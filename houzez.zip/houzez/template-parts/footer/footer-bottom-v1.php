<div class="footer-bottom-wrap footer-bottom-wrap-v1">
	<div class="container">
		<div class="d-flex justify-content-between">
			
			<?php get_template_part('template-parts/footer/copy-rights'); ?>

			<?php get_template_part('template-parts/footer/nav'); ?>
			
			<?php get_template_part('template-parts/footer/social'); ?>

		</div><!-- d-flex -->
	</div><!-- container -->
</div><!-- footer-top-wrap -->