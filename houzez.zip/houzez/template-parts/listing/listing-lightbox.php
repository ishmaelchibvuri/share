<div class="property-lightbox">
	<div class="modal fade" id="houzez-listing-lightbox" tabindex="-1" role="dialog">
		<div class="modal-dialog modal-dialog-centered" role="document">
			<div id="hz-listing-model-content" class="modal-content">
				
			</div><!-- modal-content -->
		</div><!-- modal-dialog -->
	</div><!-- modal -->
</div><!-- property-lightbox -->