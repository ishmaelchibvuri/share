<div class="col-lg-12">
	<p class="mt-30 text-center">
		<?php esc_html_e('No listing found.', 'houzez'); ?>
	</p>
</div>