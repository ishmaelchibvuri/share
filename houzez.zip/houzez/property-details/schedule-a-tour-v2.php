<div class="property-schedule-tour-wrap property-schedule-tour-wrap-v2 property-section-wrap" id="property-schedule-tour-wrap">
	<div class="block-wrap">
		<div class="block-content-wrap">
			<?php get_template_part('property-details/partials/schedule-tour-form-v2'); ?>
		</div>
		<!-- block-content-wrap -->
	</div>
	<!-- block-wrap -->
</div>