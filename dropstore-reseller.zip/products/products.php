<?php


function post_products_for_dropstore(WP_REST_Request $request)
{

    global $wpdb;
    global $wp;

    $headers = get_server_headers();
    $auth_result = auth($headers);

    $table_name = $wpdb->prefix . "dropstore_products";

    if ($auth_result == true) {

        $product = $request->get_json_params();
        $websiteProductId = $product['websiteProductId'];

        $woocommerceProduct = null;
        if (!is_null($websiteProductId) && $websiteProductId != "") {
            $woocommerceProduct = wc_get_product($websiteProductId);
        }
        if (is_null($woocommerceProduct) || !$woocommerceProduct->exists()) {
            $woocommerceProduct = get_product_by_sku($product['sku']);
        }
        //if the product exists, therefore update
        if ($woocommerceProduct){
            if (!is_countable($product['variants']) || count($product['variants']) == 0 || (count($product['variants']) == 1 && ($product['variants'][0]['title'] == 'Default' || $product['variants'][0]['title'] == 'Default Title'))) {
                //$woocommerceProduct = new WC_Product($woocommerceProduct->get_id());

                $woocommerceProduct->set_backorders('no'); // 'yes', 'no' or 'notify'
                $woocommerceProduct->set_stock_quantity($product['quantity']);
                $woocommerceProduct->set_manage_stock(true);
                $woocommerceProduct->set_price($product['price']);
                $woocommerceProduct->set_regular_price($product['price']);
                $woocommerceProduct->set_status('publish'); //Set product status.
                /*
                $images = $product['images'];
                $imageIDs = [];
                foreach ($images as $image) {
                    if ($image['src'] != '') {
                        if (strstr($image['src'], '?', true)) {
                            $file = strstr($image['src'], '?', true);
                        } else {
                            $file = $image['src'];
                        }

                        if (check_attachment_exists_by_filename($file)) {
                            $imageIDs[] = get_attachment_by_filename($file);
                        }else{
                            $imgID = downloadProductImage($product['id'], $file);
                            if (!is_null($imgID)){
                                $imageIDs[] = $imgID;
                            }else{
                                $imgID = downloadProductImage($product['id'], $file, true);
                                if (!is_null($imgID)){
                                    $imageIDs[] = $imgID;
                                }
                            }
                        }
                    }
                }
                if (isset($imageIDs) && is_countable($imageIDs) && count($imageIDs) > 0 && $imageIDs[0] != '') {
                    $woocommerceProduct->set_image_id($imageIDs[0]);
                }
                if (isset($imageIDs) && is_countable($imageIDs) && count($imageIDs) > 1) {
                    $imageIDs = array_shift($imageIDs);
                    $woocommerceProduct->set_gallery_image_ids($imageIDs);
                }*/

                $woocommerceProduct->save();
            }else{
                foreach ($product['variants'] as $productVariant){
                    $variant = $wpdb->get_var($wpdb->prepare("SELECT p.id FROM {$wpdb->prefix}postmeta as pm 
                    INNER JOIN {$wpdb->prefix}posts as p ON p.ID = pm.post_id 
                    WHERE p.post_type = 'product_variation'
                      AND p.post_status = 'publish'AND p.post_parent = {$woocommerceProduct->get_id()} 
                      AND pm.meta_key = '_sku'AND pm.meta_value != '".$productVariant['sku']."'"));

                    if (!is_null($variant)) {
                        $payload = array(
                            'id' => $variant,
                            'regular_price' => $productVariant['price'],
                            'price' => $productVariant['price'],
                            'stock_qty' => $productVariant['quantity']
                        );
                        update_variation($payload);
                    } else {
                        $sku = $productVariant['sku'];
                        create_product_variation($websiteProductId, $productVariant['title'], $sku, $productVariant['price'], $productVariant['quantity']);
                    }
                }
            }
            $response = $woocommerceProduct->get_id();
        }else{
            $response = createNewProduct($product);
        }
        return [
            'orders'      => $response,
            'status_code' => 200
        ];
    } else {
        return [
            'orders'      => 'Authorization failed',
            'status_code' => 400
        ];
    }
}


function delete_products_for_dropstore()
{
    global $wpdb;

    $headers = get_server_headers();

    $auth_result = auth($headers);

    $table_name = $wpdb->prefix . "dropstore_products";

    if ($auth_result == true) {

        if (isset($_GET['id']) && !is_null($_GET['id']) && isset($_GET['websiteProductId']) && !is_null($_GET['websiteProductId'])) {

            $id = $_GET['websiteProductId'];
            $api_id = $_GET['id'];

            $wpdb->query("DELETE FROM " . $table_name . " WHERE api_id = " . $api_id);

            $product = wc_get_product($id);

            if (!empty($product)) {
                $product->delete();
                // Delete parent product transients.
                if ($parent_id = wp_get_post_parent_id($id)) {
                    wc_delete_product_transients($parent_id);
                }
            }
        }

    }else {
        return [
            'message' => 'Authorization failed',
            'status_code' => 400
        ];
    }
}