<?php
define('MAX_DOWNLOAD_TRY_TIMES', 10);
define('DOWNLOAD_COMPLETED', 'yes');
function dropstore_product_was_deleted($post_id)
{
    $post_type = get_post_type($post_id);
    // $post_status = get_post_status( $post_id );
    //  && in_array(
    //     $post_status, array( 'publish','draft','future' )
    // )) 
    if ($post_type == 'product') {
        $vars = [
            'woo_status' => '',
            'api_websiteProductId' => '',
        ];
        $where = [
            'api_websiteProductId' => $post_id,
        ];
        dropstore_update_products_by_vars_where($vars, $where);
        do_action('dropstore_product_was_deleted', $post_id);
    }
}

add_action('delete_post', 'dropstore_product_was_deleted');

function dropstore_wp_trash_post($post_id)
{
    $post_type = get_post_type($post_id);
    // $post_status = get_post_status( $post_id );
    //  && in_array(
    //     $post_status, array( 'publish','draft','future' )
    // )) 
    if ($post_type == 'product') {
        $vars = [
            'woo_status' => 'trash',
        ];
        $where = [
            'api_websiteProductId' => $post_id,
        ];
        dropstore_update_products_by_vars_where($vars, $where);
        do_action('dropstore_trash_product', $post_id);
    }
}

add_action('wp_trash_post', 'dropstore_wp_trash_post');

function dropstore_wp_untrashed_post($post_id)
{
    $post_type = get_post_type($post_id);
    // $post_status = get_post_status( $post_id );
    //  && in_array(
    //     $post_status, array( 'publish','draft','future' )
    // )) 
    if ($post_type == 'product') {
        $vars = [
            'woo_status' => '',
        ];
        $where = [
            'api_websiteProductId' => $post_id,
        ];
        dropstore_update_products_by_vars_where($vars, $where);
        do_action('dropstore_untrash_product', $post_id);
    }
}

add_action('untrashed_post', 'dropstore_wp_untrashed_post');


function dropstore_get_product_api_id_with_sku($sku)
{
    $args = [
        'woo_sku' => $sku
    ];
    $fields = ['api_title', 'api_id', 'api_websiteProductId'];
    $objs = dropstore_get_all_products($args, $fields);
    if (isset($objs[0])) {
        return $objs[0]->api_websiteProductId;
    }
    return false;
}

/**
 * Pull products from API into the cache table
 *
 * @param null $page_index
 * @param string $status
 * @return array|false
 */
function dropstore_process_products_downloading($page_index = null, $status = 'active'/*active, deleted*/)
{
    $products = dropstore_download_products_from_server($page_index, $status);
    if (isset($products[0]['id']) && isset($products[0]['title'])) {
        $ids = [];
        foreach ($products as $prod) {
            $ids[] = dropstore_save_products_to_cache_table($prod, $status);
        }

        return $ids;
    }
    return false;
}

function dropstore_save_products_to_cache_table($prod, $status = 'active'/*active, deleted*/)
{
    $fields = dropstore_get_api_product_fields();

    $args = [];
    foreach ($fields as $field) {
        if (!empty($prod[$field])) {
            $args['api_' . $field] = $prod[$field];
        } else {
            $args['api_' . $field] = '';
        }
    }

    if (isset($prod['images'])) {
        $args['api_images'] = serialize($prod['images']);
    }
    $args['api_refer'] = serialize($prod);
    $args['woo_update_status'] = '';//to update qty and price

    return dropstore_insert_products($args);
}

function dropstore_download_and_import_active_products($all_pages = false)
{
    if (!$all_pages) {
        $dropstore_size_of_download_pages = get_option('dropstore_size_of_download_pages', 2);
        $dropstore_page_index = get_option('dropstore_page_index');
        if (empty($dropstore_page_index)) {
            $dropstore_page_index = 1;
        }
    }

    //get all active products
    $results = [];
    try {
        do {
            $products = dropstore_process_products_downloading($page_index);
            $results['downloaded'][] = $products;
            $page_index++;
        } while (!empty($products));

    } catch (Exception $e) {
        $msg = $e->getMessage();
        if (strpos($msg, '404') !== false) {//that means we are reach the end of download pages
            $page_index = 1;
        }
    }
    update_option('dropstore_page_index', $page_index);

    return $results;
}

function dropstore_download_and_delete_products()
{

    global $wpdb;
    $page_index = get_option('dropstore_page_deleted_index');

    if (empty($page_index)) {
        $page_index = 1;
    }
    try {
        /*$products = dropstore_download_products_from_server($page_index, 'deleted');

        if (empty($products)) {
            $page_index = 1;
        }else {
            $page_index++;
        }

        foreach($products as $product) {
            if($product['websiteProductId'] != ''){

                $id = $product['websiteProductId'];
                $api_id = $product['id'];

                $wpdb->query("DELETE FROM " .  $wpdb->prefix . "dropstore_products WHERE api_id " . $api_id);

                $product = wc_get_product($id);

                if(!empty($product)) {
                    $product->delete();
                    // Delete parent product transients.
                    if ($parent_id = wp_get_post_parent_id($id)) {
                        wc_delete_product_transients($parent_id);
                    }
                }
            }
        }*/

    } catch (Exception $e) {
        $msg = $e->getMessage();
        if (strpos($msg, '404') !== false) {//that means we are reach the end of download pages
            $page_index = 1;
        }
    }

    update_option('dropstore_page_deleted_index', $page_index);

    return true;
}

function dropstore_prepare_item_images($item)
{
    //add images to download table
    // ob_start();
    // print_r($item);
    // echo PHP_EOL;
    // echo PHP_EOL;
    // echo PHP_EOL;
    // echo PHP_EOL;
    // $data1=ob_get_clean();
    // file_put_contents(dirname(__FILE__)  . '/item.log',$data1,FILE_APPEND);
    $images = unserialize($item->api_images);
    foreach ($images as $i_key => $img) {
        $args = array(
            // 'ean' => $item->sku_ean,
            'remote_url' => $img['src'],
            'position' => $img['position'],
            'import_cache_id' => $item->id,
            'import_cache_title' => $item->api_title,
        );
        dropstore_insert_products_images($args);
    }
}

function dropstore_download_image($item)
{
    dropstore_prepare_item_images($item);//prepare images download infor to product images table

    $saved_args['where'] = [
        // 'ean'=>$item->sku_ean,
        'import_cache_id' => $item->id,
    ];
    $saved_args['orderby'] = 'id';
    $saved_args['order'] = 'ASC';

    $all_imgs = dropstore_get_all_products_images($saved_args);
    do_action('dropstore_get_product_images', $item, $all_imgs);

    // ob_start();
    // print_r($all_imgs);
    // echo PHP_EOL;
    // echo PHP_EOL;
    // echo PHP_EOL;
    // echo PHP_EOL;
    // $data1=ob_get_clean();
    // file_put_contents(dirname(__FILE__)  . '/all_imgs.log',$data1,FILE_APPEND);
    if (!empty($all_imgs)) {
        foreach ($all_imgs as $i_key => $i_img) {
            if (empty($i_img->local_fileinfo)) {
                $img_url = $i_img->remote_url;
                $img_title = $item->api_title . '-' . $i_key;
                $download_files_info = dropstore_download_image_and_save_to_media_library($img_url, $img_title);
                if (empty($download_files_info['error'])) {
                    $vars = [
                        'download_time' => current_time('mysql'),
                        'local_fileinfo' => serialize($download_files_info),
                    ];
                    $where = [
                        // 'ean'=>$item->sku_ean,
                        'remote_url' => $img_url,
                        // 'import_cache_id' => $item->id,
                    ];
                    dropstore_update_products_images_by_vars_where($vars, $where);
                } else {
                    do_action('dropstore_download_image_and_save_to_media_library_error', $download_files_info, $i_img);
                    // $log_args=[
                    //   'action' => 'dropstore_download_image_and_save_to_media_library',
                    //   'result' => $download_files_info['error'],
                    //   'refer' => serialize($i_img) . serialize($download_files_info),
                    // ];
                    // dropstore_insert_cronjob_log($log_args);
                }
            }
        }
    }//end of if(!empty($all_imgs)){

    $saved_args['where'] = [
        // 'ean'=>$item->sku_ean,
        'import_cache_id' => $item->id,
        'local_fileinfo' => '!=',
    ];
    $dowloaded_imgs = dropstore_get_all_products_images($saved_args);
    $downloaded_images = [];
    if (!empty($dowloaded_imgs)) {
        foreach ($dowloaded_imgs as $i_key => $i_img) {
            if (!empty($i_img->local_fileinfo)) {
                $downloaded_images[] = unserialize($i_img->local_fileinfo);
            }
        }
    }//end of if(!empty($imgs)){

    //update downloaded images of products table
    $old_args['where'] = [
        'id' => $item->id,
    ];
    $old_fields = ['images_download_completed', 'images_download_try_times'];
    $old_imgs = dropstore_get_all_products($old_args, $old_fields);
    if (isset($old_imgs[0])) {
        //update downloaded times
        $images_download_try_times = $old_imgs[0]->images_download_try_times + 1;

        $images_download_completed = '';
        //downloaded or over the max download time
        if (count($downloaded_images) == count($all_imgs) || $images_download_try_times >= MAX_DOWNLOAD_TRY_TIMES) {
            $images_download_completed = DOWNLOAD_COMPLETED;
        }
        $vars = [
            'images_download_try_times' => $images_download_try_times,
            'downloaded_images' => serialize($downloaded_images),
            'images_download_completed' => $images_download_completed,
        ];
        $where = [
            'id' => $item->id,
        ];
        dropstore_update_products_by_vars_where($vars, $where);
    }

    return $downloaded_images;
}

function dropstore_download_image_and_save_to_media_library($img_url, $image_title = '')
{
    if (empty($image_title)) {
        $image_file_base = basename($img_url);
    } else {
        $image_file_base = sanitize_title($image_title);
    }
    $get = wp_remote_get($img_url);
    // Check content-type (eg image/png), might want to test & exit if applicable
    $type = wp_remote_retrieve_header($get, 'content-type');
    $img_ext = trim($type);
    $img_ext = str_replace('image/', '', $img_ext);
    $image_file = $image_file_base . '.' . $img_ext;
    // Mirror this image in your upload dir
    $mirror = wp_upload_bits($image_file, '', wp_remote_retrieve_body($get));
    $mirror['file'] = str_replace('\\', '/',
        $mirror['file']);//we need this to avoid unserialize return empty because of \ in path
    //  Sample output for mirror:
    // array(3) {
    // ["file"]=>
    // string(64) "E:\home\planetozh\wordpress/wp-content/uploads/2010/09/Hq4QA.jpg"
    // ["url"]=>
    // string(63) "http://127.0.0.1/wordpress/wp-content/uploads/2010/09/Hq4QA.jpg"
    // ["error"]=>
    // bool(false)
    // }

    return $mirror;
}

function dropstore_prepare_importing_products_images($items)
{
    // ob_start();
    // print_r($items);
    // echo PHP_EOL;
    // echo PHP_EOL;
    // echo PHP_EOL;
    // echo PHP_EOL;
    // $data1=ob_get_clean();
    // file_put_contents(dirname(__FILE__)  . '/items.log',$data1,FILE_APPEND);
    //group products by variants or simple
    foreach ($items as $i_key => $item) {
        // ob_start();
        // print_r($item);
        // echo PHP_EOL;
        // echo PHP_EOL;
        // echo PHP_EOL;
        // echo PHP_EOL;
        // $data1=ob_get_clean();
        // file_put_contents(dirname(__FILE__)  . '/item.log',$data1,FILE_APPEND);
        $_pre_item = dropstore_prepare_importing_item($item);

        // ob_start();
        // print_r($_pre_item);
        // echo PHP_EOL;
        // echo PHP_EOL;
        // echo PHP_EOL;
        // echo PHP_EOL;
        // $data1=ob_get_clean();
        // file_put_contents(dirname(__FILE__)  . '/_pre_item.log',$data1,FILE_APPEND);
        if (empty($_pre_item['images'])) {
            $woo_images = unserialize($item->woo_images);
            $woo_images_count = 0;
            if (!empty($woo_images)) {
                $woo_images_count = count($woo_images);
            }

            $downloaded_images = unserialize($item->downloaded_images);
            $downloaded_images_count = 0;
            if (!empty($downloaded_images)) {
                $downloaded_images_count = count($downloaded_images);
            }

            // ob_start();
            // print_r($woo_images_count);
            // echo PHP_EOL;
            // print_r($downloaded_images_count);
            // echo PHP_EOL;
            // print_r($item);
            // echo PHP_EOL;
            // echo PHP_EOL;
            // echo PHP_EOL;
            // echo PHP_EOL;
            // $data1=ob_get_clean();
            // file_put_contents(dirname(__FILE__)  . '/item-empty-images.log',$data1,FILE_APPEND);

            if ($woo_images_count > 0 && ($woo_images_count == $downloaded_images_count)) {
                $_pre_item['images'] = [];//images already exist
            } else {
                $_pre_item['images'] = dropstore_download_image($item);
            }
        }
        $items[$i_key] = $_pre_item;
    }
    return $items;
}

function dropstore_get_post_content_from_item($item)
{
    return $item->api_description;
}

function dropstore_get_post_title_from_item($item)
{
    return $item->api_productName;
}

function dropstore_prepare_importing_item($item)
{
    $post = array(
        'post_title' => dropstore_get_post_title_from_item($item),
        'post_content' => dropstore_get_post_content_from_item($item),
        'post_status' => 'publish',
        'post_type' => 'product',
    );

    // $field_metas_map=[
    //   '_item'=>'im_item',
    //   '_apn_barcode'=>'im_apn_barcode',
    //   '_ean'=>'sku_ean',
    // ];

    // $dimensions=dropstore_get_dimensions_from_item($item);
    $metas = [
        // '_visibility'=>'visible',
        "_stock" => $item->api_quantity,
        "_price" => $item->api_price,
        "_regular_price" => $item->api_price,
        // "_sale_price"=>$item->api_costPrice,
        "_cost_price" => $item->api_costPrice,
        "_sku" => $item->api_sku,
        "_quantity" => $item->api_quantity,
        // "_tax_class"=>'',
    ];

    if (empty($metas['_regular_price']) && !empty($metas['_sale_price'])) {
        $metas['_regular_price'] = $metas['_sale_price'];
        $metas['_price'] = $metas['_sale_price'];
        $metas['_sale_price'] = '';
    }
    if (empty($metas['_price']) && !empty($metas['_regular_price'])) {
        $metas['_price'] = $metas['_regular_price'];
    }

    $attributes = [];
    // foreach ($attr_keys as $a_key) {
    //   $attributes[$a_key]=$a_key;
    // }
    // $post['attributes']=$attributes;

    // $field_attrs_map=[];
    $variants = [];
    $_attributes = [];
    // foreach ($field_attrs_map as $a_key => $i_key) {
    //   $_attributes[$a_key]=$item->$i_key;
    // }
    $variants[] = [
        "attributes" => $_attributes,
        "stock" => 99999,
        "price" => $item->api_price,
        "sale_price" => $item->api_price,
        "sku" => $item->api_sku,
        "tax_class" => '',
    ];

    if (empty($variants[0]['price']) && !empty($variants[0]['sale_price'])) {
        $variants[0]['price'] = $variants[0]['sale_price'];
        $variants[0]['sale_price'] = '';
    }
    /*
      [sku_category] => Wellbeing
      [sku_supplier] => Pharmacare
      [sku_brand] => Nature's Way
    */
    $categories = [
        $item->api_merchantWebsiteCategory,
        // 'supplier'=>$item->sku_supplier,
        // 'brand'=>$item->sku_brand,
    ];
    // $department_desc=explode(",",$item->im_department_desc);

    // $cat_desc=explode(",",$item->im_cat_desc);
    // $categories=$cat_desc;
    // foreach ($cat_desc as $cat) {
    //   $categories[$cat]=$item->sku_brand;//sub category
    // }
    // $categories=array_merge($cat_desc);
    //TODO make the brand as child category of above category

    if (!empty($item->api_variants)) {
        $terms = array(
            'product_type' => 'variable',
            'product_cat' => $categories,
        );
    } else {
        $terms = array(
            'product_type' => 'simple',//simple or variable
            'product_cat' => $categories,
        );
    }

    $images = [];//we treat images in other function, it's just a placeholder here
    return compact('item', 'post', 'metas', 'terms', 'attributes', 'variants', 'categories', 'images');
}

function dropstore_process_deleting_products()
{
    // $args['where']['api_productName']='!=';
    $args['where']['api_status'] = 'deleted';
    // $args['where']['images_download_completed']='yes';
    // $args['where']['woo_images']='!=';//images is ready
    $dropstore_size_of_import_batch = 999;//get_option('dropstore_size_of_import_batch',30);
    $args['number'] = $dropstore_size_of_import_batch;
    $ready = dropstore_get_all_products($args);
    $ids = [];
    foreach ($ready as $prod) {
        $sku = $prod->api_sku;
        $post_id = dropstore_get_product_id_by_sku($sku);
        $ids[] = wp_trash_post($post_id);
    }

    if (empty($ids)) {
        return false;
    }

    return $ids;
}

function dropstore_download_all_products_images($products_count = 0)
{
    $args['where']['api_productName'] = '!=';
    $args['where']['api_status'] = '!=deleted';
    $args['where']['woo_update_status'] = '';
    $args['where']['images_download_completed'] = '';//not completed of images downloading
    $args['where']['woo_status'] = '!=trash';//we ignore these product in trash

    $args['number'] = $products_count;

    $args['orderby'] = 'images_download_try_times';
    $args['order'] = 'ASC';//to avoid the same item was try again and again

    // [id] => 380
    // [api_productName] => Jeronimo 2 in 1 Zoo Blocks
    // [api_title] => Jeronimo 2-in-1 Zoo Blocks
    // [api_sku] => 8000601
    $fields = ['id', 'api_title', 'api_sku', 'api_images'];
    $ready_but_missing_images = dropstore_get_all_products($args);
    // ob_start();
    // print_r($args);
    // echo PHP_EOL;
    // print_r($ready_but_missing_images);
    // echo PHP_EOL;
    // echo PHP_EOL;
    // echo PHP_EOL;
    // echo PHP_EOL;
    // $data1=ob_get_clean();
    // file_put_contents(dirname(__FILE__)  . '/ready_but_missing_images.log',$data1,FILE_APPEND);
    //download images
    $download_imgs = [];
    foreach ($ready_but_missing_images as $item) {
        $download_imgs[] = dropstore_download_image($item);
    }
    do_action('dropstore_download_imgs', $download_imgs);

    return $download_imgs;
}

function verify_plugin_on_dropstore($access_token)
{
    $access_token = get_option('dropstore_access_token');
    $site_url = get_option('siteurl');

    $body = array(
        "site_url" => $site_url,
        "plugin_version" => "7.0.0"
     );

    //The URL that we want to send a PUT request to.
    $url = 'https://api-backend.dropstore.co.za/api/v2/merchant/plugin/verify';

    try {
        $args = array(
            'method' => 'PUT',
            'body' => json_encode($body),
            'timeout' => 600,
            'headers' => array( 'X-Dropstore-Access-Token' => $access_token)
        );

        $response = wp_remote_request($url, $args);
        return $response;

    } catch (Exception $e) {
        return $e->getMessage();
    }

}

function create_webhook($access_token)
{
    global $wpdb;
    $orderUrl = 'https://api-backend.dropstore.co.za/api/v1/woocommerce/merchant/order/create/' . $access_token;
    $productUrl = 'https://api-backend.dropstore.co.za/api/v1/woocommerce/source/merchant/product/delete/' . $access_token;
    $orderExisting = false;
    $productExisting = false;
    try {

        $wpdb->query( "DELETE FROM {$wpdb->prefix}wc_webhooks WHERE delivery_url LIKE '%dropstore.co.za%'" );

        $results = $wpdb->get_results( "SELECT webhook_id, delivery_url FROM {$wpdb->prefix}wc_webhooks" );
        foreach($results as $result)
        {
            if(strpos($result->delivery_url, $orderUrl) !== false)
            {
                $orderExisting = true;
            }

            if(strpos($result->delivery_url, $productUrl) !== false)
            {
                $productExisting = true;
            }
        }

        if (!$orderExisting) {
            $webhook = new WC_Webhook();
            $webhook->set_user_id( 1 ); // User ID used while generating the webhook payload.
            $webhook->set_name( 'Dropstore Order Update' ); // Event used to trigger a webhook.
            $webhook->set_topic( 'order.updated' ); // Event used to trigger a webhook.
            $webhook->set_secret( 'secret' ); // Secret to validate webhook when received.
            $webhook->set_delivery_url($orderUrl); // URL where webhook should be sent.
            $webhook->set_status( 'active' ); // Webhook status.
            $webhook->save();
        }

        if (!$productExisting) {
            $webhook = new WC_Webhook();
            $webhook->set_user_id( 1 ); // User ID used while generating the webhook payload.
            $webhook->set_name( 'Dropstore Deleted Product ' ); // Event used to trigger a webhook.
            $webhook->set_topic( 'product.deleted' ); // Event used to trigger a webhook.
            $webhook->set_secret( 'secret' ); // Secret to validate webhook when received.
            $webhook->set_delivery_url( $productUrl); // URL where webhook should be sent.
            $webhook->set_status( 'active' ); // Webhook status.
            $webhook->save();
        }
    } catch (Exception $e) {

    }
}