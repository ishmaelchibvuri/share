<?php

/**
 * Handle the form submissions
 *
 * @package Package
 * @subpackage Sub Package
 */
class DropStore_Products_Form_Handler {

    /**
     * Hook 'em all
     */
    public function __construct() {
        add_action( 'admin_init', array( $this, 'handle_form' ) );
    }

    /**
     * Handle the products new and edit form
     *
     * @return void
     */
    public function handle_form() {
        // echo '<div style="display1:none;"><pre>';
        // var_dump(__METHOD__);
        // echo '</pre></div>';
        // die();
        if ( ! isset( $_POST['submit_products'] ) ) {
            return;
        }
        // echo '<div style="display1:none;"><pre>';
        // var_dump(__METHOD__);
        // echo '</pre></div>';
        // die();
        if ( ! wp_verify_nonce( $_POST['_wpnonce'], 'dropstore_products_nonce' ) ) {
            die( __( 'Wrong nonce!', 'dropstore' ) );
        }

        if ( ! current_user_can( 'read' ) ) {
            wp_die( __( 'Permission Denied!', 'dropstore' ) );
        }

        $errors   = array();
        $page_url = admin_url( 'admin.php?page=dropstore-products' );
        $field_id = isset( $_POST['field_id'] ) ? intval( $_POST['field_id'] ) : 0;

        // $clicks = isset( $_POST['clicks'] ) ? sanitize_text_field( $_POST['clicks'] ) : '';
        $api_productName = isset( $_POST['api_productName'] ) ? sanitize_text_field( $_POST['api_productName'] ) : '';
        $api_title = isset( $_POST['api_title'] ) ? sanitize_text_field( $_POST['api_title'] ) : '';
        $api_sku = isset( $_POST['api_sku'] ) ? sanitize_text_field( $_POST['api_sku'] ) : '';
        $api_description = isset( $_POST['api_description'] ) ? sanitize_text_field( $_POST['api_description'] ) : '';
        $api_merchantWebsiteCategory = isset( $_POST['api_merchantWebsiteCategory'] ) ? sanitize_text_field( $_POST['api_merchantWebsiteCategory'] ) : '';
        $woo_sku = isset( $_POST['woo_sku'] ) ? sanitize_text_field( $_POST['woo_sku'] ) : '';
        $woo_categories = isset( $_POST['woo_categories'] ) ? sanitize_text_field( $_POST['woo_categories'] ) : '';
        $woo_tags = isset( $_POST['woo_tags'] ) ? sanitize_text_field( $_POST['woo_tags'] ) : '';
        $woo_metas = isset( $_POST['woo_metas'] ) ? sanitize_text_field( $_POST['woo_metas'] ) : '';
        $woo_short_desc = isset( $_POST['woo_short_desc'] ) ? sanitize_text_field( $_POST['woo_short_desc'] ) : '';
        $woo_attributes = isset( $_POST['woo_attributes'] ) ? sanitize_text_field( $_POST['woo_attributes'] ) : '';
        $woo_variants = isset( $_POST['woo_variants'] ) ? sanitize_text_field( $_POST['woo_variants'] ) : '';
        $api_variants = isset( $_POST['api_variants'] ) ? sanitize_text_field( $_POST['api_variants'] ) : '';
        $woo_import_status = isset( $_POST['woo_import_status'] ) ? sanitize_text_field( $_POST['woo_import_status'] ) : '';
        $api_timeCreated = isset( $_POST['api_timeCreated'] ) ? sanitize_text_field( $_POST['api_timeCreated'] ) : '';
        $api_timeModified = isset( $_POST['api_timeModified'] ) ? sanitize_text_field( $_POST['api_timeModified'] ) : '';
        $api_markupPercentage = isset( $_POST['api_markupPercentage'] ) ? sanitize_text_field( $_POST['api_markupPercentage'] ) : '';
        $api_tags = isset( $_POST['api_tags'] ) ? sanitize_text_field( $_POST['api_tags'] ) : '';
        $created_at = isset( $_POST['created_at'] ) ? sanitize_text_field( $_POST['created_at'] ) : '';
        $updated_at = isset( $_POST['updated_at'] ) ? sanitize_text_field( $_POST['updated_at'] ) : '';
        $api_refer = isset( $_POST['api_refer'] ) ? sanitize_text_field( $_POST['api_refer'] ) : '';
        $woo_description = isset( $_POST['woo_description'] ) ? sanitize_text_field( $_POST['woo_description'] ) : '';
        $woo_images = isset( $_POST['woo_images'] ) ? sanitize_text_field( $_POST['woo_images'] ) : '';
        $woo_attach_ids = isset( $_POST['woo_attach_ids'] ) ? sanitize_text_field( $_POST['woo_attach_ids'] ) : '';
        $woo_refer = isset( $_POST['woo_refer'] ) ? sanitize_text_field( $_POST['woo_refer'] ) : '';
        $api_id = isset( $_POST['api_id'] ) ? sanitize_text_field( $_POST['api_id'] ) : '';
        $api_websiteProductId = isset( $_POST['api_websiteProductId'] ) ? sanitize_text_field( $_POST['api_websiteProductId'] ) : '';
        $api_price = isset( $_POST['api_price'] ) ? sanitize_text_field( $_POST['api_price'] ) : '';
        $api_costPrice = isset( $_POST['api_costPrice'] ) ? sanitize_text_field( $_POST['api_costPrice'] ) : '';
        $api_quantity = isset( $_POST['api_quantity'] ) ? sanitize_text_field( $_POST['api_quantity'] ) : '';
        $api_checksum = isset( $_POST['api_checksum'] ) ? sanitize_text_field( $_POST['api_checksum'] ) : '';
        // some basic validation
        // if ( ! $clicks ) {
        //     $errors[] = __( 'Error: Clicks is required', 'dropstore' );
        // }

        if (empty($api_productName) ) {
            $errors[] = __( 'Error: Api Product Name is required', 'dropstore' );
        }
        if (empty($api_title) ) {
            $errors[] = __( 'Error: Api Title is required', 'dropstore' );
        }
        if (empty($api_sku) ) {
            $errors[] = __( 'Error: Api Sku is required', 'dropstore' );
        }
        if (empty($api_description) ) {
            $errors[] = __( 'Error: Api Description is required', 'dropstore' );
        }
        if (empty($api_merchantWebsiteCategory) ) {
            $errors[] = __( 'Error: Api Merchant Website Category is required', 'dropstore' );
        }
        if (empty($woo_sku) ) {
            $errors[] = __( 'Error: Woo Sku is required', 'dropstore' );
        }
        if (empty($woo_categories) ) {
            $errors[] = __( 'Error: Woo Categories is required', 'dropstore' );
        }
        if (empty($woo_tags) ) {
            $errors[] = __( 'Error: Woo Tags is required', 'dropstore' );
        }
        if (empty($woo_metas) ) {
            $errors[] = __( 'Error: Woo Metas is required', 'dropstore' );
        }
        if (empty($woo_short_desc) ) {
            $errors[] = __( 'Error: Woo Short Desc is required', 'dropstore' );
        }
        if (empty($woo_attributes) ) {
            $errors[] = __( 'Error: Woo Attributes is required', 'dropstore' );
        }
        if (empty($woo_variants) ) {
            $errors[] = __( 'Error: Woo Variants is required', 'dropstore' );
        }
        if (empty($woo_import_status) ) {
            $errors[] = __( 'Error: Woo Import Status is required', 'dropstore' );
        }
        if (empty($api_timeCreated) ) {
            $errors[] = __( 'Error: Api Time Created is required', 'dropstore' );
        }
        if (empty($api_timeModified) ) {
            $errors[] = __( 'Error: Api Time Modified is required', 'dropstore' );
        }
        if (empty($api_markupPercentage) ) {
            $errors[] = __( 'Error: Api Markup Percentage is required', 'dropstore' );
        }
        if (empty($api_tags) ) {
            $errors[] = __( 'Error: Api Tags is required', 'dropstore' );
        }
        if (empty($api_refer) ) {
            $errors[] = __( 'Error: Api Refer is required', 'dropstore' );
        }
        if (empty($woo_description) ) {
            $errors[] = __( 'Error: Woo Description is required', 'dropstore' );
        }
        if (empty($woo_images) ) {
            $errors[] = __( 'Error: Woo Images is required', 'dropstore' );
        }
        if (empty($woo_attach_ids) ) {
            $errors[] = __( 'Error: Woo Attach Ids is required', 'dropstore' );
        }
        if (empty($woo_refer) ) {
            $errors[] = __( 'Error: Woo Refer is required', 'dropstore' );
        }
        if (empty($api_id) ) {
            $errors[] = __( 'Error: Api ID is required', 'dropstore' );
        }
        if (empty($api_websiteProductId) ) {
            $errors[] = __( 'Error: Api Website Product ID is required', 'dropstore' );
        }
        if (empty($api_price) ) {
            $errors[] = __( 'Error: Api Price is required', 'dropstore' );
        }
        if (empty($api_costPrice) ) {
            $errors[] = __( 'Error: Api Cost Price is required', 'dropstore' );
        }

        $fields = array(
            'api_productName' => $api_productName,
            'api_title' => $api_title,
            'api_sku' => $api_sku,
            'api_description' => $api_description,
            'api_merchantWebsiteCategory' => $api_merchantWebsiteCategory,
            'woo_sku' => $woo_sku,
            'woo_categories' => $woo_categories,
            'woo_tags' => $woo_tags,
            'woo_metas' => $woo_metas,
            'woo_short_desc' => $woo_short_desc,
            'woo_attributes' => $woo_attributes,
            'woo_variants' => $woo_variants,
            'api_variants' => $api_variants,
            'woo_import_status' => $woo_import_status,
            'api_timeCreated' => $api_timeCreated,
            'api_timeModified' => $api_timeModified,
            'api_markupPercentage' => $api_markupPercentage,
            'api_tags' => $api_tags,
            'api_refer' => $api_refer,
            'woo_description' => $woo_description,
            'woo_images' => $woo_images,
            'woo_attach_ids' => $woo_attach_ids,
            'woo_refer' => $woo_refer,
            'api_id' => $api_id,
            'api_websiteProductId' => $api_websiteProductId,
            'api_price' => $api_price,
            'api_costPrice' => $api_costPrice,
            'api_checksum' => $api_checksum,
            'api_quantity' => $api_quantity,
        );
        // bail out if error found
        if ( $errors ) {
            $first_error = reset( $errors );
            if(empty($field_id)){
                $query_arg=$fields + array( 'error' => urlencode($first_error), 'action' =>'new' ); 
                $redirect_to = add_query_arg($query_arg, $page_url );
            }else{
                $query_arg=$fields + array( 'error' => urlencode($first_error), 'action' =>'edit','id'=>$field_id ); 
                $redirect_to = add_query_arg($query_arg, $page_url );
            }
            wp_safe_redirect( $redirect_to );
            exit;
        }

        // New or edit?
        if ($field_id ) {
            $fields['id'] = $field_id;
        }
        $insert_id = dropstore_insert_products( $fields );

        if ( is_wp_error( $insert_id ) ) {
            $redirect_to = add_query_arg(
                array( 'error' => urlencode($insert_id->get_error_message()) ),
                $page_url
            );
        } else {
            do_action('products_data_was_saved_successfully',$insert_id,$fields);
            $redirect_to = add_query_arg(
                array( 'success' => urlencode(__( 'Succesfully saved!', 'dropstore' )) ),
                $page_url
            );
        }

        wp_safe_redirect( $redirect_to );
        exit;
    }
}

new DropStore_Products_Form_Handler();