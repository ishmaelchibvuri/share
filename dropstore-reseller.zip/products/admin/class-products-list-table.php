<?php

if (!class_exists('WP_List_Table')) {
    require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

/**
 * List table class
 */
class DropStore_Products_List extends \WP_List_Table
{

    function __construct()
    {
        parent::__construct(array(
            'singular' => 'Product',
            'plural' => 'Products',
            'ajax' => false
        ));
    }

    function get_table_classes()
    {
        return array('widefat', 'fixed', 'striped', $this->_args['plural']);
    }

    /**
     * Message to show if no designation found
     *
     * @return void
     */
    function no_items()
    {
        _e('No Products Found', 'dropstore');
    }

    /**
     * Default column values if no callback found
     *
     * @param object $item
     * @param string $column_name
     *
     * @return string
     */
    function column_default($item, $column_name)
    {

        switch ($column_name) {
            case 'id':
                return $item->id;

            case 'api_productName':
                return $item->api_productName;

            case 'api_title':
                return $item->api_title;

            case 'api_sku':
                return $item->api_sku;

            case 'api_description':
                return $item->api_description;

            case 'api_merchantWebsiteCategory':
                return $item->api_merchantWebsiteCategory;

            case 'woo_sku':
                return $item->woo_sku;

            case 'woo_categories':
                return $item->woo_categories;

            case 'woo_tags':
                return $item->woo_tags;

            case 'woo_metas':
                return $item->woo_metas;

            case 'woo_short_desc':
                return $item->woo_short_desc;

            case 'woo_attributes':
                return $item->woo_attributes;

            case 'woo_variants':
                return $item->woo_variants;

            case 'woo_import_status':
                return $item->woo_import_status;

            case 'api_timeCreated':
                return $item->api_timeCreated;

            case 'api_timeModified':
                return $item->api_timeModified;

            case 'api_markupPercentage':
                return $item->api_markupPercentage;

            case 'api_tags':
                return $item->api_tags;

            case 'created_at':
                return $item->created_at;

            case 'updated_at':
                return $item->updated_at;

            case 'api_refer':
                return $item->api_refer;

            case 'woo_description':
                return $item->woo_description;

            case 'woo_images':
                return $item->woo_images;

            case 'woo_attach_ids':
                return $item->woo_attach_ids;

            case 'woo_refer':
                return $item->woo_refer;

            case 'api_id':
                return $item->api_id;

            case 'api_websiteProductId':
                return $item->api_websiteProductId;

            case 'api_price':
                return $item->api_price;

            case 'api_costPrice':
                return $item->api_costPrice;

            case 'is_processed':
                return ($item->is_processed == 1 ? "yes" : "no");
            default:
                return isset($item->$column_name) ? $item->$column_name : '';
        }
    }

    /**
     * Render the designation name column
     *
     * @param object $item
     *
     * @return string
     */
    function column_id($item)
    {

        $actions = array();
        $actions['delete'] = sprintf('<a href="%s" class="submitdelete" data-id="%d" title="%s">%s</a>',
            admin_url('admin.php?page=dropstore-products&action=delete&id=' . $item->id), $item->id,
            __('Delete this item', 'dropstore'), __('Delete', 'dropstore'));

        return sprintf('<a href="%1$s"><strong>%2$s</strong></a> %3$s',
            admin_url('admin.php?page=dropstore-products&action=view&id=' . $item->id), $item->id,
            $this->row_actions($actions));
    }

    function column_name($item)
    {
        return sprintf('<a href="%s" data-id="%d" title="%s">%s</a>',
            admin_url('admin.php?page=dropstore-products&action=edit&id=' . $item->id), $item->id,
            __($item->name, 'dropstore'), __($item->name, 'dropstore'));
    }

    function column_woo_status($item)
    {
        if ('trash' == $item->woo_status) {
            return '<span style="color:red;">' . $item->woo_status . '</span>';
        }
        return $item->woo_status;
    }

    function column_api_images($item)
    {
        // $images=unserialize($item->api_images);
        // if(empty($images)) return false;
        $api_images = unserialize($item->api_images);
        if (empty($api_images)) {
            $count = 0;
        } else {
            $count = count($api_images);
        }
        $count_images[] = 'API Images: ' . $count . ' images';

        $downloaded_images = unserialize($item->downloaded_images);
        if (empty($downloaded_images)) {
            $count = 0;
        } else {
            $count = count($downloaded_images);
        }

        $count_images[] = 'Downloaded: ' . $count;
        $count_images[] = 'Try ' . $item->images_download_try_times . ' times';
        $yes_no = ('yes' == $item->images_download_completed) ? 'Yes' : '<b style="color:red;">No</b>';
        $count_images[] = 'Completed: ' . $yes_no;

        $count_images_line = implode('<br/>', $count_images);
        return $count_images_line;
    }

    function column_woo_title($item)
    {
        return sprintf('<a href="%s" title="%s">%s</a>',
            admin_url('post.php?action=edit&post=' . $item->api_websiteProductId), __($item->woo_title, 'dropstore'),
            __($item->woo_title, 'dropstore'));
    }

    function column_api_productName($item)
    {
        return sprintf('<a href="%s" data-id="%d" title="%s">%s</a>',
            admin_url('admin.php?page=dropstore-products&action=view&id=' . $item->id), $item->id,
            __($item->api_productName, 'dropstore'), __($item->api_productName, 'dropstore'));
    }

    /**
     * Set the bulk actions
     *
     * @return array
     */
    function get_bulk_actions()
    {
        $actions = array(
            'delete' => __('Delete Selected Items', 'dropstore'),
        );
        return $actions;
    }

    /**
     * Render the checkbox column
     *
     * @param object $item
     *
     * @return string
     */
    function column_cb($item)
    {
        return sprintf(
            '<input type="checkbox" name="products_id[]" value="%d" />', $item->id
        );
    }

    /**
     * Set the views
     *
     * @return array
     */
    public function get_views()
    {

        $base_link = admin_url('admin.php?page=dropstore-products');

        $status_links = $this->get_status_links();

        foreach ($status_links as $key => $value) {
            $class = ($key == $_GET['status']) ? 'current' : 'status-' . $key;
            $status_links[$key] = sprintf('<li class="%s"><a href="%s" class="%s status-link">%s</a><span class="count"> (%s)</span></li>',
                $key, add_query_arg(array('status' => $key), $base_link), $class, $value['label'], $value['count']);
        }

        return '<ul class="subsubsub">' . implode(' | ', $status_links) . '</ul>';
    }

    function get_status_links()
    {
        $all_links = [
            'all' => 'All',
            'active_api_data' => 'API data(active)',
            'inactive_api_data' => 'API data(removed)',
            'imported_products' => 'Product Created',
            'pending_sync_products' => 'Pending Batch Update',
        ];

        foreach ($all_links as $l_key => $l_val) {
            $args = [];
            $args = $this->get_where_from_status($args, $l_key);
            $all_links[$l_key] = [
                'label' => $l_val,
                'count' => dropstore_get_products_count($args),
            ];
        }

        return $all_links;
    }

    function get_where_from_status($args, $status)
    {
        switch ($status) {
            case 'all':
                $args['where']['api_status'] = '!=deleted';
                break;

            case 'imported_products':
                $args['where']['api_status'] = '!=deleted';
                $args['where']['api_websiteProductId'] = "!=''";
                $args['where']['api_websiteProductId'] = "!=NULL";
                break;

            case 'pending_sync_products':
                $args['where']['api_status'] = '!=deleted';
                $args['where']['is_processed'] = "0";
                break;

            case 'active_api_data':
                $args['where']['api_status'] = 'active';
                break;

            case 'inactive_api_data':
                $args['where']['api_status'] = 'deleted';
                break;

            default:
                break;
        }
        return $args;
    }

    /**
     * Prepare the class items
     *
     * @return void
     */
    function prepare_items()
    {

        $columns = $this->get_columns();
        $hidden = array();
        $sortable = $this->get_sortable_columns();
        $this->_column_headers = array($columns, $hidden, $sortable);
        $per_page = 25;
        $current_page = $this->get_pagenum();
        $offset = ($current_page - 1) * $per_page;
        $this->page_status = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : '2';
        $search = isset($_REQUEST['s']) ? sanitize_text_field($_REQUEST['s']) : '';

        // only necessary because we have sample data
        $args = array(
            'offset' => $offset,
            'number' => $per_page,
            'search' => '*' . $search . '*',
        );

        if (isset($_REQUEST['orderby']) && isset($_REQUEST['order'])) {
            $args['orderby'] = $_REQUEST['orderby'];
            $args['order'] = $_REQUEST['order'];
        }

        if (!empty($search)) {
            /*TODO: please check the field name to match*/
            $args['where'] = array('api_productName' => '*' . $search . '*');
        }


        if (!empty($_GET['status'])) {
            $args = $this->get_where_from_status($args, $_GET['status']);
        }

        $this->items = dropstore_get_all_products($args);

        $this->set_pagination_args(array(
            'total_items' => dropstore_get_products_count($args),
            'per_page' => $per_page
        ));
    }

    /**
     * Get the column names
     *
     * @return array
     */
    function get_columns()
    {
        $columns = array(
            'cb' => '<input type="checkbox" />',
            'id' => __('ID', '{ns}'),
            'api_productName' => __('Product', 'dropstore'),
            'api_sku' => __('Sku', 'dropstore'),
            'api_status' => __('API Status', 'dropstore'),
            'api_price' => __('Price', 'dropstore'),
            'api_costPrice' => __('Cost Price', 'dropstore'),
            'api_merchantWebsiteCategory' => __('Category', 'dropstore'),
            'updated_at' => __('Updated', 'dropstore'),
            'is_processed' => __('Processed', 'dropstore'),
        );

        return $columns;
    }

    /**
     * Get sortable columns
     *
     * @return array
     */
    function get_sortable_columns()
    {
        $sortable_columns = array(
            'id' => array('id', true),
            'name' => array('name', true),
            'api_sku' => array('api_sku', true),
        );

        return $sortable_columns;
    }

    protected function extra_tablenav($which)
    {
        do_action('dropstore_products_tablenav', $which);
    }
}