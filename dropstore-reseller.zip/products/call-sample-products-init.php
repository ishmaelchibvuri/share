<?php 
require_once DROPSTORE_DIR . '/includes/form-fields.php';
require_once DROPSTORE_DIR . '/includes/db-functions.php';
require_once DROPSTORE_DIR . '/products/products-init.php';
