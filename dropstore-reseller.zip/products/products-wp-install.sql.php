<?php
if( is_admin() ) {
    dropstore_db_install_products_table();
}

function dropstore_db_install_products_table()
{
    define('DROPSTORE_PRODUCTS_DB_VERSION', '4.0');
    $dropstore_installed = get_option('dropstore_products_db_version');
    if( $dropstore_installed != DROPSTORE_PRODUCTS_DB_VERSION ) {

        dropstore_reset_websiteProductId_on_products_table();

        GLOBAL $wpdb;

        $wp_prefix = $wpdb->prefix;
        // This includes the dbDelta function from WordPress.
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        $create_products_table = ("
CREATE TABLE `{$wp_prefix}dropstore_products` (
    `id` int(11) UNSIGNED NOT NULL auto_increment,
     PRIMARY KEY  (`id`),
     `api_id` int UNSIGNED NOT NULL default 0,
     `is_processed` varchar(1) NOT NULL default '',     
     `api_websiteProductId` varchar(10) DEFAULT NULL,   
     `api_productName` varchar(255) NOT NULL default '',
     `api_sku` varchar(255) NOT NULL default '',
     `api_title` varchar(255) NOT NULL default '',
     `api_description` text NOT NULL,
     `api_merchantWebsiteCategory` varchar(255) DEFAULT NULL,
     `api_markupPercentage` varchar(255) NOT NULL default '',
     `api_tags` varchar(255) DEFAULT NULL,
     `api_images` text NOT NULL,
     `api_quantity` int UNSIGNED NOT NULL default 0,  
     `api_price` decimal(12,2) NOT NULL default 0.0,
     `api_costPrice` decimal(12,2) NOT NULL default 0.0,
     `api_variants` text,
     `api_categories` text,
     `api_dimensions` text,
     `api_status` varchar(10) DEFAULT NULL,
     `api_checksum` varchar(50) DEFAULT NULL,                            
     `images_download_completed` varchar(255) NOT NULL default '',
     `woo_attach_ids` text NOT NULL,
     `downloaded_images` text NOT NULL,
     `woo_status` varchar(255) NOT NULL default '',
     `images_download_try_times` int UNSIGNED NOT NULL default 0,
     `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
     `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
     `last_processed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;");
        
        // Create/update the plugin tables.
        dbDelta($create_products_table);
        update_option('dropstore_products_db_version', DROPSTORE_PRODUCTS_DB_VERSION);
    }
}

function dropstore_reset_websiteProductId_on_products_table() {

     global $wpdb;
     $table_name = $wpdb->prefix . "dropstore_products";
     $sql = "DROP TABLE IF EXISTS $table_name;";
     $wpdb->query($sql);
}