<?php
function dropstore_products_init(){
    require_once dirname( __FILE__ ) . '/products-functions.php';
    require_once dirname( __FILE__ ) . '/products-db-functions.php';
    require_once dirname( __FILE__ ) . '/products.php';
    if(is_admin()){
        require_once dirname( __FILE__ ) . '/products-wp-install.sql.php'; 
        require_once dirname( __FILE__ ) . '/admin/class-products-list-table.php';
        require_once dirname( __FILE__ ) . '/admin/class-products-form-handler.php';
        require_once dirname( __FILE__ ) . '/admin/class-products.php'; 
    }
}//end dropstore_init

add_action('init','dropstore_products_init',10);

function dropstore_products_data_was_saved_successfully($insert_id,$fields)
{
    // your code here
}
add_action('products_data_was_saved_successfully','dropstore_products_data_was_saved_successfully',10,2);
