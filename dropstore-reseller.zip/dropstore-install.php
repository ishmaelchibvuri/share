<?php
if( is_admin() ) {
}//end of if( is_admin() ) {