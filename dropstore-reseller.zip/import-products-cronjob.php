<?php
ini_set('max_execution_time', 600);

function dropstore_add_import_products_cron_schedules($schedules)
{
    $schedules['10_minutes'] = array(
        'interval' => 60 * 10,
        'display' => __('10 Minutes')
    );
    $schedules['15_minutes'] = array(
        'interval' => 60 * 15,
        'display' => __('15 Minutes')
    );
    $schedules['30_minutes'] = array(
        'interval' => 60 * 30 * 1,
        'display' => __('30 Minutes')
    );
    $schedules['hourly'] = array(
        'interval' => 60 * 60 * 1,
        'display' => __('Hourly')
    );
    $schedules['2_hours'] = array(
        'interval' => 60 * 60 * 2,
        'display' => __('2 Hours')
    );
    $schedules['3_hours'] = array(
        'interval' => 60 * 60 * 3,
        'display' => __('3 Hours')
    );
    $schedules['4_hours'] = array(
        'interval' => 60 * 60 * 4,
        'display' => __('4 Hours')
    );
    $schedules['5_hours'] = array(
        'interval' => 60 * 60 * 5,
        'display' => __('5 Hours')
    );
    $schedules['6_hours'] = array(
        'interval' => 60 * 60 * 6,
        'display' => __('6 Hours')
    );
    $schedules['8_hours'] = array(
        'interval' => 60 * 60 * 8,
        'display' => __('8 Hours')
    );
    $schedules['12_hours'] = array(
        'interval' => 60 * 60 * 12,
        'display' => __('12 Hours')
    );
    $schedules['daily'] = array(
        'interval' => 60 * 60 * 24,
        'display' => __('Daily')
    );
    return $schedules;
}

add_filter('cron_schedules', 'dropstore_add_import_products_cron_schedules');

function dropstore_setup_import_products_cron_job($cron_hook, $schedule_id = 'twicedaily')
{
    $all_schedules_ids = array(
        '10_minutes',
        '15_minutes',
        '30_minutes',
        'hourly',
        '2_hours',
        '3_hours',
        '4_hours',
        '5_hours',
        '6_hours',
        '8_hours',
        '12_hours',
        'daily',
        'hourly',
        'daily',
        'twicedaily'
    );
    if (false == in_array($schedule_id, $all_schedules_ids)) {
        $schedule_id = 'twicedaily';
    }
    if (wp_next_scheduled($cron_hook)) {//clear previous settings
        wp_clear_scheduled_hook($cron_hook);
    }
    wp_schedule_event(time(), $schedule_id, $cron_hook);
}
/*
function dropstore_import_products_cron_task()
{

    global $wpdb;
    $table_name = $wpdb->prefix . "dropstore_products";
    $state = 'success';
    $result = 0;
    $data[] = '';
    $dropstore_create_update_count=get_option('dropstore_products_create_update_count',20);

    $productLists = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}dropstore_products WHERE is_processed != '1' ORDER BY last_processed_at ASC  LIMIT " . $dropstore_create_update_count);

    try {

        foreach ($productLists as $productList) {

            $productList = (array)$productList;
            $imageIDs = array();

            //creating new product
            if (is_null($productList['api_websiteProductId']) || $productList['api_websiteProductId'] == '' || $productList['api_websiteProductId'] == 0) {

                //checking if existing post has the same sku
                $woocommerceProduct = get_product_by_sku($productList['api_sku']);

                /**
                 * If product found, this updates the cache with product_id data, in 2nd run, it would flag as processed
                 **
                if(!is_null($woocommerceProduct)){

                    $api_variants = unserialize($productList['api_variants']);

                    if (!is_countable($api_variants) || count($api_variants) == 0 || (count($api_variants) == 1 && ($api_variants[0]['title'] == 'Default' || $api_variants[0]['title'] == 'Default Title'))) {

                        $woocommerceExistingProduct = new WC_Product($woocommerceProduct->get_id());

                        $woocommerceExistingProduct->set_backorders('no'); // 'yes', 'no' or 'notify'
                        $woocommerceExistingProduct->set_stock_quantity($productList['api_quantity']);
                        $woocommerceExistingProduct->set_manage_stock(true);
                        $woocommerceExistingProduct->set_price($productList['api_price']);
                        $woocommerceExistingProduct->set_regular_price($productList['api_price']);
                        $woocommerceExistingProduct->set_status('publish'); //Set product status.

                        $woocommerceExistingProduct->save();

                    } else {

                        foreach ($api_variants as $api_variant) {

                            $variant = $wpdb->get_var($wpdb->prepare("SELECT p.id FROM {$wpdb->prefix}postmeta as pm
        INNER JOIN {$wpdb->prefix}posts as p ON p.ID = pm.post_id
        WHERE p.post_type = 'product_variation'AND p.post_status = 'publish'AND p.post_parent = {$woocommerceProduct->get_id()} AND pm.meta_key = '_sku'AND pm.meta_value != '".$api_variant['sku']."'"));

                            $payload = array(
                                'id' => $variant,
                                'regular_price' => $api_variant['price'],
                                'price' => $api_variant['price'],
                                'stock_qty' => $api_variant['quantity']
                            );
                            update_variation($payload);
                        }
                    }

                    $variables['is_processed'] = '1';
                    $variables['last_processed_at'] = date('Y-m-d H:i:s');
                    $variables['api_websiteProductId'] = $woocommerceProduct->get_id();

                    $wpdb->update($table_name, $variables, array('id' => $productList['id']));

                    update_dropstore_with_product_id($woocommerceProduct->get_id(), $productList['api_id']);

                    continue;
                }

                $api_variants = unserialize($productList['api_variants']);
                $descArray = explode('.', $productList['api_description'], 2);
                $short_description = $descArray[0];

                if (!is_countable($api_variants) || count($api_variants) == 0 || (count($api_variants) == 1 && ($api_variants[0]['title'] == 'Default' || $api_variants[0]['title'] == 'Default Title'))) {

                    $payload = array(
                        'name' => $productList['api_title'],
                        'description' => $productList['api_description'],
                        'short_description' => $short_description,
                        'sku' => $productList['api_sku'],
                        'regular_price' => $productList['api_price'], // product price
                        'status' => ($productList['api_status'] == 'active' ? 'publish' : 'pending'),
                        'visibility' => ($productList['api_status'] == 'active' ? 'visible' : 'hidden'),
                        'manage_stock' => true,
                        'stock_qty' => $productList['api_quantity'],
                        'weight' => ($productList['weight'] ?? ''),
                        'length' => ($productList['api_dimensions']['length'] ?? ''),
                        'width' => ($productList['api_dimensions']['width'] ?? ''),
                        'height' => ($productList['api_dimensions']['height'] ?? '')

                    );

                    $resultID = create_simple_product($payload);

                    $wpdb->update($table_name, $variables, array('id' => $resultID));

                    $woocommerceProduct = new WC_Product($resultID);

                    $images = unserialize($productList['api_images']);
                    foreach ($images as $image) {
                        if ($image['src'] != '') {
                            if (strstr($image['src'], '?', true)) {
                                $file =  strstr($image['src'], '?', true);
                            } else {
                                $file =  $image['src'];
                            }

                            if ( 0 ==  does_file_exists( $file ) ) {
                                $imageIDs[] = setProductImage($resultID, $file);
                            }
                        }
                    }


                    //setting images
                    if (is_countable($imageIDs) && count($imageIDs) > 0 && $imageIDs[0] != '') {
                        // Images and Gallery
                        $product->set_image_id($args['image_id'] ?? "");
                        $product->set_gallery_image_ids($args['gallery_ids'] ?? array());
                        $payload['image_id'] = $imageIDs[0];
                    }
                    if (is_countable($imageIDs) && count($imageIDs) > 1) {
                        $imageIDs = array_shift($imageIDs);
                        $payload['gallery_ids'] = $imageIDs;
                    }









                    $api_categories = unserialize($productList['api_categories']);

                    if(is_countable($api_categories) && count($api_categories) > 0){
                        $category_ids= array();
                        foreach ($api_categories as $category) {
                            if(isset($category['mappedCategoryId'])) {
                                $category_ids[] = $category['mappedCategoryId'];
                            }
                        }

                        if(is_countable($category_ids) && count($category_ids) > 0) {

                            $woocommerceProduct->set_category_ids($category_ids);
                        }
                    }

                    $woocommerceProduct->save();

                    $variables['api_websiteProductId'] = $result;
                    $variables['is_processed'] = '1';
                    $variables['last_processed_at'] = date('Y-m-d H:i:s');



                    if ($productList['api_id']) {
                        update_dropstore_with_product_id($result, $productList['api_id']);
                    }

                } else { //creating variable product
                    $img = '';

                    $payload = array(
                        'name' => $productList['api_title'],
                        'description' => $productList['api_description'],
                        'short_description' => $short_description,
                        'sku' => $productList['api_sku'],
                        'regular_price' => $productList['api_price'], // product price
                        'status' => ($productList['api_status'] == 'active' ? 'publish' : 'pending'),
                        'visibility' => ($productList['api_status'] == 'active' ? 'visible' : 'hidden'),
                        'manage_stock' => false,
                        'stock_qty' => $productList['api_quantity'],
                        'weight' => ($productList['api_weight'] ?? ''),
                        'length' => ($productList['api_dimensions']['length'] ?? ''),
                        'width' => ($productList['api_dimensions']['width'] ?? ''),
                        'height' => ($productList['api_dimensions']['height'] ?? '')
                    );


                    $variation_data = array();
                    $stockCount = 0;
                    foreach ($api_variants as $api_variant) {
                        $variation_data[] = $api_variant['title'];
                        $payload['variants'][] = array(
                            'title' => $api_variant['title'],
                            'sku' => $api_variant['sku'],
                            'regular_price' => $api_variant['price'],
                            'price' =>  $api_variant['price'],
                            'stock_qty' => $api_variant['quantity']
                        );
                        $stockCount += $api_variant['quantity'];
                    }

                    if($stockCount > 0) {
                        $payload['stock_status'] = 'instock';
                    }else{
                        $payload['stock_status'] = 'outofstock';
                    }
                    $payload['attributes']['variants'] = $variation_data;
                    $payload['attributes_label'] = implode(" , ", $variation_data);

                    $resultID = create_variable_product($payload);

                    $images = unserialize($productList['api_images']);
                    foreach ($images as $image) {
                        if ($image['src'] != '') {
                            if (strstr($image['src'], '?', true)) {
                                $file =  strstr($image['src'], '?', true);
                            } else {
                                $file =  $image['src'];
                            }

                            if ( 0 ==  does_file_exists( $file ) ) {
                                $imageIDs[] = setProductImage($resultID, $file);
                            }
                        }
                    }

                    if (is_countable($imageIDs) && count($imageIDs) > 0 && $imageIDs[0] != '') {
                        $payload['image_id'] = $imageIDs[0];
                    }
                    if (is_countable($imageIDs) && count($imageIDs) > 1) {
                        $payload['gallery_ids'] = array_shift($imageIDs);
                    }



                    //  $variation_data = array();

                    foreach ($api_variants as $api_variant) {
                        $sku = $api_variant['sku'];
                        create_product_variation($result, $api_variant['title'], $sku,$api_variant['price'], $api_variant['quantity']);
                    }

                    $variables['api_websiteProductId'] = $result;
                    $variables['is_processed'] = '1';
                    $variables['last_processed_at'] = date('Y-m-d H:i:s');

                    $wpdb->update($table_name, $variables, array('id' => $productList['id']));

                    $api_categories = unserialize($productList['api_categories']);

                    if(is_countable($api_categories) && count($api_categories) > 0){
                        $category_ids= array();
                        foreach ($api_categories as $category) {
                            if(isset($category['mappedCategoryId'])) {
                                $category_ids[] = $category['mappedCategoryId'];
                            }
                        }

                        if(is_countable($category_ids) && count($category_ids) > 0) {
                            $woocommerceProduct = new WC_Product_Variable($variables['api_websiteProductId']);

                            $woocommerceProduct->set_category_ids($category_ids);
                            $woocommerceProduct->save();
                        }
                    }

                    if ($productList['api_id']) {
                        update_dropstore_with_product_id($result, $productList['api_id']);

                    }

                }

            } else {//updating existing products

                $api_variants = unserialize($productList['api_variants']);
                $woocommerceProduct = new WC_Product($productList['api_websiteProductId']);

                if(!is_null($woocommerceProduct)) {
                    if (!is_countable($api_variants) || count($api_variants) == 0 || (count($api_variants) == 1 && ($api_variants[0]['title'] == 'Default' || $api_variants[0]['title'] == 'Default Title'))) {


                        $woocommerceProduct->set_backorders('no'); // 'yes', 'no' or 'notify'
                        $woocommerceProduct->set_stock_quantity($productList['api_quantity']);
                        $woocommerceProduct->set_manage_stock(true);
                        $woocommerceProduct->set_price($productList['api_price']);
                        $woocommerceProduct->set_regular_price($productList['api_price']);


                        //image update and upload
                        $dropstore_update_images_with_product_update = get_option('dropstore_update_images_with_product_update',
                            false);

                        if ($dropstore_update_images_with_product_update === true) {
                            $images = unserialize($productList['api_images']);
                            foreach ($images as $image) {
                                if ($image['src'] != '') {
                                    if (strstr($image['src'], '?', true)) {
                                        $file = strstr($image['src'], '?', true);
                                    } else {
                                        $file = $image['src'];
                                    }

                                    if (0 == does_file_exists($file)) {

                                        $imageIDs[] = setProductImage($productList['api_title'], $file);
                                    }
                                }
                            }
                            if (is_countable($imageIDs) && count($imageIDs) > 0 && $imageIDs[0] != '') {
                                $woocommerceProduct->set_image_id($imageIDs[0]);
                            }
                            if (is_countable($imageIDs) && count($imageIDs) > 1) {
                                $gallery_ids = array_shift($imageIDs);
                                $woocommerceProduct->set_gallery_image_ids($gallery_ids);
                            }

                        }
                        $woocommerceProduct->save();

                    } else {

                        foreach ($api_variants as $api_variant) {

                            $variant = $wpdb->get_var($wpdb->prepare("SELECT p.id FROM {$wpdb->prefix}postmeta as pm
        INNER JOIN {$wpdb->prefix}posts as p ON p.ID = pm.post_id
        WHERE p.post_type = 'product_variation'AND p.post_status = 'publish'AND p.post_parent = {$woocommerceProduct->get_id()} AND pm.meta_key = '_sku'AND pm.meta_value != '" . $api_variant['sku'] . "'"));

                            if (!is_null($variant)) {
                                $payload = array(
                                    'id' => $variant,
                                    'regular_price' => $api_variant['price'],
                                    'price' => $api_variant['price'],
                                    'stock_qty' => $api_variant['quantity']
                                );
                                update_variation($payload);
                            } else {
                                $sku = $api_variant['sku'];
                                create_product_variation($productList['api_websiteProductId'], $api_variant['title'],
                                    $sku, $api_variant['price'], $api_variant['quantity']);
                            }
                        }


                        //image update and upload
                        $dropstore_update_images_with_product_update = get_option('dropstore_update_images_with_product_update',
                            false);

                        if ($dropstore_update_images_with_product_update === true) {

                            $images = unserialize($productList['api_images']);
                            foreach ($images as $image) {
                                if ($image['src'] != '') {
                                    if (strstr($image['src'], '?', true)) {
                                        $file = strstr($image['src'], '?', true);
                                    } else {
                                        $file = $image['src'];
                                    }

                                    if (0 == does_file_exists($file)) {
                                        $imageIDs[] = setProductImage($productList['api_title'], $file);
                                    }
                                }
                            }
                            if (is_countable($imageIDs) && count($imageIDs) > 0 && $imageIDs[0] != '') {
                                $woocommerceProduct = new WC_Product_Variable($productList['api_websiteProductId']);
                                $woocommerceProduct->set_image_id($imageIDs[0]);

                                if (count($imageIDs) > 1) {
                                    $gallery_ids = array_shift($imageIDs);
                                    $woocommerceProduct->set_gallery_image_ids($gallery_ids);
                                }
                                $woocommerceProduct->save();
                            }
                        }

                    }
                }

                update_dropstore_with_product_id($productList['api_websiteProductId'] , $productList['api_id']);

            }
            $variables['is_processed'] = '1';
            $variables['last_processed_at'] = date('Y-m-d H:i:s');
            $wpdb->update($table_name, $variables, array('id' => $productList['id']));

        }
        update_option('dropstore_time_last_imported', date('Y-m-d H:i:s'));

    } catch (Exception $e) {
        $variables['api_status'] = 'deleted';
        $variables['is_processed'] = '1';
        $variables['last_processed_at'] = date('Y-m-d H:i:s');
        $wpdb->update($table_name, $variables, array('id' => $productList['id']));

        //  throw new Exception('Request failed. ' . $e->getMessage() . " - " . $e->getLine());

    }

}
*/

function download_and_attach_image_to_product($image_url, $product_id)
{
    require_once(ABSPATH . 'wp-admin/includes/file.php');
    require_once(ABSPATH . 'wp-admin/includes/media.php');
    require_once(ABSPATH . 'wp-admin/includes/image.php');

    // Download the image file
    $tmp = download_url($image_url);

    // Check for download errors
    if (is_wp_error($tmp)) {
        echo 'Failed to download the image: ' . $tmp->get_error_message();
        return null;
    }

    // Set the filename for the attachment
    $filename = basename($image_url);

    // Create an array of attachment data
    $file_array = array(
        'name' => $filename,
        'tmp_name' => $tmp
    );

    // Upload and attach the image to the media library
    $attachment_id = media_handle_sideload($file_array, $product_id);

    // Check for errors during sideloading
    if (is_wp_error($attachment_id)) {
        @unlink($file_array['tmp_name']); // Clean up the temporary file
        echo 'Failed to attach the image: ' . $attachment_id->get_error_message();
        return null;
    }

    // Set the product's featured image
    set_post_thumbnail($product_id, $attachment_id);
    return $attachment_id;
}


function setProductImage($product_id, $image_url){

    try {
        // Fetch the contents of the image
        $image_data = file_get_contents($image_url);

        if ($image_data) {
            // Use WordPress function to upload the image to the media library
            $upload = wp_upload_bits(basename($image_url), null, $image_data);

            // Check if the image was uploaded successfully
            if (!$upload['error']) {
                $file_path = $upload['file'];
                $file_name = basename($file_path);

                // Prepare the image data array for attachment
                $attachment = array(
                    'post_mime_type' => $upload['type'],
                    'post_parent' => $product_id, // Attach image to the product
                    'post_title' => preg_replace('/\.[^.]+$/', '', $file_name),
                    'post_content' => '',
                    'post_status' => 'inherit'
                );

                // Insert the attachment into the media library
                $attach_id = wp_insert_attachment($attachment, $file_path, $product_id);

                // Set the product image as the featured image (if needed)
                if ($attach_id) {
                    set_post_thumbnail($product_id, $attach_id);
                } else {
                    // Error handling for failed attachment insertion
                    echo 'Failed to insert attachment.';
                }

                return $attach_id;

            } else {
                // Error handling for failed image upload
                echo 'Failed to upload image.';
            }
        }
    }catch(Exception $e){
        throw $e;
    }
}


function downloadProductImage($product_id, $image_url, $unescape = false)
{
    $file = plugin_dir_path( __FILE__ ) . '/errors.log';
    $time = date("F jS Y - H:i");
    $ban = "[$time]\r\n";
    $newLine = '' . PHP_EOL;

    require_once(ABSPATH . 'wp-admin/includes/file.php');
    require_once(ABSPATH . 'wp-admin/includes/media.php');
    require_once(ABSPATH . 'wp-admin/includes/image.php');

    if($unescape){
        $image_url = stripslashes($image_url);
    }

    /*file_put_contents($file, $ban.$newLine, FILE_APPEND);
    file_put_contents($file, '[IMG-DL-URL] : ' . $image_url.$newLine, FILE_APPEND);*/

    // Download the image file
    $tmp = download_url($image_url);

    // Check for download errors
    if (is_wp_error($tmp)) {
        echo 'Failed to download the image: ' . $tmp->get_error_message();
        /*file_put_contents($file, '[IMG-DL-ERROR] : ' . $tmp->get_error_message().$newLine, FILE_APPEND);
        file_put_contents($file, $newLine.$newLine, FILE_APPEND);*/
        return null;
    }

    // Set the filename for the attachment
    $filename = basename($image_url);

    // Create an array of attachment data
    $file_array = array(
        'name' => $filename,
        'tmp_name' => $tmp
    );

    // Upload and attach the image to the media library
    $attachment_id = media_handle_sideload($file_array, $product_id);

    // Check for errors during sideloading
    if (is_wp_error($attachment_id)) {
        @unlink($file_array['tmp_name']); // Clean up the temporary file
        echo 'Failed to attach the image: ' . $attachment_id->get_error_message();
        /*file_put_contents($file, '[IMG-DL-ERROR] : ' . $attachment_id->get_error_message().$newLine, FILE_APPEND);
        file_put_contents($file, $newLine.$newLine, FILE_APPEND);*/
        return null;
    }

    // Set the product's featured image
    set_post_thumbnail($product_id, $attachment_id);
    return $attachment_id;
}

function get_attachment_by_filename($filename) : ?int {
    global $wpdb;
    $table = $wpdb->prefix . 'posts';

    $query = $wpdb->prepare(
        "SELECT ID FROM $table WHERE post_type = 'attachment' AND guid LIKE %s",
        '%' . $wpdb->esc_like($filename)
    );

    $attachment_id = $wpdb->get_var($query);

    if ($attachment_id) {
        return (int)$attachment_id;
    }
    return $attachment_id;
}

function check_attachment_exists_by_filename($filename): bool
{
    global $wpdb;
    $table = $wpdb->prefix . 'posts';

    $query = $wpdb->prepare(
        "SELECT ID FROM $table WHERE post_type = 'attachment' AND guid LIKE %s",
        '%' . $wpdb->esc_like($filename)
    );

    $attachment_id = $wpdb->get_var($query);

    if ($attachment_id) {
        return true;
    } else {
        return false;
    }
}

function does_file_exists($filename) {
    global $wpdb;
    $image_name = wp_basename($filename);
    return (int) $wpdb->get_var("SELECT COUNT(meta_id) FROM {$wpdb->postmeta} WHERE meta_value LIKE '%/".$image_name."%'");
}

add_action('dropstore_import_products_cron_hook', 'dropstore_import_products_cron_task');