<?php

ini_set('max_execution_time', 1200);

function dropstore_download_products_cron_schedule($schedules) {
    $schedules['10_minutes'] = array(
        'interval' => 60*10,
        'display' => __('10 Minutes')
    );
    $schedules['15_minutes'] = array(
        'interval' => 60*15,
        'display' => __('15 Minutes')
    );
    $schedules['30_minutes'] = array(
        'interval' => 60*30,
        'display' => __('30 Minutes')
    );
    $schedules['hourly'] = array(
        'interval' => 60*60*1,
        'display' => __('Hourly')
    );
    $schedules['2_hours'] = array(
        'interval' => 60*60*2,
        'display' => __('2 Hours')
    );
    $schedules['3_hours'] = array(
        'interval' => 60*60*3,
        'display' => __('3 Hours')
    );
    $schedules['4_hours'] = array(
        'interval' => 60*60*4,
        'display' => __('4 Hours')
    );
    $schedules['5_hours'] = array(
        'interval' => 60*60*5,
        'display' => __('5 Hours')
    );
    $schedules['6_hours'] = array(
        'interval' => 60*60*6,
        'display' => __('6 Hours')
    );
    $schedules['8_hours'] = array(
        'interval' => 60*60*8,
        'display' => __('8 Hours')
    );
    $schedules['12_hours'] = array(
        'interval' => 60*60*12,
        'display' => __('12 Hours')
    );
    $schedules['daily'] = array(
        'interval' => 60*60*24,
        'display' => __('Daily')
    );
    return $schedules;
}
add_filter('cron_schedules', 'dropstore_download_products_cron_schedule');

function dropstore_setup_download_products_cron_job($cron_hook) {
    if (wp_next_scheduled( $cron_hook )) {
        //clear previous settings
        wp_clear_scheduled_hook($cron_hook);
    }
    wp_schedule_single_event(time() + 60, $cron_hook);
}

function dropstore_download_products_cron_task($reset=false) {
    global $wpdb;
    $table_name = $wpdb->prefix . "dropstore_products";
    $data[] = '';

    $index = get_option('dropstore_download_products_index');
    if (!$index) {
        $index = 1;
    }

    try {
        $status = 'active';

        $products = dropstore_download_products_from_server($index, $status, $reset);

        $file = plugin_dir_path( __FILE__ ) . '/errors.log';
        $time = date("F jS Y - H:i");
        $ban = "[$time]\r\n";
        $newLine = '' . PHP_EOL;

        file_put_contents($file, $ban, FILE_APPEND);
        file_put_contents($file, $newLine, FILE_APPEND);
        file_put_contents($file, "[PRODUCT COUNT] - INDEX: (" . $index . ") - COUNT(" . count($products) . ")". $newLine, FILE_APPEND);
        file_put_contents($file, $newLine.$newLine, FILE_APPEND);

        foreach ($products as $product) {
            try {
                $websiteProductId = $product['websiteProductId'];

                $woocommerceProduct = null;
                if (!is_null($websiteProductId) && $websiteProductId != "") {
                    $woocommerceProduct = wc_get_product(intval($websiteProductId));
                }
                if (!$woocommerceProduct || !$woocommerceProduct->exists()) {
                    $woocommerceProduct = get_product_by_sku($product['sku']);
                }
                if ($woocommerceProduct){
                    if (!is_countable($product['variants']) || count($product['variants']) == 0 || (count($product['variants']) == 1 && ($product['variants'][0]['title'] == 'Default' || $product['variants'][0]['title'] == 'Default Title'))) {
                        //$woocommerceProduct = new WC_Product($woocommerceProduct->get_id());

                        $woocommerceProduct->set_backorders('no'); // 'yes', 'no' or 'notify'
                        $woocommerceProduct->set_stock_quantity($product['quantity']);
                        $woocommerceProduct->set_manage_stock(true);
                        $woocommerceProduct->set_price($product['price']);
                        $woocommerceProduct->set_regular_price($product['price']);
                        $woocommerceProduct->set_status('publish'); //Set product status.

                        $images = $product['images'];
                        $imageIDs = [];
                        foreach ($images as $image) {
                            if ($image['src'] != '') {
                                if (strstr($image['src'], '?', true)) {
                                    $file = strstr($image['src'], '?', true);
                                } else {
                                    $file = $image['src'];
                                }

                                if (check_attachment_exists_by_filename($file)) {
                                    $imageIDs[] = get_attachment_by_filename($file);
                                }else{
                                    $imgID = downloadProductImage($product['id'], $file);
                                    if (!is_null($imgID)){
                                        $imageIDs[] = $imgID;
                                    }else{
                                        $imgID = downloadProductImage($product['id'], $file, true);
                                        if (!is_null($imgID)){
                                            $imageIDs[] = $imgID;
                                        }
                                    }
                                }
                            }
                        }
                        if (isset($imageIDs) && is_countable($imageIDs) && count($imageIDs) > 0 && $imageIDs[0] != '') {
                            $woocommerceProduct->set_image_id($imageIDs[0]);
                        }
                        if (isset($imageIDs) && is_countable($imageIDs) && count($imageIDs) > 1) {
                            $imageIDs = array_shift($imageIDs);
                            $woocommerceProduct->set_gallery_image_ids($imageIDs);
                        }

                        $woocommerceProduct->save();
                    }else{
                        foreach ($product['variants'] as $productVariant){
                            $variant = $wpdb->get_var($wpdb->prepare("SELECT p.id FROM {$wpdb->prefix}postmeta as pm 
                    INNER JOIN {$wpdb->prefix}posts as p ON p.ID = pm.post_id 
                    WHERE p.post_type = 'product_variation'
                      AND p.post_status = 'publish'AND p.post_parent = {$woocommerceProduct->get_id()} 
                      AND pm.meta_key = '_sku'AND pm.meta_value != '".$productVariant['sku']."'"));

                            if (!is_null($variant)) {
                                $payload = array(
                                    'id' => $variant,
                                    'regular_price' => $productVariant['price'],
                                    'price' => $productVariant['price'],
                                    'stock_qty' => $productVariant['quantity']
                                );
                                update_variation($payload);
                            } else {
                                $sku = $productVariant['sku'];
                                create_product_variation($websiteProductId, $productVariant['title'], $sku, $productVariant['price'], $productVariant['quantity']);
                            }
                        }
                    }
                }else{
                    createNewProduct($product);
                }
            }catch (Exception $e){
                /*$file = plugin_dir_path( __FILE__ ) . '/errors.log';
                $time = date("F jS Y - H:i");
                $ban = "[$time]\r\n";
                $newLine = '' . PHP_EOL;

                file_put_contents($file, $ban, FILE_APPEND);
                file_put_contents($file, $newLine, FILE_APPEND);
                file_put_contents($file, json_encode($product, JSON_PRETTY_PRINT), FILE_APPEND);
                file_put_contents($file, $newLine, FILE_APPEND);
                file_put_contents($file, json_encode([
                    'message' => $e->getMessage(),
                    'trace' => $e->getTraceAsString()
                ], JSON_PRETTY_PRINT), FILE_APPEND);
                file_put_contents($file, $newLine, FILE_APPEND);
                file_put_contents($file, $newLine, FILE_APPEND);*/
            }
        }

        update_option('dropstore_time_last_downloaded', date('Y-m-d H:i:s'));
        $msg = 'Products are loading in the background';

        if(!empty($products)){
            $index++;
            update_option('dropstore_download_products_index', $index);
            dropstore_setup_download_products_cron_job('dropstore_download_products_cron_hook');
        }
    } catch (Exception $e) {
        if(!empty($products)){
            $index++;
            update_option('dropstore_download_products_index', $index);
            dropstore_setup_download_products_cron_job('dropstore_download_products_cron_hook');
        }
        $state = 'failed';
        $msg = $e->getMessage();
    }

    return $msg;
}
add_action( 'dropstore_download_products_cron_hook', 'dropstore_download_products_cron_task' );

