<?php
function dropstore_log_related_hooks()
{
    $dropstore_log_is_enabled = get_option('dropstore_log_is_enabled', '');
    if ('yes' == $dropstore_log_is_enabled) {
         //add_action( 'dropstore_download_products_from_server', 'dropstore_dropstore_download_products_from_server' );
    }
}//end dropstore_log_related_hooks
add_action('init', 'dropstore_log_related_hooks', 90);
function dropstore_dropstore_api_update_order($order, $api_results)
{

}

function dropstore_dropstore_api_create_order($order, $api_results)
{
    /*
    $refer = [
        'order' => $order,
        'api_results' => $api_results,
    ];
    $log_args = [
        'action' => 'dropstore_api_create_order',
        'result' => count($order) . ' items',
        'refer' => serialize($refer),
    ];
    dropstore_insert_cronjob_log($log_args);
    */
}

function dropstore_dropstore_untrash_product($post_id)
{
    $log_args = [
        'action' => 'dropstore_untrash_product',
        'result' => count($post_id) . ' items',
        'refer' => serialize($post_id),
    ];
    dropstore_insert_cronjob_log($log_args);
}

function dropstore_dropstore_trash_product($post_id)
{
    $log_args = [
        'action' => 'dropstore_trash_product',
        'result' => count($post_id) . ' items',
        'refer' => serialize($post_id),
    ];
    dropstore_insert_cronjob_log($log_args);
}

function dropstore_dropstore_product_was_deleted($post_id)
{
    $log_args = [
        'action' => 'dropstore_product_was_deleted',
        'result' => count($post_id) . ' items',
        'refer' => serialize($post_id),
    ];
    dropstore_insert_cronjob_log($log_args);
}

function dropstore_dropstore_api_update_product_log($args, $products)
{
    $refer = [
        'args' => $args,
        'products' => $products,
    ];
    $log_args = [
        'action' => 'dropstore_api_update_product',
        'result' => count($products) . ' items',
        'refer' => serialize($refer),
    ];
    dropstore_insert_cronjob_log($log_args);
}

function dropstore_dropstore_download_products_from_server()
{
    $log_args = [
        'action' => 'dropstore_download_products_from_server',
    ];
   // dropstore_insert_cronjob_log($log_args);
}

function dropstore_dropstore_download_image_and_save_to_media_library_error($download_files_info, $i_img)
{
    $refer = [
        'download_files_info' => $download_files_info,
        'i_img' => $i_img,
    ];
    $log_args = [
        'action' => 'dropstore_download_image_and_save_to_media_library_error',
        'result' => $download_files_info['error'],
        'refer' => serialize($refer),
    ];
    dropstore_insert_cronjob_log($log_args);
}

function dropstore_dropstore_get_product_images($item, $all_imgs)
{
    $refer = [
        'item' => $item,
        'all_imgs' => $all_imgs,
    ];
    $log_args = [
        'action' => 'dropstore_get_product_images',
        'result' => count($item) . ' items',
        'refer' => serialize($refer),
    ];
    dropstore_insert_cronjob_log($log_args);
}
