<?php
function dropstore_cronjob_log_init(){
    require_once dirname( __FILE__ ) . '/cronjob_log-functions.php';
    require_once dirname( __FILE__ ) . '/cronjob_log-db-functions.php';
    if(is_admin()){
        require_once dirname( __FILE__ ) . '/cronjob_log-wp-install.sql.php'; 
        require_once dirname( __FILE__ ) . '/admin/class-cronjob_log-list-table.php';
        require_once dirname( __FILE__ ) . '/admin/class-cronjob_log-form-handler.php';
        require_once dirname( __FILE__ ) . '/admin/class-cronjob_log.php'; 
    }
}//end dropstore_init

add_action('init','dropstore_cronjob_log_init',10);

function dropstore_cronjob_log_data_was_saved_successfully($insert_id,$fields)
{
    // your code here
}
add_action('cronjob_log_data_was_saved_successfully','dropstore_cronjob_log_data_was_saved_successfully',10,2);
