<?php
if( is_admin() ) {
    //dropstore_db_remove_cronjob_log_table();
    dropstore_db_install_cronjob_log_table();
}

function dropstore_db_install_cronjob_log_table()
{
    define('DROPSTORE_CRONJOB_LOG_DB_VERSION', '1.0');
    $dropstore_installed = get_option('dropstore_cronjob_log_db_version');
    if( $dropstore_installed != DROPSTORE_CRONJOB_LOG_DB_VERSION ) { 
        GLOBAL $wpdb;
        
        $wp_prefix = $wpdb->prefix;
        // This includes the dbDelta function from WordPress.
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        $create_cronjob_log_table = ("
CREATE TABLE `{$wp_prefix}dropstore_cronjob_log` (
    `id` int(11) UNSIGNED NOT NULL auto_increment,
     PRIMARY KEY  (`id`),

     `action` varchar(255) NOT NULL default '',
     `result` varchar(255) NOT NULL default '',
     `action_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
     `refer` text NOT NULL default ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;");
        
        // Create/update the plugin tables.
        dbDelta($create_cronjob_log_table);
        update_option('dropstore_cronjob_log_db_version', DROPSTORE_CRONJOB_LOG_DB_VERSION);
    }
}

function dropstore_db_remove_cronjob_log_table() {
    define('DROPSTORE_CRONJOB_LOG_DELETED_TABLE_VERSION', '1.0');
    $dropstore_cronjob_log_deleted = get_option('dropstore_cronjob_log_deleted_version');
    if( $dropstore_cronjob_log_deleted != DROPSTORE_CRONJOB_LOG_DELETED_TABLE_VERSION ) {
     global $wpdb;
     $table_name = $wpdb->prefix . "dropstore_cronjob_log";
     $sql = "DROP TABLE IF EXISTS $table_name;";
     $wpdb->query($sql);
        update_option('dropstore_cronjob_log_deleted_version', DROPSTORE_CRONJOB_LOG_DELETED_TABLE_VERSION);
    }
}