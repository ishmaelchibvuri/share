<div class="wrap">
    <h2><?php _e( 'Cronjob Log(all data in this page are safe to delete)', 'dropstore' ); ?></h2>
    <?php if (array_key_exists('error', $_GET)): ?>
        <div class="notice notice-error"><p><?php echo $_GET['error']; ?></p></div>
    <?php endif; ?>
    <?php if (array_key_exists('success', $_GET)): ?>
        <div class="notice notice-success"><p><?php echo $_GET['success']; ?></p></div>
    <?php endif; ?>
    <?php wp_nonce_field( 'dropstore_delete_log_ajax_nonce','_delete_log_ajax_nonce' ); ?>
    <a href="javascript:void(0);" id="delete-log" class="button button-default btn btn-default">Delete all log</a>
    <form method="post">
        <input type="hidden" name="page" value="ttest_list_table">

        <?php
        $list_table = new DropStore_Cronjob_log_List();
        $list_table->prepare_items();
        $list_table->search_box( 'search', 's' );
        $list_table->display();
        ?>
    </form>
</div>