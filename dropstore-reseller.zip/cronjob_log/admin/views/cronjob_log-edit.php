<?php 
$item = dropstore_get_cronjob_log_by_id( $id ); 
$submit_button_title=__( 'Update Cronjob Log', 'dropstore' );
$form_title=__( 'Edit Cronjob Log', 'dropstore' );

require dirname(__FILE__) . '/cronjob_log-form.php';
