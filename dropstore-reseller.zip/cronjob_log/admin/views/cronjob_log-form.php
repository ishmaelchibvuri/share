<div class="wrap">
    <h2><?php _e( $form_title, 'dropstore' ); ?></h2>
    <?php if (array_key_exists('error', $_GET)): ?>
        <div class="notice notice-error"><p><?php echo $_GET['error']; ?></p></div>
    <?php endif; ?>
    <?php if (array_key_exists('success', $_GET)): ?>
        <div class="notice notice-success"><p><?php echo $_GET['success']; ?></p></div>
    <?php endif; ?>

    <form action="" method="post">
        <?php
        echo dropstore_text('action','Action',$item->action,true); 
        echo dropstore_text('result','Result',$item->result,true); 
        echo dropstore_datetimepicker('action_time','Action time',$item->action_time,false); 
        echo dropstore_textarea('refer','Refer',$item->refer,false); 
        ?>
        <input type="hidden" name="field_id" value="<?php echo $item->id; ?>">

        <?php wp_nonce_field( 'dropstore_cronjob_log_nonce' ); ?>
        <?php submit_button( $submit_button_title, 'primary', 'submit_cronjob_log' ); ?>

    </form>
</div>