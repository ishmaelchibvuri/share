<?php 
$item=new stdClass();
$item->id=0;

$fields=array('action','result','action_time','refer');

foreach ($fields as $field) {
    if(isset($_GET[$field])){
        if(is_array($_GET[$field])){
            $item->$field=$_GET[$field];
        }else{
            $item->$field=urldecode($_GET[$field]);
        }
    }
}

$submit_button_title=__( 'Add New Cronjob Log', 'dropstore' );
$form_title=__( 'New Cronjob Log', 'dropstore' );

require dirname(__FILE__) . '/cronjob_log-form.php';
