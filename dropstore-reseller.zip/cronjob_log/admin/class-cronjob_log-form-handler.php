<?php

/**
 * Handle the form submissions
 *
 * @package Package
 * @subpackage Sub Package
 */
class DropStore_Cronjob_log_Form_Handler {

    /**
     * Hook 'em all
     */
    public function __construct() {
        add_action( 'admin_init', array( $this, 'handle_form' ) );
    }

    /**
     * Handle the cronjob_log new and edit form
     *
     * @return void
     */
    public function handle_form() {
        // echo '<div style="display1:none;"><pre>';
        // var_dump(__METHOD__);
        // echo '</pre></div>';
        // die();
        if ( ! isset( $_POST['submit_cronjob_log'] ) ) {
            return;
        }
        // echo '<div style="display1:none;"><pre>';
        // var_dump(__METHOD__);
        // echo '</pre></div>';
        // die();
        if ( ! wp_verify_nonce( $_POST['_wpnonce'], 'dropstore_cronjob_log_nonce' ) ) {
            die( __( 'Wrong nonce!', 'dropstore' ) );
        }

        if ( ! current_user_can( 'read' ) ) {
            wp_die( __( 'Permission Denied!', 'dropstore' ) );
        }

        $errors   = array();
        $page_url = admin_url( 'admin.php?page=dropstore-cronjob_log' );
        $field_id = isset( $_POST['field_id'] ) ? intval( $_POST['field_id'] ) : 0;

        // $clicks = isset( $_POST['clicks'] ) ? sanitize_text_field( $_POST['clicks'] ) : '';
        $action = isset( $_POST['action'] ) ? sanitize_text_field( $_POST['action'] ) : '';
        $result = isset( $_POST['result'] ) ? sanitize_text_field( $_POST['result'] ) : '';
        $action_time = isset( $_POST['action_time'] ) ? sanitize_text_field( $_POST['action_time'] ) : '';
        $refer = isset( $_POST['refer'] ) ? sanitize_text_field( $_POST['refer'] ) : '';
        // some basic validation
        // if ( ! $clicks ) {
        //     $errors[] = __( 'Error: Clicks is required', 'dropstore' );
        // }

        if (empty($action) ) {
            $errors[] = __( 'Error: Action is required', 'dropstore' );
        }
        if (empty($result) ) {
            $errors[] = __( 'Error: Result is required', 'dropstore' );
        }
        // if (empty($action_time) ) {
        //     $errors[] = __( 'Error: Action Time is required', 'dropstore' );
        // }
        // if (empty($refer) ) {
        //     $errors[] = __( 'Error: Refer is required', 'dropstore' );
        // }

        $fields = array(
            'action' => $action,
            'result' => $result,
            // 'action_time' => $action_time,
            // 'refer' => $refer,
        );
        // bail out if error found
        if ( $errors ) {
            $first_error = reset( $errors );
            if(empty($field_id)){
                $query_arg=$fields + array( 'error' => urlencode($first_error), 'action' =>'new' ); 
                $redirect_to = add_query_arg($query_arg, $page_url );
            }else{
                $query_arg=$fields + array( 'error' => urlencode($first_error), 'action' =>'edit','id'=>$field_id ); 
                $redirect_to = add_query_arg($query_arg, $page_url );
            }
            wp_safe_redirect( $redirect_to );
            exit;
        }

        // New or edit?
        if ( ! $field_id ) {

            $insert_id = dropstore_insert_cronjob_log( $fields );

        } else {

            $fields['id'] = $field_id;

            $insert_id = dropstore_insert_cronjob_log( $fields );
        }

        if ( is_wp_error( $insert_id ) ) {
            $redirect_to = add_query_arg(
                array( 'error' => urlencode($insert_id->get_error_message()) ),
                $page_url
            );
        } else {
            do_action('cronjob_log_data_was_saved_successfully',$insert_id,$fields);
            $redirect_to = add_query_arg(
                array( 'success' => urlencode(__( 'Succesfully saved!', 'dropstore' )) ),
                $page_url
            );
        }

        wp_safe_redirect( $redirect_to );
        exit;
    }
}

new DropStore_Cronjob_log_Form_Handler();