<?php
function dropstore_get_all_cronjob_log( $args = array(), $fields=array() ) {
    global $wpdb;

    $defaults = array(
        'offset'     => 0,
        'number'     => 20,
        'where'      => array(),
        'orderby'    => 'id',
        'order'      => 'DESC',
        'groupby'    => '',
    );

    $args      = wp_parse_args( $args, $defaults );
    $_cache_key=dropstore_cache_key($args);
    $cache_key = 'cronjob_log-all' . $_cache_key . $args['offset'] . '-' . $args['number'];
    $items     = wp_cache_get( $cache_key, 'dropstore' );
    $where = dropstore_get_where($args['where']);
    $fields_line=dropstore_get_fields_line($fields);

    if ( false === $items ) {
        $sql='SELECT ' . $fields_line . ' FROM ' .   $wpdb->prefix . "dropstore_cronjob_log" . $where .' ORDER BY ' . $args['orderby'] .' ' . $args['order'] .' LIMIT ' . $args['offset'] . ', ' . $args['number'];
        if(!empty($args['groupby'])){
            $sql='SELECT ' . $fields_line . ' FROM ' .   $wpdb->prefix . "dropstore_cronjob_log" . $where 
                . ' GROUP BY '. $args['groupby'] .' ORDER BY ' . $args['orderby'] .' ' . $args['order']  .' LIMIT ' . $args['offset'] . ', ' . $args['number'];
        }
        $items = $wpdb->get_results($sql);

        wp_cache_set( $cache_key, $items, 'dropstore' );
    }

    return $items;
}

function dropstore_get_cronjob_log_count($args=array()) {
    global $wpdb;
    $where = dropstore_get_where($args['where']);
    return (int) $wpdb->get_var( "SELECT COUNT(id) FROM " .   $wpdb->prefix . "dropstore_cronjob_log" . $where);
}

function dropstore_get_cronjob_log_by_id( $id = 0, $fields=array()  ) {
    global $wpdb;

    $fields_line=dropstore_get_fields_line($fields);
    return $wpdb->get_row( $wpdb->prepare( "SELECT " . $fields_line . " FROM " .   $wpdb->prefix . "dropstore_cronjob_log" . " WHERE id = %d", $id ) );
}

function dropstore_update_cronjob_log_by_vars_where($vars=array(),$where=array()) {
    if(empty($vars)){
        return false;
    }

    global $wpdb;
    $table_prefix=$wpdb->prefix;

    $set_vars=array();
    foreach ($vars as $key => $value) {
        $set_vars[]=sprintf("`%s`='%s'",$key,esc_sql($value));
    }
    $set_vars_line=' SET ' . implode(',',$set_vars) . ' ';

    $where = dropstore_get_where($where);
    if(!empty($where)){
        $sql="UPDATE  " .  $wpdb->prefix . "dropstore_cronjob_log" . $set_vars_line . $where;
        $result = $wpdb->query($sql);
        return $result;
    }
    return false;
}

function dropstore_delete_cronjob_log($args=array()) {
    global $wpdb;
    $where = dropstore_get_where($args['where']);
    $result=false;
    if(!empty($where)){
        $result = $wpdb->query("DELETE FROM " .  $wpdb->prefix . "dropstore_cronjob_log" . $where);
    }
    return $result;
}

function dropstore_delete_cronjob_log_by_id($id = 0) {
    global $wpdb;
    $table_prefix=$wpdb->prefix;
    $result = $wpdb->query($wpdb->prepare("DELETE FROM " .  $wpdb->prefix . "dropstore_cronjob_log" . " WHERE  id = %d", $id ));
    return $result;
}

function dropstore_insert_cronjob_log( $args = array() ) {
    global $wpdb;

    $defaults = array(
        'id' => '',
//        'created_at' => '',
//        'updated_at' => '',
        'action' => '',
        'result' => '',
        'action_time' => current_time('mysql'),
        'refer' => '',
    );

    $args       = wp_parse_args( $args, $defaults );
    $table_name =   $wpdb->prefix . "dropstore_cronjob_log";

    // some basic validation
    // if ( empty( $args['cronjob_log_name'] ) ) {
    //     return new WP_Error( 'no-cronjob_log_name', __( 'No Campaign Name provided.', 'dropstore' ) );
    // }

    // if ( empty( $args['cp_url'] ) ) {
    //     return new WP_Error( 'no-cp_url', __( 'No Campaign Url provided.', 'dropstore' ) );
    // }
    // remove row id to determine if new or update
    $row_id = (int) $args['id'];
    unset( $args['id'] );

    if ( ! $row_id ) {

        // insert a new
        if ( $wpdb->insert( $table_name, $args ) ) {
            return $wpdb->insert_id;
        }

    } else {

        // do update method here
        $wpdb->update( $table_name, $args, array( 'id' => $row_id ) );
        return $row_id;
    }

    return false;
}