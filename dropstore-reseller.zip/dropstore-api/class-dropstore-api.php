<?php
class Dropstore_API {
    /**
     * @var mixed
     */
    private $access_token;
    /**
     * @var mixed
     */
    private $endpoint;

    public function __construct($args=array()) {
        $defaults = array(
            'endpoint' => 'https://api-backend.dropstore.co.za/source/woocommerce/merchant/webhook/',
            'access_token' => '',
        );

        $args = array_merge($defaults, $args );
        foreach ($args as $key => $value) {
            $this->key=$value;
        }

        //please update this if you don't use 'endpoint' as your target url
        $this->endpoint = $args['endpoint'];
        $this->access_token = $args['access_token'];
    }

    public function get_products($args) {
        $body=array();
        //$resource=sprintf('products/%s',$this->access_token);
        if(!empty($args['page_index'])){
            $resource=sprintf('products/%s',$args['page_index']);
        }

        //?status=deleted
        if(!empty($args['status'])){
            $resource .=sprintf('?status=%s', $args['status']);
        }
        return $this->request($resource,$body,'GET');
    }

    public function update_product($id,$body) {
        //  $resource=sprintf('product/website-product-id/%s/%s', $id, $this->access_token);
        //  return $this->request($resource,$body,'PUT');
    }


    // public function delete_product($args) {
    //     $body=array();
    //     return $this->request('product/delete/',$body,'POST');
    // }
/*
    public function create_order($order) {
        $body=$order;
        $resource=sprintf('order/create/%s',$this->access_token);
        return $this->request($resource,$body,'POST');
    }

    public function update_order($order) {
        $body=$order;
        $resource=sprintf('order/update/%s',$this->access_token);
        return $this->request($resource,$body,'PUT');
    }
*/
    public function request( $resource, $body, $method = 'POST', $options = array() ) {
        // set default options
        $timeout=0.6 * ini_get('max_execution_time');
        if(empty($timeout)){
            $timeout=60;
        }
        $options = wp_parse_args( $options, array(
            'method'  => $method,
            'timeout' => $timeout,
            'body'    => in_array( $method, array( 'GET') ) ? null : json_encode( $body ),
            'headers' => array(),
            // 'sslverify' => false,
        ) );

        // set default header options
        $options['headers'] = wp_parse_args( $options['headers'], array(
            'Content-Type' => 'application/json; charset=UTF-8',
            'X-Dropstore-Access-Token' => $this->access_token
        ) );

        // WP docs say method should be uppercase
        $options['method'] = strtoupper( $options['method'] );

        $url  = $this->endpoint . $resource;
        $result = wp_remote_request( $url, $options );

        if ( is_wp_error( $result ) ) {
            throw new Exception( 'Request failed. '. $result->get_error_message() );
        }elseif($result['response']['code'] != 200){
            throw new Exception( sprintf( '%s: %s', $result['response']['code'], $result['response']['message'] ) );
        }

        return json_decode( $result['body'], true );
    }

    function init()
    {

    }

}
