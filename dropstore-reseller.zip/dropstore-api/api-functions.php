<?php
function dropstore_get_api()
{
    $access_token = get_option('dropstore_access_token');
    $time_last_imported = get_option('dropstore_time_last_imported');
    require_once __DIR__ . '/class-dropstore-api.php';
    $args = [
        'access_token' => $access_token,
    ];
    return new Dropstore_API($args);
}

function dropstore_get_api_product_fields()
{
    $fields = [
        'id',
        'productName',
        'websiteProductId',
        'title',
        'sku',
        'description',
        'merchantWebsiteCategory',
        'price',
        'costPrice',
        'quantity',
        'timeCreated',
        'timeModified',
        'markupPercentage',
        'tags',
        'variants'
    ];
    return $fields;
}

function dropstore_download_products_from_server($page_index = 1, $status = 'any'/*active, deleted*/, $reset = false)
{

    $api = dropstore_get_api();
    $access_token = get_option('dropstore_access_token');

    if (!empty($api)) {

        $url = 'https://api-backend.dropstore.co.za/api/v2/merchant/products/'. $page_index . '?status=' . $status;

        try {
            $args = array(
                'method'  => 'GET',
                'timeout' => 600,
                'headers' => [
                    'Content-Type' => 'application/json; charset=utf-8',
                    'X-Dropstore-Access-Token' => $access_token
                ]
            );


            $result =  wp_remote_get($url, $args);
            return json_decode( $result['body'], true );

        } catch (Exception $e) {
            return [];
        }
    }

    return false;
}

function dropstore_dropstore_api_update_product($post_id, $status = '')
{
    $fields = ['api_id', 'api_websiteProductId', 'api_status'];
    $saved_args = [
        'api_websiteProductId' => $post_id
    ];

    $prods = dropstore_get_all_products($saved_args, $fields);
    if (!isset($prods[0])) {
        return false;
    }

    $api = dropstore_get_api();
    if (!empty($api)) {
        $args = [
            "websiteProductId" => $prods[0]->api_websiteProductId
        ];

        $products = $api->update_product($post_id, $args['websiteProductId']);
        do_action('dropstore_api_update_product', $args, $products);

        return $products;
    }
}

function update_dropstore_with_product_id($woocommerceProductId, $merchantProductId)
{
    $access_token = get_option('dropstore_access_token');
    $body = array("websiteProductId" => $woocommerceProductId);

    //The URL that we want to send a PUT request to.
    $url = 'https://api-backend.dropstore.co.za/api/v2/merchant/product/website-product-id/' . $merchantProductId;

    try {
        $args = array(
            'method' => 'PUT',
            'body' => json_encode($body),
            'timeout' => 600,
            'headers' => array( 'X-Dropstore-Access-Token' => $access_token)
        );

        $response = wp_remote_request($url, $args);
        return $response;

    } catch (Exception $e) {
        return $e->getMessage();
    }

}


function push_category_to_dropstore($categoryId, $categoryName)
{
    $access_token = get_option('dropstore_access_token');
    $body = array("id" => $categoryId, 'name' => $categoryName);
    //The URL that we want to send a PUT request to.
    $url = 'https://api-backend.dropstore.co.za/api/v2/merchant/category/create';

    try {
        $args = array(
            'method' => 'POST',
            'body' => json_encode($body),
            'timeout' => 600,
            'headers' => array( 'X-Dropstore-Access-Token' => $access_token)
        );

        $response = wp_remote_request($url, $args);
        return $response;

    } catch (Exception $e) {
        return $e->getMessage();
    }

}

add_action('dropstore_product_was_deleted', 'dropstore_dropstore_api_update_product');
add_action('dropstore_trash_product', 'dropstore_dropstore_api_update_product');