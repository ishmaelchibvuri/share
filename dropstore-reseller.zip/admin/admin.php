<?php 
require_once dirname(__FILE__) . '/admin-functions.php';
require_once dirname(__FILE__) . '/class-settings.php';

require_once DROPSTORE_DIR . '/admin/ajax/download_products/download_products.php';
require_once DROPSTORE_DIR . '/admin/ajax/import_products/import_products.php';
require_once DROPSTORE_DIR . '/admin/ajax/save_main_settings/save_main_settings.php';
require_once DROPSTORE_DIR . '/admin/ajax/delete_log/delete_log.php';
require_once DROPSTORE_DIR . '/admin/ajax/download_deleted_products/download_deleted_products.php';

require_once DROPSTORE_DIR . '/admin/ajax/pull_products_from_dropstore/pull_products_from_dropstore.php';
require_once DROPSTORE_DIR . '/admin/ajax/pull_images_from_source/pull_images_from_source.php';
