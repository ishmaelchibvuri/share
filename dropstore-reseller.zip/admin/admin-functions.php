<?php
add_action( 'dropstore_products_tablenav', 'dropstore_dropstore_products_tablenav' );    
function dropstore_dropstore_products_tablenav( $which ) {
    global $current_screen;
    if( strpos($current_screen->id,'toplevel_page_dropstore-products') !== false && 'top' === $which){
        ?>
        <?php wp_nonce_field( 'dropstore_pull_products_nonce','pull_products_nonce'); ?>
        <div class="alignleft actions custom pull-products-button-wrapper">
            <a href="javascript:void(0);" style="display: none;" class="button" id="pull-products-button" data-task="pull_products"><?php
                echo __( 'Pull Products Data From Dropstore', 'dropstore' ); ?></a>
            <a href="javascript:void(0);" class="button" id="import_products-button" data-task="sync_products"><?php
                echo __( 'Create/Update Woocommerce Product', 'dropstore' ); ?></a>
            <a href="javascript:void(0);" class="button" id="push-categories-button" data-task="pull_products"><?php
                echo __( 'Push Categories to Dropstore', 'dropstore' ); ?>
            </a>
        </div>
        <?php
    }
}

