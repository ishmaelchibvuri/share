<?php
function dropstore_download_deleted_products_ajax_admin_fun(){
    $state='success';
    $msg='It is success';
    $data='';
    try {
        $cronjob=$_POST['cronjob'];
        $_wpnonce=$_POST['_wpnonce'];
        $_wp_http_referer=$_POST['_wp_http_referer'];


        // $msg='Loaded successfully!';
        $all_results=dropstore_download_deleted_products_cron_task();
        $results=$all_results['downloaded_deleted'];
        if(isset($results['downloaded'])){
            foreach ($results['downloaded'] as $ids) {
                if(!empty($ids)){
                    $downloaded +=count($ids);
                }
            }
        }

        $msg='Success! ' . sprintf('downloaded: %s',$downloaded);// "cronjob: $cronjob, result: " . count($results) . ' items were downloaded';

        //do something here
    } catch (Exception $e) {
        $state='failed';
        $msg=$e->getMessage();
    }

    $return=array('state'=>$state,'msg'=>$msg,'data'=>$data);
    echo json_encode($return);
    die();
}

add_action("wp_ajax_dropstore_download_deleted_products_ajax_admin_fun","dropstore_download_deleted_products_ajax_admin_fun");
// add_action("wp_ajax_nopriv_dropstore_download_deleted_products_ajax_admin_fun","dropstore_download_deleted_products_ajax_admin_fun");

function dropstore_download_deleted_products_ajax_js($hook) {
    //please make sure the $hook is correct by uncomment following statement to check it,
    // var_dump($hook);die();
    if( strpos($hook,'dropstore_page_dropstore_settings') !== false){
        wp_enqueue_script( 'dropstore_download_deleted_products_ajax_js', plugins_url('/download_deleted_products.js', __FILE__),array('jquery'),1.0 );
        wp_register_script('dropstore-jquery-ba-throttle-debounce-min', DROPSTORE_URL . 'assets/lib/jquery/jquery.ba-throttle-debounce.min.js', array('jquery'), '1.0', true);
        /* you can use following enqueue in a shortcode to load as required */ 
        wp_enqueue_script('dropstore-jquery-ba-throttle-debounce-min');
    }
}
add_action( 'admin_enqueue_scripts', 'dropstore_download_deleted_products_ajax_js' );
