<?php
function dropstore_import_products_ajax_admin_fun(){
    $state='success';
    $msg='It is success';
    $data='';
    try {
        $cronjob=$_POST['cronjob'];
        $_wpnonce=$_POST['_wpnonce'];
        $_wp_http_referer=$_POST['_wp_http_referer'];

            $results=dropstore_import_products_cron_task();
            $msg='Success!';

        //do something here
    } catch (Exception $e) {
        $state='failed';
        $msg=$e->getMessage();
    }

    $return=array('state'=>$state,'msg'=>$msg,'data'=>$data);
    echo json_encode($return);
    die();
}

add_action("wp_ajax_dropstore_import_products_ajax_admin_fun","dropstore_import_products_ajax_admin_fun");
// add_action("wp_ajax_nopriv_dropstore_import_products_ajax_admin_fun","dropstore_import_products_ajax_admin_fun");

function dropstore_import_products_ajax_js($hook) {
    //please make sure the $hook is correct by uncomment following statement to check it,
    // var_dump($hook);die();
    if( strpos($hook,'dropstore_page_dropstore_settings') !== false){
        wp_enqueue_script( 'dropstore_import_products_ajax_js', plugins_url('/import_products.js', __FILE__),array('jquery'),1.0 );
        wp_register_script('dropstore-jquery-ba-throttle-debounce-min', DROPSTORE_URL . 'assets/lib/jquery/jquery.ba-throttle-debounce.min.js', array('jquery'), '1.0', true);
        /* you can use following enqueue in a shortcode to load as required */ 
        wp_enqueue_script('dropstore-jquery-ba-throttle-debounce-min');
    }
}
add_action( 'admin_enqueue_scripts', 'dropstore_import_products_ajax_js' );
