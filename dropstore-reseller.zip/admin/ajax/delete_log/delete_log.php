<?php
function dropstore_delete_log_ajax_admin_fun(){
    $state='success';
    $msg='It is success';
    $data='';
    try {
        $task=$_POST['task'];
        $_wpnonce=$_POST['_wpnonce'];
        $_wp_http_referer=$_POST['_wp_http_referer'];

            $args['where']=[
                'id'=>'>=0'
            ];
            $result=dropstore_delete_cronjob_log($args);
            // $msg='Loaded successfully!';
            $msg='Success! ' . "task: $task, delete: $result items";

        //do something here
    } catch (Exception $e) {
        $state='failed';
        $msg=$e->getMessage();
    }

    $return=array('state'=>$state,'msg'=>$msg,'data'=>$data);
    echo json_encode($return);
    die();
}

add_action("wp_ajax_dropstore_delete_log_ajax_admin_fun","dropstore_delete_log_ajax_admin_fun");
// add_action("wp_ajax_nopriv_dropstore_delete_log_ajax_admin_fun","dropstore_delete_log_ajax_admin_fun");

function dropstore_delete_log_ajax_js($hook) {
    //please make sure the $hook is correct by uncomment following statement to check it,
    // var_dump($hook);die();
    if( strpos($hook,'dropstore_page_dropstore-cronjob_log') !== false){
        wp_enqueue_script( 'dropstore_delete_log_ajax_js', plugins_url('/delete_log.js', __FILE__),array('jquery'),1.0 );
        wp_register_script('dropstore-jquery-ba-throttle-debounce-min', DROPSTORE_URL . 'assets/lib/jquery/jquery.ba-throttle-debounce.min.js', array('jquery'), '1.0', true);
        /* you can use following enqueue in a shortcode to load as required */ 
        wp_enqueue_script('dropstore-jquery-ba-throttle-debounce-min');
    }
}
add_action( 'admin_enqueue_scripts', 'dropstore_delete_log_ajax_js' );
