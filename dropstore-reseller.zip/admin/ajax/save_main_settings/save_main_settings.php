<?php
function dropstore_save_main_settings_ajax_admin_fun(){
    $state='success';
    $msg='It is success';
    $data='';
    try {
        $access_token=$_POST['access_token'];
        $download_import_interval=$_POST['download_import_interval'];
        $_wpnonce=$_POST['_wpnonce'];
        $_wp_http_referer=$_POST['_wp_http_referer'];

            // $msg='Loaded successfully!';
            if(empty($access_token)){
                $state='failed';
                $msg='Error: Access Token is empty';
            }else{
                $result=dropstore_save_main_settings($access_token);
                if($result){
                    $msg='Success! ' . "access_token: " . $access_token;
                    $data=['redirect_to_url'=>admin_url('admin.php?page=dropstore-setup&step=confirm')];
                }else{
                    $state='failed';
                    $msg='Error: Something is wrong';
                }
            }
       // dropstore_import_products_cron_task();
        //do something here
    } catch (Exception $e) {
        $state='failed';
        if($e->getCode() == 500 || $e->getCode() == 501 || $e->getCode() == 502){
            $msg = "There was an error on your hosting server allocated memory which is preventing this process from completing. You can find more information in your Woocommerce error log";
        }else {
            $msg = $e->getMessage();
        }
    }

    $return=array('state'=>$state,'msg'=>$msg,'data'=>$data);
    echo json_encode($return);
    die();
}

add_action("wp_ajax_dropstore_save_main_settings_ajax_admin_fun","dropstore_save_main_settings_ajax_admin_fun");
// add_action("wp_ajax_nopriv_dropstore_save_main_settings_ajax_admin_fun","dropstore_save_main_settings_ajax_admin_fun");

function dropstore_save_main_settings_ajax_js($hook) {
    //please make sure the $hook is correct by uncomment following statement to check it,
    var_dump($hook);die();
    if( strpos($hook,'page_cms90_northstar_newbook_settings') !== false){
        wp_enqueue_script( 'dropstore_save_main_settings_ajax_js', plugins_url('/save_main_settings.js', __FILE__),array('jquery'),1.0 );
        wp_register_script('dropstore-jquery-ba-throttle-debounce-min', DROPSTORE_URL . 'assets/lib/jquery/jquery.ba-throttle-debounce.min.js', array('jquery'), '1.0', true);
        /* you can use following enqueue in a shortcode to load as required */ 
        wp_enqueue_script('dropstore-jquery-ba-throttle-debounce-min');
    }
}
// add_action( 'admin_enqueue_scripts', 'dropstore_save_main_settings_ajax_js' );
