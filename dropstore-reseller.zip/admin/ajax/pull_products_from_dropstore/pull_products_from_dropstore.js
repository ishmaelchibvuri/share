function event_process(event){
    var wpnonce=encodeURIComponent($("[name='pull_products_nonce']").val());
    var wp_http_referer=encodeURIComponent($("[name='_wp_http_referer']").val());
    var task=encodeURIComponent($(this).data('task'));

    var post_data="task="+ task;
    post_data=post_data + "&_wpnonce="+ wpnonce;
    post_data=post_data + "&_wp_http_referer="+ wp_http_referer;

    var result_area=$(this);//note if you change something here, please update $("#pull-products-button").on('pull_products_from_dropstore_received',function(evt,res){ as well
    ajax_call_pull_products_from_dropstore(result_area,post_data);
    event.preventDefault();
}

function import_process(event){
    var wpnonce=encodeURIComponent($("[name='_wpnonce']").val());
    var wp_http_referer=encodeURIComponent($("[name='_wp_http_referer']").val());
    var cronjob=encodeURIComponent($(this).data('cronjob'));

    var post_data="cronjob="+ cronjob;
    post_data=post_data + "&_wpnonce="+ wpnonce;
    post_data=post_data + "&_wp_http_referer="+ wp_http_referer;

    var result_area=$(this);//note if you change something here, please update $("#import_products").on('import_products_received',function(evt,res){ as well
    ajax_call_import_products(result_area,post_data);
    event.preventDefault();
}

function event_push_categories(event){
    var wpnonce=encodeURIComponent($("[name='push_category_nonce']").val());
    var wp_http_referer=encodeURIComponent($("[name='_wp_http_referer']").val());
    var cronjob=encodeURIComponent($(this).data('cronjob'));

    var post_data="cronjob="+ cronjob;
    post_data=post_data + "&_wpnonce="+ wpnonce;
    post_data=post_data + "&_wp_http_referer="+ wp_http_referer;

    var result_area=$(this);//note if you change something here, please update $("#import_products").on('import_products_received',function(evt,res){ as well
    ajax_call_push_categories_to_dropstore(result_area,post_data);
    event.preventDefault();
}

function ajax_call_pull_products_from_dropstore(ajax_ele,post_data){
    $.ajax({
        type:"POST",
        data:post_data + "&action=dropstore_pull_products_from_dropstore_ajax_admin_fun",
        url:ajaxurl,
        datatype:'json',
        beforeSend:function(){
            pull_products_from_dropstore_updateTips(ajax_ele,'Fetching Products...','ajax-going','color:#000');
        },
        success:function(res){
            console.log(res);
            res=$.parseJSON(res);
            if('success' == res.state){
                pull_products_from_dropstore_updateTips(ajax_ele,res.msg,'ajax-success','color:#0073AA');
                var data=res.data;
                $(ajax_ele).trigger('pull_products_from_dropstore_received',res);
                window.location.reload();
            }else{
                pull_products_from_dropstore_updateTips(ajax_ele,res.msg,'ajax-no-match','color:#f00');
            }
        },
        error: function(res, textStatus, errorThrown){
            console.log(res);
            pull_products_from_dropstore_updateTips(ajax_ele,res.status + ' ' + res.statusText,'ajax-no-match','color:#f00');
        }
    });
}


function pull_products_from_dropstore_updateTips(lead_ele,ele_msg,ele_class,ele_style){
    ele_tips=$(lead_ele).parent().find('.pull_products_from_dropstore_msg-tips');
    if ($(ele_tips).length > 0) {
        $(ele_tips).html(ele_msg);
        $(ele_tips).attr('style',ele_style);
    }else{
        $(lead_ele).after('<span class="pull_products_from_dropstore_msg-tips" class="' + ele_class + '" style="'+ ele_style +'">' + ele_msg +'</span>');
    }
}

function ajax_call_import_products(ajax_ele,post_data){
    $.ajax({
        type:"POST",
        data:post_data + "&action=dropstore_import_products_ajax_admin_fun",
        url:ajaxurl,
        datatype:'json',
        beforeSend:function(){
            import_products_updateTips(ajax_ele,'Processing, please wait for this process to finish...','ajax-going','color:#000');
        },
        success:function(res){
            // console.log(res);
            res=$.parseJSON(res);
            if('success' == res.state){
                import_products_updateTips(ajax_ele,res.msg,'ajax-success','color:#0073AA');
                var data=res.data;
                $(ajax_ele).trigger('import_products_received',res);
                window.location.reload();
            }else{
                import_products_updateTips(ajax_ele,res.msg,'ajax-no-match','color:#f00');
            }
        },
        error: function(res, textStatus, errorThrown){
            // console.log(res);
            import_products_updateTips(ajax_ele,res.status + ' ' + res.statusText,'ajax-no-match','color:#f00');
        }
    });
}

function import_products_updateTips(lead_ele,ele_msg,ele_class,ele_style){
    ele_tips=$(lead_ele).parent().find('.import_products_msg-tips');
    if ($(ele_tips).length > 0) {
        $(ele_tips).html(ele_msg);
        $(ele_tips).attr('style',ele_style);
    }else{
        $(lead_ele).after('<span class="import_products_msg-tips" class="' + ele_class + '" style="'+ ele_style +'">' + ele_msg +'</span>');
    }
}

function ajax_call_push_categories_to_dropstore(ajax_ele,post_data){
    $.ajax({
        type: "POST",
        data: post_data + "&action=dropstore_push_categories_to_dropstore_ajax_admin_fun",
        url: ajaxurl,
        datatype: 'json',
        beforeSend:function(){
            swal.fire({
                backdrop: true,
                allowOutsideClick: false,
                allowEscapeKey: false,
                html:
                    '<div>' +
                    '<p class="pl-3 pr-3"><strong>Pushing categories to Dropstore, Please wait</strong>' +
                    '</p>' +
                    '</div>' +
                    '<div class="spinner-border mt-3 mb-2" style="width: 3rem; height: 3rem;" role="status">' +
                    '<span class="sr-only">Loading...</span>' +
                    '</div>',
                showCloseButton: false,
                showCancelButton: false,
                showConfirmButton: false,
                focusConfirm: false,
            });
        },
        success:function(res){
            res = JSON.parse(res);
            if(res.msg.toLowerCase() === 'success'){
                Swal.fire({
                    html: '<div class="mt-3">' +
                        '<lord-icon src="https://cdn.lordicon.com/lupuorrc.json" trigger="loop" colors="primary:#0ab39c,secondary:#405189" style="width:120px;height:120px"></lord-icon>' +
                        '<div class="mt-4 pt-2 fs-15">' +
                        '<h4>Well done !</h4>' +
                        '<p class="text-success text-muted mx-4 mb-0">Categories pushed to Dropstore successfully.</p>' +
                        '</div>' +
                        '</div>',
                    showCancelButton: true,
                    showConfirmButton: false,
                    cancelButtonClass: 'btn btn-primary w-xs mb-1',
                    cancelButtonText: 'Back',
                    buttonsStyling: false,
                    showCloseButton: true
                });
            }else{
                Swal.fire({
                    html: '<div class="mt-3">' +
                        '<lord-icon src="https://cdn.lordicon.com/tdrtiskw.json" trigger="loop" colors="primary:#f06548,secondary:#f7b84b" style="width:120px;height:120px"></lord-icon>' +
                        '<div class="mt-4 pt-2 fs-15">' +
                        '<h4>Oops...! Something went Wrong !</h4>' +
                        '<p class="text-danger text-muted mx-4 mb-0">' + res.msg + '</p>' +
                        '</div>' +
                        '</div>',
                    showCancelButton: true,
                    showConfirmButton: false,
                    cancelButtonClass: 'btn btn-primary w-xs mb-1',
                    cancelButtonText: 'Dismiss',
                    buttonsStyling: false,
                    showCloseButton: true
                });
            }
        },
        error: function(res, textStatus, errorThrown){
            Swal.fire({
                html: '<div class="mt-3">' +
                    '<lord-icon src="https://cdn.lordicon.com/tdrtiskw.json" trigger="loop" colors="primary:#f06548,secondary:#f7b84b" style="width:120px;height:120px"></lord-icon>' +
                    '<div class="mt-4 pt-2 fs-15">' +
                    '<h4>Oops...! Something went Wrong !</h4>' +
                    '<p class="text-danger text-muted mx-4 mb-0">' + res.status + ' ' + res.statusText + '</p>' +
                    '</div>' +
                    '</div>',
                showCancelButton: true,
                showConfirmButton: false,
                cancelButtonClass: 'btn btn-primary w-xs mb-1',
                cancelButtonText: 'Dismiss',
                buttonsStyling: false,
                showCloseButton: true
            });
        }
    });
}

function push_categories_updateTips(lead_ele,ele_msg,ele_class,ele_style){
    ele_tips=$(lead_ele).parent().find('.category_msg-tips');
    if ($(ele_tips).length > 0) {
        $(ele_tips).html(ele_msg);
        $(ele_tips).attr('style',ele_style);
    }else{
        $(lead_ele).after('<span class="category_msg-tips" class="' + ele_class + '" style="'+ ele_style +'">' + ele_msg +'</span>');
    }
}