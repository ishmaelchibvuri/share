<?php
ini_set('max_execution_time', 600);
function dropstore_push_categories_to_dropstore_ajax_admin_fun()
{
    try {

        $orderby = 'name';
        $order = 'asc';
        $hide_empty = false ;
        $cat_args = array(
            'orderby'    => $orderby,
            'order'      => $order,
            'hide_empty' => $hide_empty,
        );

        $product_categories = get_terms( 'product_cat', $cat_args );

        if( !empty($product_categories) ){
            foreach ($product_categories as $key => $category) {
                push_category_to_dropstore($category->term_id, $category->name);
            }
        }

        $msg = 'Success';

    } catch (Exception $e) {
         $msg = $e->getMessage();
    }

$return = array( 'msg' => $msg);
echo json_encode($return);
die();

}

add_action("wp_ajax_dropstore_push_categories_to_dropstore_ajax_admin_fun",
    "dropstore_push_categories_to_dropstore_ajax_admin_fun");


function dropstore_pull_products_from_dropstore_ajax_js($hook)
{

    if (strpos($hook, 'toplevel_page_dropstore-products') !== false) {
        wp_enqueue_script('dropstore_pull_products_from_dropstore_ajax_js',
            plugins_url('/pull_products_from_dropstore.js', __FILE__), array('jquery'), 1.0);
        wp_register_script('dropstore-jquery-ba-throttle-debounce-min',
            DROPSTORE_URL . 'assets/lib/jquery/jquery.ba-throttle-debounce.min.js', array('jquery'), '1.0', true);
        /* you can use following enqueue in a shortcode to load as required */
        wp_enqueue_script('dropstore-jquery-ba-throttle-debounce-min');
    }
}

add_action('admin_enqueue_scripts', 'dropstore_pull_products_from_dropstore_ajax_js');