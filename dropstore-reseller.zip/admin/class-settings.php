<?php
class Download_Skulibrary_Data_Settings {
    private $_tabs=null;
    private $_current_tab=null;

    public function __construct() {
        $this->tabs_init();
        add_action( 'admin_init', array($this,'admin_init') );
        add_action( 'admin_menu', array($this,'admin_menu'), 90 );
        add_action('wp_head', 'custom_script');
    }

    function custom_script(){
        ?>
        <script type="text/javascript"><?php $ajax_url = admin_url('admin-ajax.php'); echo ("let ajaxurl = '" . $ajax_url . "';");?></script>
        <?php
    }

    public function tabs_init(){
        $tabs['general']=[
            'id'=>'general',
            'title'=>'General',
            'url'=>admin_url('admin.php?page=dropstore_settings') . '&tab=general',
            'tab_html_fun'=>'get_general_tab_html'
        ];

        $tabs['others']=[
            'id'=>'others',
            'title'=>'Setup Wizard',
            'url'=>admin_url('admin.php?page=dpothers_settings') . '&tab=others',
            'tab_html_fun'=>'get_others_tab_html'
        ];

        $this->_tabs=$tabs;
        $this->_current_tab=$tabs['general'];
        if(!empty($_GET['tab']) && isset($tabs[$_GET['tab']])){
            $this->_current_tab=$tabs[$_GET['tab']];
        }
    }

    function admin_init()
    {
        if('general' == $this->_current_tab['id']){
            $download_import_interval= '10_minutes';
            $download_interval= '4_hours';
            register_setting('dropstore_options','dropstore_access_token');
            register_setting('dropstore_options','dropstore_time_last_downloaded', date('Y-m-d H:i:s'));
            register_setting('dropstore_options','dropstore_time_last_imported', date('Y-m-d H:i:s'));
            register_setting('dropstore_options','dropstore_time_last_deleted', date('Y-m-d H:i:s'));
            register_setting('dropstore_options','dropstore_download_deleted_products_interval',array($this,'sanitize_download_deleted_products_interval'));
            add_action('wp_head', 'custom_script');
        }
    }

    function checkbox_single($name, $label, $current_value, $required=true, $tips='')
    {
        $id=dropstore_getLowCaseIdName($name);
        ob_start();
        $checked='';
        $checked_value='yes';
        if($checked_value==$current_value){
            $checked='checked="checked"';
        }
        ?>
        <div class="checkbox-single-wrapper <?php echo $id; ?>-checkbox-single-wrapper">
            <label><b>
                    <input type="checkbox" id="<?php echo $name; ?>" <?php echo $checked; ?> name="
                    <?php echo $name; ?>" value="
                    <?php echo $checked_value; ?>">
                    <?php echo $label; ?></b>
            </label>
        </div>
        <?php
        $html=ob_get_clean();
        return $html;
    }//end dropstore_checkbox_single()

    function checkbox($name, $options=array(),$current_value_arr=array())
    {
        ob_start();
        ?>
        <div class="checkbox">
            <?php foreach ($options as $value => $label): ?>
            <?php
                        $checked='';
                        if(in_array($value,$current_value_arr) != false){//find the value
                            $checked=' checked="checked"';
                        }
                        ?>
            <label>
                <input name="<?php echo $name . '[]'; ?>" type="checkbox" value="<?php echo $value; ?>" <?php echo $checked; ?>>
                <?php echo $label; ?>
            </label>
            <?php endforeach ?>
        </div>
        <?php
        $html=ob_get_clean();
        return $html;
    }

    function select($name, $options=array(),$current_value='')
    {
        ob_start();
        ?>
        <select name="<?php echo $name; ?>" id="<?php echo $name; ?>" class="form-control">
            <?php foreach ($options as $value => $label): ?>
            <?php
                        $selected='';
                        if($current_value==$value){
                            $selected=' selected="selected"';
                        }
                        ?>
            <option value="<?php echo $value; ?>" <?php echo $selected; ?>>
                <?php echo $label; ?>
            </option>
            <?php endforeach ?>
        </select>
        <?php
        $html=ob_get_clean();
        return $html;
    }

    function option_page()
    {
        ?>
<div class="wrap">
    <?php screen_icon(); ?>
    <nav class="nav-tab-wrapper woo-nav-tab-wrapper">
        <?php foreach ($this->_tabs as $t_key => $tab): ?>
        <?php
                    $active='';
                    if($t_key == $this->_current_tab['id']){
                        $active='nav-tab-active';
                    }
                    ?>
        <a href="<?php echo $tab['url']; ?>" class="nav-tab <?php echo $active; ?> ">
            <?php echo $tab['title']; ?></a>
        <?php endforeach ?>
    </nav>
    <style type="text/css">
    .desc {
        padding-top: 0;
        margin-top: 0;
        max-width: 500px;
    }

    .form-table th {
        margin: 20px 10px 20px 0;
        padding: 0px;
    }

    .nav-tab-wrapper {
        margin-bottom: 1.5rem;
    }
    </style>
    <?php
        call_user_func(array($this, $this->_current_tab['tab_html_fun']));
    ?>
    <?php

    }

    function get_others_tab_html()
    {
        wp_register_style('sweetalert2', DROPSTORE_URL . 'assets/libs/sweetalert2/sweetalert2.min.css');
        wp_register_script('sweetalert2', DROPSTORE_URL . 'assets/libs/sweetalert2/sweetalert2.min.js');
        wp_register_script('dropstore-layout', DROPSTORE_URL . 'assets/js/layout.js');
        wp_register_style('dropstore-bootstrap', DROPSTORE_URL . 'assets/css/bootstrap.min.css');
        wp_register_style('dropstore-icons', DROPSTORE_URL . 'assets/css/icons.min.css');
        wp_register_style('dropstore-app', DROPSTORE_URL . 'assets/css/app.min.css');
        wp_register_style('dropstore-app-custom', DROPSTORE_URL . 'assets/css/custom.min.css');
        wp_register_script('boostrap-bundle', DROPSTORE_URL . 'assets/libs/bootstrap/js/bootstrap.bundle.min.js');
        wp_register_script('simplebar', DROPSTORE_URL . 'assets/libs/simplebar/simplebar.min.js');
        wp_register_script('waves', DROPSTORE_URL . 'assets/libs/node-waves/waves.min.js');
        wp_register_script('lord-icon', DROPSTORE_URL . 'assets/js/pages/plugins/lord-icon-2.1.0.js');
        wp_register_script('masonry', DROPSTORE_URL . 'assets/libs/masonry-layout/masonry.pkgd.min.js');
        wp_register_script('card-init', DROPSTORE_URL . 'assets/js/pages/card.init.js');
        wp_register_script('dropstore-pull-products', DROPSTORE_URL . 'assets/js/pull_products_from_dropstore.js');
        wp_register_script('dropstore-app', DROPSTORE_URL . 'assets/js/app.js');


        wp_enqueue_script('sweetalert2');
        wp_enqueue_style('sweetalert2');

        wp_enqueue_script('dropstore-layout');
        wp_enqueue_style('dropstore-bootstrap');
        wp_enqueue_style('dropstore-icons');
        wp_enqueue_style('dropstore-app');
        wp_enqueue_style('dropstore-app-custom');

        wp_enqueue_script('boostrap-bundle');
        wp_enqueue_script('simplebar');
        wp_enqueue_script('waves');
        wp_enqueue_script('lord-icon');
        wp_enqueue_script('masonry');
        wp_enqueue_script('card-init');
        wp_enqueue_script('dropstore-pull-products');
        wp_enqueue_script('dropstore-app');
        ?>
        <style type="text/css">
        .btn-next {
            background-color: #3caae1 !important;
            border-color: #3caae1 !important;
            color: #fff !important;
            display: inline-block !important;
            margin-top: 1rem !important;
        }

        form .button-primary {
            display: none !important;
        }
        </style>
        <div class="row justify-content-center">
            <div class="col-md-10">
                <?php
                do_action( 'dropstore_sys_checker', $from='admin' );
                do_action( 'dropstore_checker_helper_info', $from='admin' );
                do_action( 'dropstore_save_access_token', $from='admin' );
                ?>
            </div>
        </div>

        <?php
    }
    function get_general_tab_html()
    {
        wp_register_style('sweetalert2', DROPSTORE_URL . 'assets/libs/sweetalert2/sweetalert2.min.css');
        wp_register_script('sweetalert2', DROPSTORE_URL . 'assets/libs/sweetalert2/sweetalert2.min.js');
        wp_register_script('dropstore-layout', DROPSTORE_URL . 'assets/js/layout.js');
        wp_register_style('dropstore-bootstrap', DROPSTORE_URL . 'assets/css/bootstrap.min.css');
        wp_register_style('dropstore-icons', DROPSTORE_URL . 'assets/css/icons.min.css');
        wp_register_style('dropstore-app', DROPSTORE_URL . 'assets/css/app.min.css');
        wp_register_style('dropstore-app-custom', DROPSTORE_URL . 'assets/css/custom.min.css');
        wp_register_script('boostrap-bundle', DROPSTORE_URL . 'assets/libs/bootstrap/js/bootstrap.bundle.min.js');
        wp_register_script('simplebar', DROPSTORE_URL . 'assets/libs/simplebar/simplebar.min.js');
        wp_register_script('waves', DROPSTORE_URL . 'assets/libs/node-waves/waves.min.js');
        wp_register_script('lord-icon', DROPSTORE_URL . 'assets/js/pages/plugins/lord-icon-2.1.0.js');
        wp_register_script('masonry', DROPSTORE_URL . 'assets/libs/masonry-layout/masonry.pkgd.min.js');
        wp_register_script('card-init', DROPSTORE_URL . 'assets/js/pages/card.init.js');
        wp_register_script('dropstore-pull-products', DROPSTORE_URL . 'assets/js/pull_products_from_dropstore.js');
        wp_register_script('dropstore-app', DROPSTORE_URL . 'assets/js/app.js');


        wp_enqueue_script('sweetalert2');
        wp_enqueue_style('sweetalert2');

        wp_enqueue_script('dropstore-layout');
        wp_enqueue_style('dropstore-bootstrap');
        wp_enqueue_style('dropstore-icons');
        wp_enqueue_style('dropstore-app');
        wp_enqueue_style('dropstore-app-custom');

        wp_enqueue_script('boostrap-bundle');
        wp_enqueue_script('simplebar');
        wp_enqueue_script('waves');
        wp_enqueue_script('lord-icon');
        wp_enqueue_script('masonry');
        wp_enqueue_script('card-init');
        wp_enqueue_script('dropstore-pull-products');
        wp_enqueue_script('dropstore-app');
        ?>
        <style>
            .card {
                padding: 0px!important;
                margin-top: 0px!important;
                max-width: 100%!important;
            }
            #adminmenu div.wp-menu-name {
                font-size: 12px!important;
            }
        </style>
        <?php
        $dropstore_access_token=get_option('dropstore_access_token');

        $last_deleted = get_option('dropstore_time_last_deleted');
        $time_last_deleted = new DateTime($last_deleted);
        $time_last_deleted->setTimezone(new DateTimeZone("Africa/Johannesburg"));

        $url=admin_url('admin.php?page=dropstore-products');


        $cnt = 0;
        foreach ( _get_cron_array() as $scheduled_jobs){
            if (array_key_exists('dropstore_download_deleted_products_cron_hook',$scheduled_jobs)) {
                $cnt++;
            }
        }

        ?>
        <main>
            <nav class="page-title-box d-sm-flex align-items-center justify-content-between pt-4">
                <div class="container">
                    <a class="navbar-brand" href="#">
                        <img src="<?php echo DROPSTORE_URL . 'assets/images/dropstore_logo.png'; ?>" alt="" height="64">
                    </a>
                </div>
            </nav>


            <div class="container-fluid bg-light pt-2">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 mb-4">
                            <div class="alert alert-secondary" role="alert">
                                This plugin will seamlessly allow you to integrate your WooCommerce store with DropStore by automatically pulling your products and pushing categories to your store and create Woocommerce Products on a schedule.
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title mb-2">System Requirements Check</h4>
                                </div>
                                <div class="card-body">
                                    <table class="table table-bordered align-middle mb-0">
                                        <tbody>
                                            <tr>
                                                <td>Server Memory capacity</td>
                                                <td>
                                                    <?php if(rtrim(ini_get('memory_limit'),"M") < '256') : ?>
                                                        <span style='font-size: 12px;' class='badge text-bg-warning px-1 py-1'><?php echo esc_html(ini_get('memory_limit')) ?></span>
                                                        <div class="alert alert-danger mt-1" role="alert">
                                                            You need a minimum of 256M memory for the plugin to work efficiently. There is a high possibility that the plugin would not function properly
                                                        </div>
                                                    <?php else : ?>
                                                        <span style='font-size: 12px;' class='badge text-bg-success px-1 py-1'><?php echo esc_html(ini_get('memory_limit')) ?></span>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Woocommerce Installed</td>
                                                <td>
                                                    <?php if(is_plugin_active('woocommerce/woocommerce.php')) : ?>
                                                        <span style="font-size: 12px;" class="badge text-bg-success px-1 py-1">Installed</span>
                                                    <?php else : ?>
                                                        <span style="font-size: 12px;" class="badge text-bg-danger px-1 py-1">please activate Woocommerce</span>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Scheduled Process Installed</td>
                                                <td class="">
                                                    <?php
                                                        $setupUrl = admin_url('admin.php?page=dropstore-setup');
                                                    ?>
                                                    <?php if($cnt < 1) : ?>
                                                        <div class="alert alert-danger mt-1" role="alert">
                                                            There are some scheduled processes missing. <br>Run setup from the <b>Setup Wizard</b> in the next tab
                                                        </div>

                                                    <?php else : ?>
                                                        <span style="font-size: 12px;" class="badge text-bg-success px-1 py-1">Setup correctly</span>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title mb-2">Dropstore Access Token</h4>
                                </div>
                                <div class="card-body">
                                    <div class="alert alert-<?php echo esc_attr(empty(trim($dropstore_access_token)) ? 'danger' : 'warning') ?>" role="alert">
                                        In order to have the integration working, you would need to get your merchant access token on your DropStore Merchant Account.
                                    </div>
                                    <div style="font-size: 14px;" class="alert alert-success text-center <?php echo esc_attr(empty(trim($dropstore_access_token)) ? 'd-none' : ''); ?>" role="alert">
                                        <?php echo esc_html($dropstore_access_token); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title mb-2">Push Categories to Dropstore</h4>
                                </div>
                                <div class="card-body">
                                    <div class="alert alert-warning" role="alert">
                                        <strong>Please Note:</strong> In order to push your categories to Dropstore, you need to create them first on this store.
                                        Click on <strong>Push Categories to Dropstore</strong> - this pulls your categories from this Woocommerce store and send them to Dropstore
                                    </div>
                                    <?php wp_nonce_field( 'dropstore_pull_categories_nonce' ); ?>
                                    <button type="button" id="push-categories-button" class="btn btn-primary waves-effect waves-light <?php echo esc_attr(empty(trim($dropstore_access_token)) ? 'd-none' : ''); ?>" data-task="pull_products" onclick="event_push_categories(event)"><?php echo __( 'Push Categories to Dropstore', 'dropstore' ); ?></button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
        <!-- /.container -->
        <?php
    }

    function admin_menu()
    {
        // add_options_page('Download Skulibrary Data','Download Skulibrary Data', 'manage_options', 'dropstore_settings', array($this,'option_page'));
        add_submenu_page( 'dropstore-products', __( 'Help and Settings', 'dropstore' ), __( 'Help and Settings', 'dropstore' ), 'manage_options', 'dropstore_settings', array( $this, 'option_page' ) );
        add_submenu_page( null, __( 'Help and Settings', 'dropstore' ), __( 'Help and Settings', 'dropstore' ), 'manage_options', 'dpothers_settings', array( $this, 'option_page' ) );
    }

    function sanitize_download_deleted_products_interval( $input ) {
        dropstore_setup_download_deleted_products_cron_job('dropstore_download_deleted_products_cron_hook', $input);
        return $input;
    }
}
$download_skulibrary_data_settings = new Download_Skulibrary_Data_Settings();