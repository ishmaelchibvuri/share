<?php
if( is_admin() ) {
    //dropstore_db_install_orders_table();
}

function dropstore_db_install_orders_table()
{
 /*   define('DROPSTORE_ORDERS_DB_VERSION', '1.0');
    $dropstore_installed = get_option('dropstore_orders_db_version');
    if( $dropstore_installed != DROPSTORE_ORDERS_DB_VERSION ) { 
        GLOBAL $wpdb;
        
        $wp_prefix = $wpdb->prefix;
        // This includes the dbDelta function from WordPress.
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        $create_orders_table = ("
CREATE TABLE `{$wp_prefix}dropstore_orders` (
    `id` int(11) UNSIGNED NOT NULL auto_increment,
     PRIMARY KEY  (`id`),

     `api_reference` varchar(255) NOT NULL default '',
     `api_websiteReference` varchar(255) NOT NULL default '',
     `api_customerName` varchar(255) NOT NULL default '',
     `api_customerPhone` varchar(255) NOT NULL default '',
     `api_customerEmail` varchar(255) NOT NULL default '',
     `woo_customerName` varchar(255) NOT NULL default '',
     `woo_customerPhone` varchar(255) NOT NULL default '',
     `woo_customerEmail` varchar(255) NOT NULL default '',
     `api_timeCreated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
     `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
     `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
     `api_refer` text NOT NULL default '',
     `woo_refer` text NOT NULL default '',
     `api_id` int UNSIGNED NOT NULL default 0,
     `woo_id` int UNSIGNED NOT NULL default 0,
     `woo_order_no` int UNSIGNED NOT NULL default 0,
     `woo_timeCreated` int UNSIGNED NOT NULL default 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;");
        
        // Create/update the plugin tables.
        dbDelta($create_orders_table);
        update_option('dropstore_orders_db_version', DROPSTORE_ORDERS_DB_VERSION);
    }
 */
}