<?php
function dropstore_orders_init(){
    require_once dirname( __FILE__ ) . '/orders-functions.php';
    require_once dirname( __FILE__ ) . '/orders-db-functions.php';
    require_once dirname( __FILE__ ) . '/orders.php';
    if(is_admin()){
        require_once dirname( __FILE__ ) . '/orders-wp-install.sql.php'; 
        require_once dirname( __FILE__ ) . '/admin/class-orders-list-table.php';
        require_once dirname( __FILE__ ) . '/admin/class-orders-form-handler.php';
        require_once dirname( __FILE__ ) . '/admin/class-orders.php'; 
    }
}//end dropstore_init

add_action('init','dropstore_orders_init',10);

function dropstore_orders_data_was_saved_successfully($insert_id,$fields)
{
    // your code here
}
add_action('orders_data_was_saved_successfully','dropstore_orders_data_was_saved_successfully',10,2);
