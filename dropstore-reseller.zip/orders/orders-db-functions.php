<?php
function dropstore_get_all_orders( $args = array(), $fields=array() ) {
    global $wpdb;

    $defaults = array(
        'offset'     => 0,
        'number'     => 20,
        'where'      => array(),
        'orderby'    => 'id',
        'order'      => 'DESC',
        'groupby'    => '',
    );

    $args      = wp_parse_args( $args, $defaults );
    $_cache_key=dropstore_cache_key($args);
    $cache_key = 'orders-all' . $_cache_key . $args['offset'] . '-' . $args['number'];
    $items     = wp_cache_get( $cache_key, 'dropstore' );
    $where = dropstore_get_where($args['where']);
    $fields_line=dropstore_get_fields_line($fields);

    if ( false === $items ) {
        $sql='SELECT ' . $fields_line . ' FROM ' .   $wpdb->prefix . "dropstore_orders" . $where .' ORDER BY ' . $args['orderby'] .' ' . $args['order'] .' LIMIT ' . $args['offset'] . ', ' . $args['number'];
        if(!empty($args['groupby'])){
            $sql='SELECT ' . $fields_line . ' FROM ' .   $wpdb->prefix . "dropstore_orders" . $where 
                . ' GROUP BY '. $args['groupby'] .' ORDER BY ' . $args['orderby'] .' ' . $args['order']  .' LIMIT ' . $args['offset'] . ', ' . $args['number'];
        }
        $items = $wpdb->get_results($sql);

        wp_cache_set( $cache_key, $items, 'dropstore' );
    }

    return $items;
}

function dropstore_get_orders_count($args=array()) {
    global $wpdb;
    $where = dropstore_get_where($args['where']);
    return (int) $wpdb->get_var( "SELECT COUNT(id) FROM " .   $wpdb->prefix . "dropstore_orders" . $where);
}

function dropstore_get_orders_by_id( $id = 0, $fields=array()  ) {
    global $wpdb;

    $fields_line=dropstore_get_fields_line($fields);
    return $wpdb->get_row( $wpdb->prepare( "SELECT " . $fields_line . " FROM " .   $wpdb->prefix . "dropstore_orders" . " WHERE id = %d", $id ) );
}

function dropstore_update_orders_by_vars_where($vars=array(),$where=array()) {
    if(empty($vars)){
        return false;
    }

    global $wpdb;
    $table_prefix=$wpdb->prefix;

    $set_vars=array();
    foreach ($vars as $key => $value) {
        $set_vars[]=sprintf("`%s`='%s'",$key,esc_sql($value));
    }
    $set_vars_line=' SET ' . implode(',',$set_vars) . ' ';

    $where = dropstore_get_where($where);
    if(!empty($where)){
        $sql="UPDATE  " .  $wpdb->prefix . "dropstore_orders" . $set_vars_line . $where;
        $result = $wpdb->query($sql);
        return $result;
    }
    return false;
}

function dropstore_delete_orders($args=array()) {
    global $wpdb;
    $where = dropstore_get_where($args['where']);
    $result=false;
    if(!empty($where)){
        $result = $wpdb->query("DELETE FROM " .  $wpdb->prefix . "dropstore_orders" . $where);
    }
    return $result;
}

function dropstore_delete_orders_by_id($id = 0) {
    global $wpdb;
    $table_prefix=$wpdb->prefix;
    $result = $wpdb->query($wpdb->prepare("DELETE FROM " .  $wpdb->prefix . "dropstore_orders" . " WHERE  id = %d", $id ));
    return $result;
}

function dropstore_insert_orders( $args = array() ) {
    global $wpdb;

    $defaults = array(
        'id' => '',
//        'created_at' => '',
//        'updated_at' => '',
//         'api_reference' => '',
//         'api_websiteReference' => '',
//         'api_customerName' => '',
//         'api_customerPhone' => '',
//         'api_customerEmail' => '',
//         'woo_customerName' => '',
//         'woo_customerPhone' => '',
//         'woo_customerEmail' => '',
//         'api_timeCreated' => '',
// //        'created_at' => '',
// //        'updated_at' => '',
//         'api_refer' => '',
//         'woo_refer' => '',
//         'api_id' => '',
//         'woo_id' => '',
//         'woo_order_no' => '',
//         'woo_timeCreated' => '',
    );

    $args       = wp_parse_args( $args, $defaults );
    $table_name =   $wpdb->prefix . "dropstore_orders";
    if(empty($args['id'])){
        $saved_args['where']=[
            'woo_id'=>$args['woo_id']
            //condition here
        ];
        $saved_obj=dropstore_get_all_orders($saved_args);

        if(isset($saved_obj[0])){
            $args['id']=$saved_obj[0]->id;
        }
    }
    // some basic validation
    // if ( empty( $args['orders_name'] ) ) {
    //     return new WP_Error( 'no-orders_name', __( 'No Campaign Name provided.', 'dropstore' ) );
    // }

    // if ( empty( $args['cp_url'] ) ) {
    //     return new WP_Error( 'no-cp_url', __( 'No Campaign Url provided.', 'dropstore' ) );
    // }
    // remove row id to determine if new or update
    $row_id = (int) $args['id'];
    unset( $args['id'] );

    if ( ! $row_id ) {

        // insert a new
        if ( $wpdb->insert( $table_name, $args ) ) {
            return $wpdb->insert_id;
        }

    } else {

        // do update method here
        $wpdb->update( $table_name, $args, array( 'id' => $row_id ) );
        return $row_id;
    }

    return false;
}