<?php 
require_once DROPSTORE_DIR . '/includes/form-fields.php';
require_once DROPSTORE_DIR . '/includes/db-functions.php';
require_once DROPSTORE_DIR . '/orders/orders-init.php';
