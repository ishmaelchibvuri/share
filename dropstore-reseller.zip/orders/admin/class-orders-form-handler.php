<?php

/**
 * Handle the form submissions
 *
 * @package Package
 * @subpackage Sub Package
 */
class DropStore_Orders_Form_Handler {

    /**
     * Hook 'em all
     */
    public function __construct() {
        add_action( 'admin_init', array( $this, 'handle_form' ) );
    }

    /**
     * Handle the orders new and edit form
     *
     * @return void
     */
    public function handle_form() {
        // echo '<div style="display1:none;"><pre>';
        // var_dump(__METHOD__);
        // echo '</pre></div>';
        // die();
        if ( ! isset( $_POST['submit_orders'] ) ) {
            return;
        }
        // echo '<div style="display1:none;"><pre>';
        // var_dump(__METHOD__);
        // echo '</pre></div>';
        // die();
        if ( ! wp_verify_nonce( $_POST['_wpnonce'], 'dropstore_orders_nonce' ) ) {
            die( __( 'Wrong nonce!', 'dropstore' ) );
        }

        if ( ! current_user_can( 'read' ) ) {
            wp_die( __( 'Permission Denied!', 'dropstore' ) );
        }

        $errors   = array();
        $page_url = admin_url( 'admin.php?page=dropstore-orders' );
        $field_id = isset( $_POST['field_id'] ) ? intval( $_POST['field_id'] ) : 0;

        // $clicks = isset( $_POST['clicks'] ) ? sanitize_text_field( $_POST['clicks'] ) : '';
        $api_reference = isset( $_POST['api_reference'] ) ? sanitize_text_field( $_POST['api_reference'] ) : '';
        $api_websiteReference = isset( $_POST['api_websiteReference'] ) ? sanitize_text_field( $_POST['api_websiteReference'] ) : '';
        $api_customerName = isset( $_POST['api_customerName'] ) ? sanitize_text_field( $_POST['api_customerName'] ) : '';
        $api_customerPhone = isset( $_POST['api_customerPhone'] ) ? sanitize_text_field( $_POST['api_customerPhone'] ) : '';
        $api_customerEmail = isset( $_POST['api_customerEmail'] ) ? sanitize_text_field( $_POST['api_customerEmail'] ) : '';
        $woo_customerName = isset( $_POST['woo_customerName'] ) ? sanitize_text_field( $_POST['woo_customerName'] ) : '';
        $woo_customerPhone = isset( $_POST['woo_customerPhone'] ) ? sanitize_text_field( $_POST['woo_customerPhone'] ) : '';
        $woo_customerEmail = isset( $_POST['woo_customerEmail'] ) ? sanitize_text_field( $_POST['woo_customerEmail'] ) : '';
        $api_timeCreated = isset( $_POST['api_timeCreated'] ) ? sanitize_text_field( $_POST['api_timeCreated'] ) : '';
        $created_at = isset( $_POST['created_at'] ) ? sanitize_text_field( $_POST['created_at'] ) : '';
        $updated_at = isset( $_POST['updated_at'] ) ? sanitize_text_field( $_POST['updated_at'] ) : '';
        $api_refer = isset( $_POST['api_refer'] ) ? sanitize_text_field( $_POST['api_refer'] ) : '';
        $woo_refer = isset( $_POST['woo_refer'] ) ? sanitize_text_field( $_POST['woo_refer'] ) : '';
        $api_id = isset( $_POST['api_id'] ) ? sanitize_text_field( $_POST['api_id'] ) : '';
        $woo_id = isset( $_POST['woo_id'] ) ? sanitize_text_field( $_POST['woo_id'] ) : '';
        $woo_order_no = isset( $_POST['woo_order_no'] ) ? sanitize_text_field( $_POST['woo_order_no'] ) : '';
        $woo_timeCreated = isset( $_POST['woo_timeCreated'] ) ? sanitize_text_field( $_POST['woo_timeCreated'] ) : '';
        // some basic validation
        // if ( ! $clicks ) {
        //     $errors[] = __( 'Error: Clicks is required', 'dropstore' );
        // }

        if (empty($api_reference) ) {
            $errors[] = __( 'Error: Api Reference is required', 'dropstore' );
        }
        if (empty($api_websiteReference) ) {
            $errors[] = __( 'Error: Api Website Reference is required', 'dropstore' );
        }
        if (empty($api_customerName) ) {
            $errors[] = __( 'Error: Api Customer Name is required', 'dropstore' );
        }
        if (empty($api_customerPhone) ) {
            $errors[] = __( 'Error: Api Customer Phone is required', 'dropstore' );
        }
        if (empty($api_customerEmail) ) {
            $errors[] = __( 'Error: Api Customer Email is required', 'dropstore' );
        }
        if (empty($woo_customerName) ) {
            $errors[] = __( 'Error: Woo Customer Name is required', 'dropstore' );
        }
        if (empty($woo_customerPhone) ) {
            $errors[] = __( 'Error: Woo Customer Phone is required', 'dropstore' );
        }
        if (empty($woo_customerEmail) ) {
            $errors[] = __( 'Error: Woo Customer Email is required', 'dropstore' );
        }
        if (empty($api_timeCreated) ) {
            $errors[] = __( 'Error: Api Time Created is required', 'dropstore' );
        }
/*        if (empty($created_at) ) {
            $errors[] = __( 'Error: Created At is required', 'dropstore' );
        }*/
/*        if (empty($updated_at) ) {
            $errors[] = __( 'Error: Updated At is required', 'dropstore' );
        }*/
        if (empty($api_refer) ) {
            $errors[] = __( 'Error: Api Refer is required', 'dropstore' );
        }
        if (empty($woo_refer) ) {
            $errors[] = __( 'Error: Woo Refer is required', 'dropstore' );
        }
        if (empty($api_id) ) {
            $errors[] = __( 'Error: Api ID is required', 'dropstore' );
        }
        if (empty($woo_id) ) {
            $errors[] = __( 'Error: Woo ID is required', 'dropstore' );
        }
        if (empty($woo_order_no) ) {
            $errors[] = __( 'Error: Woo Order No is required', 'dropstore' );
        }
        if (empty($woo_timeCreated) ) {
            $errors[] = __( 'Error: Woo Time Created is required', 'dropstore' );
        }

        $fields = array(
            'api_reference' => $api_reference,
            'api_websiteReference' => $api_websiteReference,
            'api_customerName' => $api_customerName,
            'api_customerPhone' => $api_customerPhone,
            'api_customerEmail' => $api_customerEmail,
            'woo_customerName' => $woo_customerName,
            'woo_customerPhone' => $woo_customerPhone,
            'woo_customerEmail' => $woo_customerEmail,
            'api_timeCreated' => $api_timeCreated,
//            'created_at' => $created_at,
//            'updated_at' => $updated_at,
            'api_refer' => $api_refer,
            'woo_refer' => $woo_refer,
            'api_id' => $api_id,
            'woo_id' => $woo_id,
            'woo_order_no' => $woo_order_no,
            'woo_timeCreated' => $woo_timeCreated,
        );
        // bail out if error found
        if ( $errors ) {
            $first_error = reset( $errors );
            if(empty($field_id)){
                $query_arg=$fields + array( 'error' => urlencode($first_error), 'action' =>'new' ); 
                $redirect_to = add_query_arg($query_arg, $page_url );
            }else{
                $query_arg=$fields + array( 'error' => urlencode($first_error), 'action' =>'edit','id'=>$field_id ); 
                $redirect_to = add_query_arg($query_arg, $page_url );
            }
            wp_safe_redirect( $redirect_to );
            exit;
        }

        // New or edit?
        if ( ! $field_id ) {

            $insert_id = dropstore_insert_orders( $fields );

        } else {

            $fields['id'] = $field_id;

            $insert_id = dropstore_insert_orders( $fields );
        }

        if ( is_wp_error( $insert_id ) ) {
            $redirect_to = add_query_arg(
                array( 'error' => urlencode($insert_id->get_error_message()) ),
                $page_url
            );
        } else {
            do_action('orders_data_was_saved_successfully',$insert_id,$fields);
            $redirect_to = add_query_arg(
                array( 'success' => urlencode(__( 'Succesfully saved!', 'dropstore' )) ),
                $page_url
            );
        }

        wp_safe_redirect( $redirect_to );
        exit;
    }
}

new DropStore_Orders_Form_Handler();