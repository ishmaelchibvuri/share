<?php 
$item=new stdClass();
$item->id=0;

$fields=array('api_reference','api_websiteReference','api_customerName','api_customerPhone','api_customerEmail','woo_customerName','woo_customerPhone','woo_customerEmail','api_timeCreated','created_at','updated_at','api_refer','woo_refer','api_id','woo_id','woo_order_no','woo_timeCreated');

foreach ($fields as $field) {
    if(isset($_GET[$field])){
        if(is_array($_GET[$field])){
            $item->$field=$_GET[$field];
        }else{
            $item->$field=urldecode($_GET[$field]);
        }
    }
}

$submit_button_title=__( 'Add New Orders', 'dropstore' );
$form_title=__( 'New Orders', 'dropstore' );

require dirname(__FILE__) . '/orders-form.php';
