<?php 
$item = dropstore_get_orders_by_id( $id ); 
$submit_button_title=__( 'Update Orders', 'dropstore' );
$form_title=__( 'Edit Orders', 'dropstore' );

require dirname(__FILE__) . '/orders-form.php';
