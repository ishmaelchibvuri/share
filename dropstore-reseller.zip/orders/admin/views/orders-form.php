<div class="wrap">
    <h2><?php _e( $form_title, 'dropstore' ); ?></h2>
    <?php if (array_key_exists('error', $_GET)): ?>
        <div class="notice notice-error"><p><?php echo $_GET['error']; ?></p></div>
    <?php endif; ?>
    <?php if (array_key_exists('success', $_GET)): ?>
        <div class="notice notice-success"><p><?php echo $_GET['success']; ?></p></div>
    <?php endif; ?>

    <form action="" method="post">
        <?php
        echo dropstore_text('api_reference','Api reference',$item->api_reference,true); 
        echo dropstore_text('api_websiteReference','Api website reference',$item->api_websiteReference,true); 
        echo dropstore_text('api_customerName','Api customer name',$item->api_customerName,true); 
        echo dropstore_text('api_customerPhone','Api customer phone',$item->api_customerPhone,true); 
        echo dropstore_text('api_customerEmail','Api customer email',$item->api_customerEmail,true); 
        echo dropstore_text('woo_customerName','Woo customer name',$item->woo_customerName,true); 
        echo dropstore_text('woo_customerPhone','Woo customer phone',$item->woo_customerPhone,true); 
        echo dropstore_text('woo_customerEmail','Woo customer email',$item->woo_customerEmail,true); 
        echo dropstore_datetimepicker('api_timeCreated','Api time created',$item->api_timeCreated,true); 
//        echo dropstore_datetimepicker('created_at','Created at',$item->created_at,true); 
//        echo dropstore_datetimepicker('updated_at','Updated at',$item->updated_at,true); 
        echo dropstore_textarea('api_refer','Api refer',$item->api_refer,true); 
        echo dropstore_textarea('woo_refer','Woo refer',$item->woo_refer,true); 
        echo dropstore_text('api_id','Api id',$item->api_id,true); 
        echo dropstore_text('woo_id','Woo id',$item->woo_id,true); 
        echo dropstore_text('woo_order_no','Woo order no',$item->woo_order_no,true); 
        echo dropstore_text('woo_timeCreated','Woo time created',$item->woo_timeCreated,true); 
        ?>
        <input type="hidden" name="field_id" value="<?php echo $item->id; ?>">

        <?php wp_nonce_field( 'dropstore_orders_nonce' ); ?>
        <?php submit_button( $submit_button_title, 'primary', 'submit_orders' ); ?>

    </form>
</div>