<?php

function get_orders_for_dropstore()
{
    global $wpdb;
    $headers = get_server_headers();

    $auth_result = auth($headers);


    if ($auth_result == true) {

        $criteria = " ";

        if (isset($_GET['id']) && !is_null($_GET['id'])) {
            $criteria .= "AND id > {$_GET['id']}";
        }

        if (isset($_GET['limit']) && !is_null($_GET['limit'])) {
            $criteria .= " LIMIT {$_GET['limit']}";
        }else {
            $criteria .= " LIMIT 5";
        }
        $results = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}posts WHERE post_type LIKE 'shop_order' AND post_status = 'wc-processing' " . $criteria);

        $orders = array();

// Loop through each order post object
        foreach ($results as $result) {

            // Get an instance of the WC_Order Object
            $order = wc_get_order($result->ID);

            if ($order->post_status == 'wc-processing') {
                $orderArray = [
                    'id' => $order->id,
                    'parent_id' => $order->parant_id,
                    'status' => 'processing',
                    'currency' => $order->currency,
                    'prices_include_tax' => $order->prices_include_tax,
                    'discount_total' => $order->discount_total,
                    'discount_tax' => $order->discount_tax,
                    'shipping_total' => $order->shipping_total,
                    'shipping_tax' => $order->shipping_tax,
                    'cart_tax' => $order->cart_tax,
                    'total' => $order->total,
                    'total_tax' => $order->total_tax,
                    'customer_id' => $order->get_customer_id(),
                    'order_key' => $order->order_key,
                    'payment_method' => $order->payment_method,
                    'payment_method_title' => $order->payment_method_title,
                    'transaction_id' => $order->transaction_id,
                    'date_paid' => $order->date_paid,
                    'cart_hash' => $order->cart_hash,
                    'meta_data' => $order->meta_data,
                    'tax_lines' => $order->tax_lines,
                    'shipping_lines' => $order->shipping_lines,
                    'fee_lines' => $order->fee_lines,
                    'refunds' => $order->refunds,
                    'currency_symbol' => $order->currency_symbol,
                ];

                $orderArray['billing'] = [
                    'first_name' => $order->get_billing_first_name(),
                    'last_name' => $order->get_billing_last_name(),
                    'company' => $order->get_billing_company(),
                    'address_1' => $order->get_billing_address_1(),
                    'address_2' => $order->get_billing_address_2(),
                    'city' => $order->get_billing_city(),
                    'state' => $order->get_billing_state(),
                    'postcode' => $order->get_billing_postcode(),
                    'country' => $order->get_billing_country(),
                    'email' => $order->get_billing_email(),
                    'phone' => $order->get_billing_phone(),
                ];


                $orderArray['shipping'] = [
                    'first_name' => $order->get_shipping_first_name(),
                    'last_name' => $order->get_shipping_last_name(),
                    'company' => $order->get_shipping_company(),
                    'address_1' => $order->get_shipping_address_1(),
                    'address_2' => $order->get_shipping_address_2(),
                    'city' => $order->get_shipping_city(),
                    'state' => $order->get_shipping_state(),
                    'postcode' => $order->get_shipping_postcode(),
                    'country' => $order->get_shipping_country(),
                    'phone' => $order->get_shipping_phone(),
                ];


                $order_items = $order->get_items();
                $lineItems = array();
                foreach ($order_items as $item) {

                    $product = wc_get_product($item['product_id']);

                    $lineItems
                        = [
                        'id' => $item['id'],
                        'name' => $item['name'],
                        'product_id' => $item['product_id'],
                        'variation_id' => $item['variation_id'],
                        'quantity' => $item['quantity'],
                        'tax_class' => $item['tax_class'],
                        'subtotal' => $item['subtotal'],
                        'subtotal_tax' => $item['subtotal_tax'],
                        'total' => $item['total'],
                        'taxes' => $item['taxes'],
                        'meta_data' => $item['meta_data'],
                        'sku' => $product->get_sku(),
                        'price' => $product->get_price()
                    ];

                }

                $orderArray['line_items'][] = $lineItems;

                $orders[] = $orderArray;
            }
        }

        return array('orders' => $orders, 'status_code' => 200);
    }else{
        return array('orders' => 'Authorization failed', 'status_code' => 400);
    }
}