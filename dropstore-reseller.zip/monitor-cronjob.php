<?php

ini_set('max_execution_time', 600);

function dropstore_monitor_cron_schedules($schedules)
{
    $schedules['5_minutes'] = array(
        'interval' => 60 * 5,
        'display' => __('5 Minutes')
    );
    $schedules['10_minutes'] = array(
        'interval' => 60 * 10,
        'display' => __('10 Minutes')
    );
    $schedules['15_minutes'] = array(
        'interval' => 60 * 15,
        'display' => __('15 Minutes')
    );
    $schedules['30_minutes'] = array(
        'interval' => 60 * 30,
        'display' => __('30 Minutes')
    );
    $schedules['hourly'] = array(
        'interval' => 60 * 60 * 1,
        'display' => __('Hourly')
    );
    $schedules['2_hours'] = array(
        'interval' => 60 * 60 * 2,
        'display' => __('2 Hours')
    );
    $schedules['3_hours'] = array(
        'interval' => 60 * 60 * 3,
        'display' => __('3 Hours')
    );
    $schedules['4_hours'] = array(
        'interval' => 60 * 60 * 4,
        'display' => __('4 Hours')
    );
    $schedules['5_hours'] = array(
        'interval' => 60 * 60 * 5,
        'display' => __('5 Hours')
    );
    $schedules['6_hours'] = array(
        'interval' => 60 * 60 * 6,
        'display' => __('6 Hours')
    );
    $schedules['8_hours'] = array(
        'interval' => 60 * 60 * 8,
        'display' => __('8 Hours')
    );
    $schedules['12_hours'] = array(
        'interval' => 60 * 60 * 12,
        'display' => __('12 Hours')
    );
    $schedules['daily'] = array(
        'interval' => 60 * 60 * 24,
        'display' => __('Daily')
    );
    return $schedules;
}

add_filter('cron_schedules', 'dropstore_monitor_cron_schedules');

function dropstore_setup_monitor_cron_job($cron_hook, $schedule_id = '5_mins')
{
    $all_schedules_ids = array(
        '5_minutes',
        '10_minutes',
        '15_minutes',
        '30_minutes',
        'hourly',
        '2_hours',
        '3_hours',
        '4_hours',
        '5_hours',
        '6_hours',
        '8_hours',
        '12_hours',
        'daily',
        'hourly',
        'daily',
        'twicedaily'
    );
   /* if (false == in_array($schedule_id, $all_schedules_ids)) {
        $schedule_id = '5_minutes';
    }
    if (wp_next_scheduled($cron_hook)) {//clear previous settings
        wp_clear_scheduled_hook($cron_hook);
    }
    wp_schedule_event(time(), $schedule_id, $cron_hook);
   */
}

function dropstore_monitor_cron_task($reset = false)
{
    global $wpdb;
    $table_name = $wpdb->prefix . "dropstore_products";
    $state = 'success';
    $data[] = '';

    try {

        $access_token = get_option('dropstore_access_token');
        $time_last_deleted = get_option('dropstore_time_last_deleted');

        /* check last time delete cron ran - every 6 hours */
        $to_time = strtotime("now");
        $from_time = strtotime($time_last_deleted);
        $delete_diff_in_min = round(abs($to_time - $from_time) / 60);

        if($delete_diff_in_min > 360){
            dropstore_download_deleted_products_cron_task();
        }

    } catch (Exception $e) {
        $msg = $e->getMessage();
    }

    return $msg;
}

add_action('dropstore_monitor_cron_hook', 'dropstore_monitor_cron_task');

