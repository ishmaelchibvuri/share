<?php
function dropstore_get_wc_version()
{
    /*ensure WooCommerce has be activated.*/
    if (!defined('WOOCOMMERCE_VERSION')) {
        return 0;
    }
    $wc_v = get_transient('wc_drm_wc_v');
    if (false === $wc_v) {

        $wc_v = WOOCOMMERCE_VERSION;
        set_transient('wc_drm_wc_v', $wc_v, DAY_IN_SECONDS * 7);
    }
    return $wc_v;
}

function create_variable_product($args)
{

    $product = new WC_Product_Variable();
    $product->set_name(wc_clean($args['name']));
    if (isset($args['slug'])) {
        $product->set_name($args['slug']);
    }
    $product->set_sku($args['sku']);
    // Description and short description:
    $product->set_description($args['description']);
    $product->set_short_description($args['short_description']);

    // Status ('publish', 'pending', 'draft' or 'trash')
    $product->set_status('publish');

    // Visibility ('hidden', 'visible', 'search' or 'catalog')
    $product->set_catalog_visibility($args['visibility'] ?? 'visible');

    // Featured (boolean)
    $product->set_featured($args['featured'] ?? false);

    // Virtual (boolean)
    $product->set_virtual($args['virtual'] ?? false);

    // Prices
    $product->set_regular_price($args['regular_price']);
    $product->set_sale_price($args['sale_price'] ?? '');
    $product->set_price($args['sale_price'] ?? $args['regular_price']);

    $product->set_manage_stock(false);// ? $args['manage_stock'] : false);
    $product->set_stock_status($args['stock_status']);

    // Images and Gallery
    $product->set_image_id($args['image_id'] ?? "");
    $product->set_gallery_image_ids($args['gallery_ids'] ?? array());

//Create the attribute object

    $attribute = new WC_Product_Attribute();
//pa_size tax id
    $attribute->set_id(0);
//pa_size slug
    $attribute->set_name('variants');

//Set terms slugs
    $attribute->set_options($args['attributes']['variants']);
    $attribute->set_position(0);

//If enabled
    $attribute->set_visible(1);
    $attribute->set_variation(1);

    $product->set_attributes(array($attribute));

//Save main product to get its id
    $id = $product->save();

    //   dropstoreTag($id);

    return $id;
}

function create_product_variation($product_id, $title, $sku, $regular_price, $stock)
{
    $product = wc_get_product($product_id);

    if($product && $product->exists()) {

        $variation_post = array(
            'post_title' => $product->get_title(),
            'post_name' => 'product-' . $product_id . '-variation',
            'post_status' => 'publish',
            'post_parent' => $product_id,
            'post_type' => 'product_variation',
            'guid' => $product->get_permalink()
        );

        $variation_id = wp_insert_post($variation_post);

        $variation = new WC_Product_Variation($variation_id);

        $variation->set_sku($sku);
        $variation->set_regular_price($regular_price);
        $variation->set_stock_quantity($stock);
        $variation->set_manage_stock('yes');
        $variation->set_backorders('no');

        $variation->save();

        update_post_meta($variation_id, 'attribute_variants', $title);
    }
}

function update_variation($value)
{

    update_post_meta($value['id'], '_regular_price', $value['regular_price']);
    update_post_meta($value['id'], '_price', $value['price']);
    update_post_meta($value['id'], '_stock', $value['stock_qty']);
    update_post_meta($value['id'], '_stock_status', ((int)$value['stock_qty'] > 0) ? 'instock' : 'outofstock');

}

// Custom function for product creation (For Woocommerce 3+ only)
function create_simple_product($args)
{
    global $woocommerce;

    $product = new WC_Product_Simple(); // "simple" By default

    // Product name (Title) and slug
    $product->set_name(wc_clean($args['name'])); // Name (title).
    if (isset($args['slug'])) {
        $product->set_name($args['slug']);
    }

    // Description and short description:
    $product->set_description($args['description']);
    $product->set_short_description($args['short_description']);

    // Status ('publish', 'pending', 'draft' or 'trash')
    $product->set_status('publish');

    // Visibility ('hidden', 'visible', 'search' or 'catalog')
    $product->set_catalog_visibility($args['visibility'] ?? 'visible');

    // Featured (boolean)
    $product->set_featured($args['featured'] ?? false);

    // Virtual (boolean)
    $product->set_virtual($args['virtual'] ?? false);

    // Prices
    $product->set_regular_price($args['regular_price']);
    $product->set_sale_price($args['sale_price'] ?? '');
    $product->set_price($args['sale_price'] ?? $args['regular_price']);
    if (isset($args['sale_price'])) {
        $product->set_date_on_sale_from($args['sale_from'] ?? '');
        $product->set_date_on_sale_to($args['sale_to'] ?? '');
    }

    // Downloadable (boolean)
    $product->set_downloadable($args['downloadable'] ?? false);
    if (isset($args['downloadable']) && $args['downloadable']) {
        $product->set_downloads($args['downloads'] ?? array());
        $product->set_download_limit($args['download_limit'] ?? '-1');
        $product->set_download_expiry($args['download_expiry'] ?? '-1');
    }

    // Taxes
    if (get_option('woocommerce_calc_taxes') === 'yes') {
        $product->set_tax_status($args['tax_status'] ?? 'taxable');
        $product->set_tax_class($args['tax_class'] ?? '');
    }


    $product->set_sku($args['sku'] ?? '');
    $product->set_manage_stock($args['manage_stock'] ?? false);
    $product->set_stock_status($args['stock_status'] ?? 'instock');

    if (isset($args['manage_stock']) && $args['manage_stock']) {
        $product->set_stock_quantity($args['stock_qty']);
        $product->set_backorders($args['backorders'] ?? 'no'); // 'yes', 'no' or 'notify'
    }


    // Sold Individually
    $product->set_sold_individually($args['sold_individually'] ?? false);

    // Weight, dimensions and shipping class
    $product->set_weight($args['weight'] ?? '');
    $product->set_length($args['length'] ?? '');
    $product->set_width($args['width'] ?? '');
    $product->set_height($args['height'] ?? '');
    if (isset($args['shipping_class_id'])) {
        $product->set_shipping_class_id($args['shipping_class_id']);
    }

    // Upsell and Cross sell (IDs)
    $product->set_upsell_ids($args['upsells'] ?? '');
    $product->set_cross_sell_ids(isset($args['cross_sells']) ? $args['upsells'] : '');

    // Attributes et default attributes
    if (isset($args['attributes'])) {
        //     $product->set_attributes(wc_prepare_product_attributes($args['attributes']));
    }
    if (isset($args['default_attributes'])) {
        $product->set_default_attributes($args['default_attributes']);
    } // Needs a special formatting

    // Reviews, purchase note and menu order
    $product->set_reviews_allowed($args['reviews'] ?? false);
    $product->set_purchase_note($args['note'] ?? '');
    if (isset($args['menu_order'])) {
        $product->set_menu_order($args['menu_order']);
    }

    // Product categories and Tags
    if (isset($args['category_ids'])) {
        $product->set_category_ids($args['category_ids']);
    }
    if (isset($args['tag_ids'])) {
        $product->set_tag_ids($args['tag_ids']);
    }

    ## --- SAVE PRODUCT --- ##
    $id = $product->save();

    dropstoreTag($id);

    return $id;

}

function get_product_by_sku( $sku ) {
    $product_id = wc_get_product_id_by_sku($sku);

    if ($product_id) {
        return wc_get_product($product_id);
    } else {
       return null;
    }
}

function dropstoreTag($wpid){
   /*
    $artCatName = 'drop@tore';
    $postCat = wp_get_post_tags($wpid, array('fields' => 'names'));
    if (!in_array($artCatName, $postCat)) {
        array_push($postCat, $artCatName);
        wp_set_post_tags($wpid, $postCat);
        wp_set_object_terms($wpid, 'drop@tore');
    }
   */
}