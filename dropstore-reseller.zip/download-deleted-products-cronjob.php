<?php
function dropstore_add_download_deleted_products_cron_schedules($schedules) {
    $schedules['10_minutes'] = array(
        'interval' => 60*10,
        'display' => __('10 Minutes')
    );
    $schedules['15_minutes'] = array(
        'interval' => 60*15,
        'display' => __('15 Minutes')
    );
    $schedules['30_minutes'] = array(
        'interval' => 60*30*1,
        'display' => __('30 Minutes')
    );
    $schedules['hourly'] = array(
        'interval' => 60*60*1,
        'display' => __('Hourly')
    );
    $schedules['2_hours'] = array(
        'interval' => 60*60*2,
        'display' => __('2 Hours')
    );
    $schedules['3_hours'] = array(
        'interval' => 60*60*3,
        'display' => __('3 Hours')
    );
    $schedules['4_hours'] = array(
        'interval' => 60*60*4,
        'display' => __('4 Hours')
    );
    $schedules['5_hours'] = array(
        'interval' => 60*60*5,
        'display' => __('5 Hours')
    );
    $schedules['6_hours'] = array(
        'interval' => 60*60*6,
        'display' => __('6 Hours')
    );
    $schedules['8_hours'] = array(
        'interval' => 60*60*8,
        'display' => __('8 Hours')
    );
    $schedules['12_hours'] = array(
        'interval' => 60*60*12,
        'display' => __('12 Hours')
    );
    $schedules['daily'] = array(
        'interval' => 60*60*24,
        'display' => __('Daily')
    );
    return $schedules;
}
add_filter('cron_schedules', 'dropstore_add_download_deleted_products_cron_schedules');

function dropstore_setup_download_deleted_products_cron_job($cron_hook,$schedule_id='6_hours') {
    $all_schedules_ids=array('10_minutes','15_minutes','30_minutes','hourly','2_hours','3_hours','4_hours','5_hours','6_hours','8_hours','12_hours','daily','twicedaily');
    if(false==in_array($schedule_id,$all_schedules_ids)){
        $schedule_id='daily';
    }
    if (wp_next_scheduled( $cron_hook )) {//clear previous settings
        wp_clear_scheduled_hook($cron_hook);
    }
    wp_schedule_event(time(), $schedule_id, $cron_hook);
}

function dropstore_download_deleted_products_cron_task() {
    $results=[];
    $results['downloaded_deleted']=dropstore_download_and_delete_products();

    update_option('dropstore_time_last_deleted', date('Y-m-d H:i:s'));

    return $results;

}
add_action( 'dropstore_download_deleted_products_cron_hook', 'dropstore_download_deleted_products_cron_task' );

