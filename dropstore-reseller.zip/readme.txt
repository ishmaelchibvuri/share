=== Dropstore Reseller ===
Tags: woocommerce, products, dropstore, dropshipping
Requires at least: 5.7
Tested up to: 6.0.3
Stable tag: 6.3.2
License: GPLv2 or later

Dropstore lets you find products, add them to your Online store, and ship directly to your customers.

== Description ==

## Dropstore lets you find products, add them to your Online store, and ship directly to your customers

Dropstore is an online inventory marketplace that makes it easy to find and sell products from South African suppliers to sell on your online store. We achieve this goal by streamlining and simplifying product sourcing from various suppliers for online entrepreneurs and completing this turnkey process by also having automatic order sync from your store to the Dropstore platform and ultimately to the supplier.

* Stock levels and prices auto-update in real-time.
* The order will be automatically imported from your store to Dropstore.
* Map the product category you want from suppliers to your store categories.

PS: You'll be prompted to get an Dropstore Acccess Token to use it, once activated.

== Installation ==

Upload the Dropstore Reseller plugin to your blog, activate it, and then go through the setup wizard enter your Dropstore Acccess Token.

1, 2, 3: You're done!

== Changelog ==
