<?php
ini_set('max_execution_time', 600);

function dropstore_save_main_settings( $access_token) {
    if(empty($access_token)){
        return false;
    }

    $delete_interval= 'daily';
    $dropstore_create_update_count= '25';

    update_option('dropstore_access_token', $access_token);
    update_option('dropstore_products_delete_interval', $delete_interval);
    update_option('dropstore_products_create_update_count', $dropstore_create_update_count);
    update_option('dropstore_update_images_with_product_update',false);

    update_option('dropstore_time_last_downloaded', date('Y-m-d H:i:s'));
    update_option('dropstore_time_last_imported', date('Y-m-d H:i:s'));
    update_option('dropstore_time_last_deleted', date('Y-m-d H:i:s'));

    create_webhook($access_token);
    verify_plugin_on_dropstore($access_token);

    dropstore_setup_download_products_cron_job('dropstore_download_products_cron_hook');
    dropstore_setup_download_deleted_products_cron_job('dropstore_download_deleted_products_cron_hook', $delete_interval);

    return true;
}

function dropstore_get_interval_options( ) {
    $interval_options=array(
        '5_minutes'=>__('5 Minutes','dropstore'),
        '10_minutes'=>__('10 Minutes','dropstore'),
        '15_minutes'=>__('15 Minutes','dropstore'),
        '30_minutes'=>__('30 Minutes','dropstore'),
        'hourly'=>__('Hourly','dropstore'),
        '2_hours'=>__('2 Hours','dropstore'),
        '3_hours'=>__('3 Hours','dropstore'),
        '4_hours'=>__('4 Hours','dropstore'),
        '5_hours'=>__('5 Hours','dropstore'),
        '6_hours'=>__('6 Hours','dropstore'),
        '8_hours'=>__('8 Hours','dropstore'),
        '12_hours'=>__('12 Hours','dropstore'),
        'daily'=>__('Daily','dropstore'),
    );

    return $interval_options;
}
function dropstore_get_status_symbol( $status ) {
    if('passed'==$status) return '<span style="color:green !important;">&#x2714;</span>';
    if('failed'==$status) return '<span style="color:red !important;">&#10008;</span>';
}

function dropstore_dropstore_sys_checker( $from='admin' ) {
    ?>


    <?php
    $sys_checkers['cronjob']=[
        'name'=>'Cronjob',
        'version'=>'',
        'info'=>defined('DISABLE_WP_CRON') ? 'disabled' : 'enabled',
        'status'=>defined('DISABLE_WP_CRON') ? 'failed' : 'passed',
    ];

    wp_register_script('dropstore-layout', DROPSTORE_URL . 'assets/js/layout.js');
    wp_register_style('dropstore-bootstrap', DROPSTORE_URL . 'assets/css/bootstrap.min.css');
    wp_register_style('dropstore-icons', DROPSTORE_URL . 'assets/css/icons.min.css');
    wp_register_style('dropstore-app', DROPSTORE_URL . 'assets/css/app.min.css');
    wp_register_style('dropstore-app-custom', DROPSTORE_URL . 'assets/css/custom.min.css');
    wp_register_script('boostrap-bundle', DROPSTORE_URL . 'assets/libs/bootstrap/js/bootstrap.bundle.min.js');
    wp_register_script('simplebar', DROPSTORE_URL . 'assets/libs/simplebar/simplebar.min.js');
    wp_register_script('waves', DROPSTORE_URL . 'assets/libs/node-waves/waves.min.js');
    wp_register_script('lord-icon', DROPSTORE_URL . 'assets/js/pages/plugins/lord-icon-2.1.0.js');
    wp_register_script('masonry', DROPSTORE_URL . 'assets/libs/masonry-layout/masonry.pkgd.min.js');
    wp_register_script('card-init', DROPSTORE_URL . 'assets/js/pages/card.init.js');
    wp_register_script('dropstore-app', DROPSTORE_URL . 'assets/js/app.js');

    wp_enqueue_script('dropstore-layout');
    wp_enqueue_style('dropstore-bootstrap');
    wp_enqueue_style('dropstore-icons');
    wp_enqueue_style('dropstore-app');
    wp_enqueue_style('dropstore-app-custom');

    wp_enqueue_script('boostrap-bundle');
    wp_enqueue_script('simplebar');
    wp_enqueue_script('waves');
    wp_enqueue_script('lord-icon');
    wp_enqueue_script('masonry');
    wp_enqueue_script('card-init');
    wp_enqueue_script('dropstore-app');
    ?>
    <style>
        .card {
            padding: 0px!important;
            margin-top: 0px!important;
            max-width: 100%!important;
        }
        #adminmenu div.wp-menu-name {
            font-size: 12px!important;
        }
    </style>
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title mb-2">System Requirements</h4>
                </div>
                <div class="card-body">
                    <table class="table table-bordered align-middle table-wrap mb-0">
                        <tbody>
                            <?php foreach ($sys_checkers as $key => $sys): ?>
                                <tr>
                                    <td><?php echo $sys['name']; ?></td>
                                    <td>
                                        <?php $badge = ($sys['status'] == 'passed' ? 'success' : 'danger'); ?>
                                        <span style="font-size: 12px;" class="badge text-bg-<?php echo esc_attr($badge); ?> px-1 py-1"><?php echo esc_html($sys['info']) ?></span>
                                    </td>
                                </tr>
                            <?php endforeach ?>
                            <tr>
                                <td>Server Memory capacity</td>
                                <td>
                                    <?php if(rtrim(ini_get('memory_limit'),"M") < '256') : ?>
                                        <span style='font-size: 12px;' class='badge text-bg-warning px-1 py-1'><?php echo esc_html(ini_get('memory_limit')) ?></span>
                                        <div class="alert alert-danger mt-1" role="alert">
                                            You need a minimum of 256M memory for the plugin to work efficiently. There is a high possibility that the plugin would not function properly
                                        </div>
                                    <?php else : ?>
                                        <span style='font-size: 12px;' class='badge text-bg-success px-1 py-1'><?php echo esc_html(ini_get('memory_limit')) ?></span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <?php
        $depends=[];

        $required_plugins['WooCommerce']=[
            'version'=>'latest',
            'file'=>'woocommerce/woocommerce.php',
            'info'=>'not installed',
            'status'=>'failed',
        ];

        if( !function_exists('get_plugin_data') ){
            require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
        }

        foreach ($required_plugins as $plugin_name => $plugin) {
            $plugin_file=PLUGINS_DIR . '/' . $plugin['file'];
            $version=$plugin['version'];
            $info=$plugin['info'];
            $status=$plugin['status'];
            $plg_data=get_plugin_data($plugin_file);
            // [Name] => WooCommerce
            // [PluginURI] => https://woocommerce.com/
            // [Version] => 4.2.2
            if(!empty($plg_data['Version'])){
                $version=$plg_data['Version'];
                $info='please activate the plugin';
            }
            if(is_plugin_active( $plugin['file'] )){
                $info='installed and activate';
                $status='passed';
            }
            $depends[$plugin_name]=[
                'name'=>$plugin_name,
                'info'=>$info,
                'version'=>$version,
                'status'=>$status,
            ];
        }
        ?>

        <div class="col-md-12 mt-2 mb-2">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title mb-2">Plugin Dependency</h4>
                </div>
                <div class="card-body">
                    <table class="table table-bordered align-middle table-wrap mb-0">
                        <tbody>
                        <?php foreach ($depends as $plugin_name => $dep): ?>
                            <tr>
                                <td><?php echo esc_html($plugin_name); ?></td>
                                <td>
                                    <?php $badge = ($dep['status'] == 'passed' ? 'success' : 'danger'); ?>
                                    <span style="font-size: 12px;" class="badge text-bg-<?php echo esc_attr($badge); ?> px-1 py-1"><?php echo esc_html($dep['info']); ?></span>
                                </td>
                                <?php if($dep['status'] == 'passed') : ?>
                                    <td>
                                        <span style="font-size: 12px;" class="badge text-bg-info px-1 py-1"> Version : <?php echo esc_html($dep['version']); ?></span>
                                    </td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
    <?php
}
add_action( 'dropstore_sys_checker', 'dropstore_dropstore_sys_checker' );

function dropstore_dropstore_save_access_token( $from='admin' ) {
    ?>
    <style>
        .card {
            padding: 0px!important;
            margin-top: 0px!important;
            max-width: 100%!important;
        }
        #adminmenu div.wp-menu-name {
            font-size: 12px!important;
        }
    </style>
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title mb-2">Dropstore Setup</h4>
                </div>
                <div class="card-body">
                <?php if  (!empty($_POST)) {
                     $accessToken =  htmlspecialchars($_POST["access_token"]);
                    dropstore_save_main_settings($accessToken);
                    ?>
                    <div class="alert alert-success" role="alert">
                        <strong>Access Token successfully updated
                    </div>
                    <?php
                 } ?>
                    <form method="POST" action="">
                    <table class="table table-bordered align-middle table-wrap mb-0">
                        <tbody>
                        <tr>
                            <td>
                                <div>
                                    <?php wp_nonce_field( 'dropstore_save_main_settings_nonce' ); ?>
                                    <label for="access_token"><b>Access Token:</b></label>
                                    <input type="text" name="access_token" id="access_token" class="form-control" value="<?php echo get_option('dropstore_access_token'); ?>">
                                    <br/>
                                </div>
                            </td>
                            <td>
                                <input type="submit" class="btn btn-primary" value="Save Access">

                            </td>
                        </tr>
                        </tbody>
                    </table>
                    </form>
                </div>
            </div>
        </div>

    </div>
    <?php
}
add_action( 'dropstore_save_access_token', 'dropstore_dropstore_save_access_token' );
function dropstore_setup_admin_enqueue_scripts($hook) {

    if( strpos($hook,'open_call_page_c9oc-submissions') !== false){
        wp_register_style('dropstore-bootstrap', DROPSTORE_URL . 'assets/libs/bootstrap/css/bootstrap.min.css');
        wp_register_style('dropstore-bootstrap-utilities', DROPSTORE_URL . 'assets/libs/bootstrap/css/bootstrap.-utilities.min.css');
        wp_register_script('dropstore-bootstrap-bundle-min', DROPSTORE_URL . 'assets/libs/bootstrap/js/bootstrap.bundle.min.js', array('jquery'), '1.0', true);

    }
}
add_action( 'admin_enqueue_scripts', 'dropstore_setup_admin_enqueue_scripts' );

function dropstore_string_line_formatter($string_line){
    if(empty($string_line)) return false;

    $clean_dash_name=preg_replace('/[^A-Z0-9]+/i','-',$string_line);
    $clean_dash_name=trim($clean_dash_name,'-');

    $clean_id_name=preg_replace('/[^A-Z0-9]+/i','_',$string_line);
    $clean_id_name=trim($clean_id_name,'_');

    $parts=explode("_",$clean_id_name);
    $parts=array_map('ucfirst',$parts);
    $name=implode("_",$parts);
    $class_name=$name;

    $low_case_class_name=lcfirst($class_name);

    $id=strtolower($clean_id_name);

    $constant=strtoupper($clean_id_name);

    $dash_id=strtolower($clean_dash_name);

    $parts=explode('-',$clean_dash_name);
    $parts=array_map('ucfirst',$parts);
    //for some special strings
    foreach ($parts as $key => $part) {
        if('Id'==$part){
            $parts[$key]='ID';
        }
    }
    $title=implode(' ',$parts);

    $result=compact('constant','id','dash_id','title');

    return $result;
}