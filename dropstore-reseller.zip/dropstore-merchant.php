<?php


/*
 * Plugin Name: Dropstore Reseller
 * Plugin URI: https://www.dropstore.co.za
 * Description: Import products from Dropstore, and delete products on delete list, send order to Dropstore.
 * Author: Dropstore
 * Author URI: https://help.dropstore.co.za
 * Version: 7.0.0
 * Text Domain: dropstore
 * Domain Path: /languages
 * WC requires at least: 5.7.0
 * WC tested up to: 7.6.1
 * PHP version 7.3
  */
/*  Copyright 2021  Dropstore (Pty) Ltd  ( email : info@dropstore.co.za )

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License, version 2, as
    published by the Free Software Foundation.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


define('DROPSTORE_URL', plugin_dir_url(__FILE__));
define('DROPSTORE_DIR', dirname(__FILE__));
define('PLUGINS_DIR', dirname(DROPSTORE_DIR));

function dropstore_load_plugin_textdomain()
{
    load_plugin_textdomain('dropstore', FALSE, dirname(plugin_basename(__FILE__)) . '/languages');
}

add_action('plugins_loaded', 'dropstore_load_plugin_textdomain');

require_once DROPSTORE_DIR . '/php-errors-log.php'; //uncomments to turn on php errors log
require_once DROPSTORE_DIR . '/functions.php';
require_once DROPSTORE_DIR . '/dropstore-api/api-functions.php';

require_once DROPSTORE_DIR . '/includes/form-fields.php';
require_once DROPSTORE_DIR . '/includes/db-functions.php';
require_once DROPSTORE_DIR . '/includes/woocommerce-functions.php';
require_once DROPSTORE_DIR . '/products/products-init.php';
require_once DROPSTORE_DIR . '/orders/orders-init.php';
require_once DROPSTORE_DIR . '/cronjob_log/cronjob_log-init.php';

require_once DROPSTORE_DIR . '/download-products-cronjob.php';
require_once DROPSTORE_DIR . '/download-deleted-products-cronjob.php';
require_once DROPSTORE_DIR . '/import-products-cronjob.php';
//require_once DROPSTORE_DIR . '/monitor-cronjob.php';
require_once DROPSTORE_DIR . '/plugin-checker/checker-init.php';

if (is_admin()) {
    // require_once DROPSTORE_DIR . '/dropstore-install.php';
    require_once DROPSTORE_DIR . '/admin/admin.php';
}

function dropstore_deactivation()
{
    wp_clear_scheduled_hook('dropstore_download_products_cron_hook');
    wp_clear_scheduled_hook('dropstore_import_products_cron_hook');
    wp_clear_scheduled_hook('dropstore_download_deleted_products_cron_hook');
    //  wp_clear_scheduled_hook('dropstore_monitor_cron_hook');
}

register_deactivation_hook(__FILE__, 'dropstore_deactivation');


function dropstore_activation()
{
    update_option("dropstore_show_my_plugin_wizard_notice", 1);
    $access_token = get_option('dropstore_access_token');

    $delete_interval = 'twicedaily';

    update_option('dropstore_access_token', $access_token);
    update_option('dropstore_time_last_deleted', date('Y-m-d H:i:s'));
    update_option('dropstore_download_products_index', 1);
    //dropstore_setup_download_products_cron_job('dropstore_download_products_cron_hook');
    //dropstore_setup_download_deleted_products_cron_job('dropstore_download_deleted_products_cron_hook', $delete_interval);
    // dropstore_setup_monitor_cron_job('dropstore_monitor_cron_hook', $monitor_interval);
    //wp_clear_scheduled_hook('dropstore_monitor_cron_hook');

    //empty the current log files
    $log_file=dirname(__FILE__) . '/php-errors.log';
    file_put_contents($log_file, "");
    add_option( 'dropstore_activation_redirect', true );
}

register_activation_hook(__FILE__, 'dropstore_activation');


add_action("admin_init", function () {
    if (get_option($opt_name = "dropstore_show_my_plugin_wizard_notice")) {
        delete_option($opt_name);
        add_action("admin_notices", "dropstore_wizard_notice");
    }
    if(get_option($opt_name = "dropstore_activation_redirect")){
        delete_option($opt_name);
        wp_safe_redirect( admin_url( 'admin.php?page=dropstore_settings' ) );
        exit;
    }
    return;
});

/**
 * Check if user has completed wizard already
 * if so then return true (don't show notice)
 *
 */
function dropstore_wizard_completed()
{
    return false;
}

function dropstore_wizard_notice()
{

    if (dropstore_wizard_completed()) {
        return;
    } // completed already
    ?>

    <div class="updated notice is-dismissible">
        <p>Welcome to dropstore plugin! You're almost there, but we think this wizard might help you setup the
            plugin.</p>
        <p><a href="<?php echo admin_url('admin.php?page=dropstore_settings'); ?>" class="button button-primary">Run Setup
                Wizard</a> <a href="javascript:window.location.reload()" class="button">Dismiss</a></p>
    </div>

    <?php

}

function get_server_headers()
{
    $headers = array();
    foreach ($_SERVER as $name => $value) {
        if (substr($name, 0, 5) == 'HTTP_') {
            $headers[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))))] = $value;
        }
    }
    return $headers;
}

function auth(array $headers)
{
    $incoming_api_key = '';

    foreach ($headers as $key => $value) {
        if (strtolower('X-Dropstore-Access-Token') == strtolower($key)) {
            $incoming_api_key = $value;
        }
    }

    $local_api_key = get_option('dropstore_access_token');

    if (strcmp(trim($local_api_key),trim($incoming_api_key)) !== 0) {
        return false;
    } else {
        return true;
    }
}

function createNewProduct($product){
    global $wpdb;

    $productVariants = $product['variants'];
    $descArray = explode('.', $product['description'], 2);
    $short_description = $descArray[0];

    if (!is_countable($productVariants) || count($productVariants) == 0 || (count($productVariants) == 1 && ($productVariants[0]['title'] == 'Default' || $productVariants[0]['title'] == 'Default Title'))) {
        $payload = [
            'name' => $product['title'],
            'description' => $product['description'],
            'short_description' => $short_description,
            'sku' => $product['sku'],
            'regular_price' => $product['price'], // product price
            'status' => ($product['status'] == 'active' ? 'publish' : 'pending'),
            'visibility' => ($product['status'] == 'active' ? 'visible' : 'hidden'),
            'manage_stock' => true,
            'stock_qty' => $product['quantity'],
            'weight' => ($product['weight'] ?? ''),
            'length' => ($product['dimensions']['length'] ?? ''),
            'width' => ($product['dimensions']['width'] ?? ''),
            'height' => ($product['dimensions']['height'] ?? '')
        ];

        $resultID = create_simple_product($payload);

        $woocommerceProduct = new WC_Product($resultID);

        $images = $product['images'];
        foreach ($images as $image) {
            if ($image['src'] != '') {
                if (strstr($image['src'], '?', true)) {
                    $file = strstr($image['src'], '?', true);
                } else {
                    $file = $image['src'];
                }

                if (check_attachment_exists_by_filename($file)) {
                    $imageIDs[] = get_attachment_by_filename($file);
                }else{
                    $imgID = setProductImage($resultID, $file);
                        $imageIDs[] = $imgID;
                }
            }
        }

        if (isset($imageIDs) && is_countable($imageIDs) && count($imageIDs) > 0 && $imageIDs[0] != '') {
            $woocommerceProduct->set_image_id($imageIDs[0]);
        }
        if (isset($imageIDs) && is_countable($imageIDs) && count($imageIDs) > 1) {
            //$imageIDs = array_shift($imageIDs);
            $galleryIDs = array_slice($imageIDs, 1);
            $woocommerceProduct->set_gallery_image_ids($galleryIDs);

        }

        $categories = $product['category'];

        if (isset($product['category']) && is_countable($categories) && count($categories) > 0) {
            $category_ids = [];
            foreach ($categories as $category) {
                if (isset($category['mappedCategoryId'])) {
                    $category_ids[] = $category['mappedCategoryId'];
                }
            }

            if (is_countable($category_ids) && count($category_ids) > 0) {
                $woocommerceProduct->set_category_ids($category_ids);
            }
        }
        $woocommerceProduct->save();

    }else{
        $img = '';

        $payload = [
            'name' => $product['title'],
            'description' => $product['description'],
            'short_description' => $short_description,
            'sku' => $product['sku'],
            'regular_price' => $product['price'], // product price
            'status' => ($product['status'] == 'active' ? 'publish' : 'pending'),
            'visibility' => ($product['status'] == 'active' ? 'visible' : 'hidden'),
            'manage_stock' => false,
            'stock_qty' => $product['quantity'],
            'weight' => ($product['weight'] ?? ''),
            'length' => ($product['dimensions']['length'] ?? ''),
            'width' => ($product['dimensions']['width'] ?? ''),
            'height' => ($product['dimensions']['height'] ?? '')
        ];

        $variation_data = [];
        $stockCount = 0;
        foreach ($productVariants as $productVariant) {
            $variation_data[] = $productVariant['title'];
            $payload['variants'][] = [
                'title' => $productVariant['title'],
                'sku' => $productVariant['sku'],
                'regular_price' => $productVariant['price'],
                'price' => $productVariant['price'],
                'stock_qty' => $productVariant['quantity']
            ];
            $stockCount += $productVariant['quantity'];
        }

        if ($stockCount > 0) {
            $payload['stock_status'] = 'instock';
        } else {
            $payload['stock_status'] = 'outofstock';
        }
        $payload['attributes']['variants'] = $variation_data;
        $payload['attributes_label'] = implode(" , ", $variation_data);

        $resultID = create_variable_product($payload);

        foreach ($productVariants as $productVariant) {
            $sku = $productVariant['sku'];
            create_product_variation($resultID, $productVariant['title'], $sku, $productVariant['price'], $productVariant['quantity']);
        }

        $woocommerceProduct = new WC_Product($resultID);

        $images = $product['images'];
        foreach ($images as $image) {
            if ($image['src'] != '') {
                if (strstr($image['src'], '?', true)) {
                    $file = strstr($image['src'], '?', true);
                } else {
                    $file = $image['src'];
                }

                if (check_attachment_exists_by_filename($file)) {
                    $imageIDs[] = get_attachment_by_filename($file);
                }else{
                    $imgID = setProductImage($resultID, $file);
                    if (!is_null($imgID)){
                        $imageIDs[] = $imgID;
                    }else{
                        $imgID = setProductImage($resultID, $file, true);
                        if (!is_null($imgID)){
                            $imageIDs[] = $imgID;
                        }
                    }
                }
            }
        }

        if (isset($imageIDs) && is_countable($imageIDs) && count($imageIDs) > 0 && $imageIDs[0] != '') {
            $woocommerceProduct->set_image_id($imageIDs[0]);
        }
        if (isset($imageIDs) && is_countable($imageIDs) && count($imageIDs) > 1) {
            //$imageIDs = array_shift($imageIDs);
            $woocommerceProduct->set_gallery_image_ids($imageIDs);

        }


        $categories = $product['category'];

        if (isset($product['category']) && is_countable($categories) && count($categories) > 0) {
            $category_ids = [];
            foreach ($categories as $category) {
                if (isset($category['mappedCategoryId'])) {
                    $category_ids[] = $category['mappedCategoryId'];
                }
            }

            if (is_countable($category_ids) && count($category_ids) > 0) {
                $woocommerceProduct->set_category_ids($category_ids);
            }
        }
        $woocommerceProduct->save();

    }

    return $resultID;
}

function dropstore_plugin_add_settings_link($links)
{
    $url = admin_url('admin.php?page=dropstore_settings');
    $settings_link = '<a href="' . $url . '">' . __('Settings') . '</a>';
    array_unshift($links, $settings_link);
    return $links;
}

add_filter("plugin_action_links_" . plugin_basename(__FILE__), 'dropstore_plugin_add_settings_link');

add_action('rest_api_init', function () {

    register_rest_route('wc/v3/dropstore', 'orders', array(
        'methods' => 'GET',
        'callback' => 'get_orders_for_dropstore',
    ));

    register_rest_route('wc/v3/dropstore/products', 'create', array(
        'methods' => 'POST',
        'callback' => 'post_products_for_dropstore',
    ));

    register_rest_route('wc/v3/dropstore/products', 'delete', array(
        'methods' => 'DELETE',
        'callback' => 'delete_products_for_dropstore',
    ));
});

add_action('before_woocommerce_init', function(){

    if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );

    }

});