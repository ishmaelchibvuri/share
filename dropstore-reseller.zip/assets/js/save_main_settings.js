function goToMainPage(url){
    window.location.href = url;
}

function saveAccessTokenSettings(event) {
    if(!jQuery(event.target).closest('div').hasClass('d-none')){
        jQuery(event.target).closest('div').addClass('d-none');
    }
    const spinnerHTML = '<div class="spinner-border text-primary" role="status">\n' +
        '  <span class="visually-hidden">Loading...</span>\n' +
        '</div>';
    jQuery('.steps-result-area-inner').html(spinnerHTML);
    let timeout = setTimeout(function (){
        event_process(event);
    }, 500);
}

function event_process(event){
    event.preventDefault();
    var wpnonce=encodeURIComponent(jQuery("[name='_wpnonce']").val());
    var wp_http_referer=encodeURIComponent(jQuery("[name='_wp_http_referer']").val());
    var access_token=encodeURIComponent(jQuery("[name='access_token']").val());
    var download_import_interval=encodeURIComponent(jQuery("[name='download_import_interval']").val());

    var post_data="access_token="+ access_token;
    post_data=post_data + "&download_import_interval="+ download_import_interval;
    post_data=post_data + "&_wpnonce="+ wpnonce;
    post_data=post_data + "&_wp_http_referer="+ wp_http_referer;

    var result_area=jQuery(this);//note if you change something here, please update $("#main_settings-btn-next").on('save_main_settings_received',function(evt,res){ as well
    ajax_call_save_main_settings(result_area, post_data, event);
    event.preventDefault();
}

function ajax_call_save_main_settings(ajax_ele, post_data, event){
    jQuery.ajax({
        type: "POST",
        data: post_data + "&action=dropstore_save_main_settings_ajax_admin_fun",
        url: ajaxurl,
        datatype: 'json',
        beforeSend:function(){
        },
        success:function(res){
            if(jQuery(event.target).closest('div').hasClass('d-none')){
                jQuery(event.target).closest('div').removeClass('d-none');
            }
            res=jQuery.parseJSON(res);
            if('success' === res.state){
               const successAlertHTML = '<div class="alert alert-success" role="alert">\n' +
                                        '    <strong>Success! </strong>Settings saved successfully\n' +
                                        '</div>';
                jQuery('.steps-result-area-inner').html(successAlertHTML);
                jQuery(event.target).closest('div').children(':first-child').addClass('d-none');
                jQuery(event.target).closest('div').children(':first-child').next().html('<i class="ri-arrow-right-line label-icon align-middle fs-16 ms-2"></i>Click to complete');
            }else{
                const errorAlertHTML = '<div class="alert alert-danger" role="alert">\n' +
                    '    <strong>Error! </strong>An error occurred while saving the settings. Please try again\n' +
                    '</div>';
                jQuery('.steps-result-area-inner').html(errorAlertHTML);
            }
        },
        error: function(res, textStatus, errorThrown){
            if(jQuery(event.target).closest('div').hasClass('d-none')){
                jQuery(event.target).closest('div').removeClass('d-none');
            }
            const errorAlertHTML = '<div class="alert alert-danger" role="alert">\n' +
                '    <strong>Error! </strong> An error occurred while saving the settings\n' +
                '    <br>\n' +
                '    <strong>' + res.status + ' ' + res.statusText + '</strong>\n' +
                '</div>';
            jQuery('.steps-result-area-inner').html(errorAlertHTML);
        }
    });
}

function save_main_settings_updateTips(lead_ele,ele_msg,ele_class,ele_style){
    ele_tips=$(lead_ele).parent().find('.save_main_settings_msg-tips');
    if ($(ele_tips).length > 0) {
        $(ele_tips).html(ele_msg);
        $(ele_tips).attr('style',ele_style);
    }else{
        $(lead_ele).after('<span class="save_main_settings_msg-tips" class="' + ele_class + '" style="'+ ele_style +'">' + ele_msg +'</span>');
    }
}