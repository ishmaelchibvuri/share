<?php
function dropstore_dropstore_checker_helper_info( $from='admin' ) {
// echo 'test';
}
add_action( 'dropstore_checker_helper_info', 'dropstore_dropstore_checker_helper_info' );    